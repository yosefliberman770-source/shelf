<?xml version="1.0" encoding="utf-8" ?>
<ogr:FeatureCollection
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://ogr.maptools.org/ Bridges1250.xsd"
     xmlns:ogr="http://ogr.maptools.org/"
     xmlns:gml="http://www.opengis.net/gml">
  <gml:boundedBy>
    <gml:Box>
      <gml:coord><gml:X>227483</gml:X><gml:Y>44171</gml:Y></gml:coord>
      <gml:coord><gml:X>645280</gml:X><gml:Y>652738</gml:Y></gml:coord>
    </gml:Box>
  </gml:boundedBy>
                                                                                                                                       
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.0">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>461131,118831</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>?Brockbridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Meon</ogr:River>
      <ogr:Attested>1280</ogr:Attested>
      <ogr:Built_by>1280</ogr:Built_by>
      <ogr:Place_name>pontem de Bradebrigge inter Menestok' et Drokenesford</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 46</ogr:Other_ref>
      <ogr:Notes>Location of Brockbridge certain, but whether this was the 'Bradebrigge' uncertain.</ogr:Notes>
      <ogr:Easting>461131</ogr:Easting>
      <ogr:Northing>118831</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.1">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>510403,411384</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>abbotesbrige</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>c. 1290</ogr:Attested>
      <ogr:Built_by>1290</ogr:Built_by>
      <ogr:Place_name>abbotesbrige, abbotisbrig</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 218</ogr:Other_ref>
      <ogr:Notes>Newsham Abbey had holdings in the parish (PNLi ii, 218).</ogr:Notes>
      <ogr:Easting>510403</ogr:Easting>
      <ogr:Northing>411384</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.2">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>448836,196914</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Abingdon</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Ock</ogr:River>
      <ogr:Attested>by 1101</ogr:Attested>
      <ogr:Built_by>1101</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 07</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>448836</ogr:Easting>
      <ogr:Northing>196914</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.3">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>442148,111844</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Acorne Bridge [lost]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>?Test or Itchen</ogr:River>
      <ogr:Attested>1227</ogr:Attested>
      <ogr:Built_by>1227</ogr:Built_by>
      <ogr:Place_name>(a) ponte Achardi</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 44</ogr:Other_ref>
      <ogr:Notes>HaPNs notes 'Robert Achard', a juror in 1248, and suggests the name was of French origin, or less likely OE Ä€cheard.</ogr:Notes>
      <ogr:Easting>442148</ogr:Easting>
      <ogr:Northing>111844</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.4">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>434940,419264</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Agbrigg (Wapentake)</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Oakenshaw Beck</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Agebrvge, Hagebrige Wapentac</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoW ii, 99 and 117; EHNs iii, 25</ogr:Other_ref>
      <ogr:Notes>The bridge was the meeting place of the wapentake; in 1286 (YI) an inquisition and in 1324 an execution was held there (PNYoW). The bridge crossed a stream called 'Aggebriggebrook' (also known as Oakenshaw Beck), an alternative name for the settlement.</ogr:Notes>
      <ogr:Easting>434940</ogr:Easting>
      <ogr:Northing>419264</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.5">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>550160,272166</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Aldreth</ogr:Location>
      <ogr:County>Ca</ogr:County>
      <ogr:River>Old West River (Great Ouse)</ogr:River>
      <ogr:Attested>11thC</ogr:Attested>
      <ogr:Built_by>1099</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>24</ogr:Harrison>
      <ogr:Jervoise>E, 103</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Possibly a causeway.</ogr:Notes>
      <ogr:Easting>550160</ogr:Easting>
      <ogr:Northing>272166</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.6">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>593796,132026</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Aloesbridge Hundred</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Adilovtesbrige, Adelovesbrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Cullen 1997, 256; KePNs, 476</ogr:Other_ref>
      <ogr:Notes>Meeting place not known (KePNs; Cullen).</ogr:Notes>
      <ogr:Easting>593796</ogr:Easting>
      <ogr:Northing>132026</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.7">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>475258,281170</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Arthingworth</ogr:Location>
      <ogr:County>Np</ogr:County>
      <ogr:River>Ise</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1150</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 73</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>475258</ogr:Easting>
      <ogr:Northing>281170</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.8">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>354037,309328</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Atcham</ogr:Location>
      <ogr:County>Sh</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>by 1221</ogr:Attested>
      <ogr:Built_by>1221</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>W, 137</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>354037</ogr:Easting>
      <ogr:Northing>309328</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.9">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>334690,129063</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Athelney</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Tone</ogr:River>
      <ogr:Attested>reign of King Alfred</ogr:Attested>
      <ogr:Built_by>900</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>42</ogr:Harrison>
      <ogr:Jervoise>S, 97</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>334690</ogr:Easting>
      <ogr:Northing>129063</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.10">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>612814,316736</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Attlebridge</ogr:Location>
      <ogr:County>Nf</ogr:County>
      <ogr:River>Wensum</ogr:River>
      <ogr:Attested>11thC</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Atebruge. Atlebruge, Attebruge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise>E, 119</ogr:Jervoise>
      <ogr:Other_ref>CDEPN 26; DEPN 18</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>612814</ogr:Easting>
      <ogr:Northing>316736</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.11">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>342901,154137</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Axbridge</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Axe</ogr:River>
      <ogr:Attested>914â€“19</ogr:Attested>
      <ogr:Built_by>919</ogr:Built_by>
      <ogr:Place_name>(to) oxenebrege, -b'igge, (to) axanbrycge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>CDEPN, 8; DEPN, 20; Mills, 26; Haslam 2014, 56-57</ogr:Other_ref>
      <ogr:Notes>Axbridge is now a far from the Axe and the bridge may be a causeway crossing the Axe levels; the River Brue previously flowed to join with the Axe east of Axbridge, making the crossing point more strategically important than it now appears (Haslam 2014).</ogr:Notes>
      <ogr:Easting>342901</ogr:Easting>
      <ogr:Northing>154137</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.12">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>521411,406447</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Aylofbrigge</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?Laceby Beck</ogr:River>
      <ogr:Attested>1240â€“53</ogr:Attested>
      <ogr:Built_by>1253</ogr:Built_by>
      <ogr:Place_name>Aylofbrigge, Nylofbrigge</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi v, 134</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>521411</ogr:Easting>
      <ogr:Northing>406447</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.13">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>353347,134588</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Baltonsborough</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Brue</ogr:River>
      <ogr:Attested>by 998</ogr:Attested>
      <ogr:Built_by>998</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 106â€’07</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>353347</ogr:Easting>
      <ogr:Northing>134588</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.14">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>375048,164340</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bath</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Avon</ogr:River>
      <ogr:Attested>1250s</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 122</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>375048</ogr:Easting>
      <ogr:Northing>164340</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.15">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>505075,249574</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bedford</ogr:Location>
      <ogr:County>Bd</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>1179x94</ogr:Attested>
      <ogr:Built_by>1194</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>24</ogr:Harrison>
      <ogr:Jervoise>E, 90â€’91</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>505075</ogr:Easting>
      <ogr:Northing>249574</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.16">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>383399,583238</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bellingham</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>North Tyne</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>60</ogr:Harrison>
      <ogr:Jervoise>N, 15</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>383399</ogr:Easting>
      <ogr:Northing>583238</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.17">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>460631,86326</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bembridge [Wt]</ogr:Location>
      <ogr:County>Wt</ogr:County>
      <ogr:River>Yar</ogr:River>
      <ogr:Attested>1316</ogr:Attested>
      <ogr:Built_by>1316</ogr:Built_by>
      <ogr:Place_name>Bynnebrygg, Cf. infra pontem</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>WtPNs, 27; WtKÃ¶, 34-35 and 62; CDEPN, 50; DEPN, 37</ogr:Other_ref>
      <ogr:Notes>A late name.  Bembridge is situated on a peninsula linked by a bridge at Yarbridge built c. 1300 (WtPNs). (Yarbridge was 'Yarnbrigge' 1462, and 'Yarneford' 1324; WtKÃ¶.) Probably known as 'Orham' in 1086 (WtPNs; see below).</ogr:Notes>
      <ogr:Easting>460631</ogr:Easting>
      <ogr:Northing>86326</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.18">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>498324,396262</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bernardesbridge</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Waddingham Beck</ogr:River>
      <ogr:Attested>1212</ogr:Attested>
      <ogr:Built_by>1212</ogr:Built_by>
      <ogr:Place_name>Bernardesbridge</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi vi, 116</ogr:Other_ref>
      <ogr:Notes>17th c. forms 'Borna brigghill' and 'Bornabrigg Hill' may be later reflexes of the name, but the development is unusual (PNLi).</ogr:Notes>
      <ogr:Easting>498324</ogr:Easting>
      <ogr:Northing>396262</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.19">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>399498,652738</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Berwick</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Tweed</ogr:River>
      <ogr:Attested>by 1199</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>83</ogr:Harrison>
      <ogr:Jervoise>N, 2</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Earlier bridge destroyed 1199.</ogr:Notes>
      <ogr:Easting>399498</ogr:Easting>
      <ogr:Northing>652738</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.20">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>539530,116224</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bevern Bridge</ogr:Location>
      <ogr:County>Sx</ogr:County>
      <ogr:River>Bevern</ogr:River>
      <ogr:Attested>1087â€“1100</ogr:Attested>
      <ogr:Built_by>1100</ogr:Built_by>
      <ogr:Place_name>pontem de Beuehorn</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNSx, 297</ogr:Other_ref>
      <ogr:Notes>First element a place-name 'Beofanhorn' 'Beofa's corner of land' (PNSx). Bevern now the stream name.</ogr:Notes>
      <ogr:Easting>539530</ogr:Easting>
      <ogr:Northing>116224</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.21">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>272589,55375</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bickham Bridge</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>Avon (Devonshire)</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Charter boundary clause evidence.</ogr:Notes>
      <ogr:Easting>272589</ogr:Easting>
      <ogr:Northing>55375</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.22">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>501023,250374</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Biddenham</ogr:Location>
      <ogr:County>Bd</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>by 1224</ogr:Attested>
      <ogr:Built_by>1224</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>24</ogr:Harrison>
      <ogr:Jervoise>E, 89</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Bridge repaired in 1224. Formerly Biddenham, also known as Bromham Bridge.</ogr:Notes>
      <ogr:Easting>501023</ogr:Easting>
      <ogr:Northing>250374</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.23">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>481471,261054</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Billing</ogr:Location>
      <ogr:County>Np</ogr:County>
      <ogr:River>Nene</ogr:River>
      <ogr:Attested>by 1243</ogr:Attested>
      <ogr:Built_by>1243</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 73</ogr:Jervoise>
      <ogr:Other_ref>RHH3/E1 ii(2), 15</ogr:Other_ref>
      <ogr:Notes>Near Northampton, with a mention of tolls collected.</ogr:Notes>
      <ogr:Easting>481471</ogr:Easting>
      <ogr:Northing>261054</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.24">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>439636,466997</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Boroughbridge</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Ure</ogr:River>
      <ogr:Attested>by 1155</ogr:Attested>
      <ogr:Built_by>1155</ogr:Built_by>
      <ogr:Place_name>pontem de Burgo</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>207</ogr:Harrison>
      <ogr:Jervoise>N, 82</ogr:Jervoise>
      <ogr:Other_ref>PNYoW v, 82â€“83; CDEPN, 70-71; DEPN, 53</ogr:Other_ref>
      <ogr:Notes>On the Old North Road/Ermine Street, with toll collection mentioned.</ogr:Notes>
      <ogr:Easting>439636</ogr:Easting>
      <ogr:Northing>466997</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.25">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>532749,344022</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Boston</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Witham</ogr:River>
      <ogr:Attested>13thC</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 60</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>532749</ogr:Easting>
      <ogr:Northing>344022</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.26">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>517212,297200</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Botolph Bridge</ogr:Location>
      <ogr:County>Hu</ogr:County>
      <ogr:River>?Nene</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Botuluesbrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNBdHu, xli, 194</ogr:Other_ref>
      <ogr:Notes>Church apparently originally dedicated to St Botolph, patron saint of wayfarers (PNBdHu).</ogr:Notes>
      <ogr:Easting>517212</ogr:Easting>
      <ogr:Northing>297200</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.27">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>537877,183087</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bow</ogr:Location>
      <ogr:County>Mx</ogr:County>
      <ogr:River>Lea</ogr:River>
      <ogr:Attested>by 1118</ogr:Attested>
      <ogr:Built_by>1118</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>111</ogr:Harrison>
      <ogr:Jervoise>E, 142â€’43</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Construction funded by Queen Matilda (1100-18). An approach road between Bow and London was probably built around the same time.</ogr:Notes>
      <ogr:Easting>537877</ogr:Easting>
      <ogr:Northing>183087</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.28">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>496603,368191</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bracebridge</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Witham</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brachebrige, Bragebbruge</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi i, 190â€“91; CDEPN, 76; DEPN, 57; LPN, 69-70; Mills, 70; Coates 2008, 44-47</ogr:Other_ref>
      <ogr:Notes>OE 'brycg', varying with ON 'bryggja' (PNLi; CDEPN 76). First element uncertain, Mills suggests a variation on OFrench 'brace[ 'arch, support', referring to the structure of the bridge and Coates ON a nominal use of ON 'brattr' 'steep'.</ogr:Notes>
      <ogr:Easting>496603</ogr:Easting>
      <ogr:Northing>368191</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.29">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>386937,271348</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bradford House and Bridge</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Elmley Brook</ogr:River>
      <ogr:Attested>1229</ogr:Attested>
      <ogr:Built_by>1229</ogr:Built_by>
      <ogr:Place_name>La Brodeford</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 236</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>386937</ogr:Easting>
      <ogr:Northing>271348</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.30">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>417668,420162</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bradley</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Colne/Calder</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1175</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 105</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Two bridges mentioned in the twelfth century across both the Colne and the Calder rivers.</ogr:Notes>
      <ogr:Easting>417668</ogr:Easting>
      <ogr:Northing>420162</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.31">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>518709,110595</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bramber</ogr:Location>
      <ogr:County>Sx</ogr:County>
      <ogr:River>Adur</ogr:River>
      <ogr:Attested>by 1230</ogr:Attested>
      <ogr:Built_by>1230</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 51</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Apparently in the thirteenth century this was a timber bridge located to the west of the stone Bramber Bridge.</ogr:Notes>
      <ogr:Easting>518709</ogr:Easting>
      <ogr:Northing>110595</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.32">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>519192,110615</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bramber</ogr:Location>
      <ogr:County>Sx</ogr:County>
      <ogr:River>Adur</ogr:River>
      <ogr:Attested>by 1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 51</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>One of two bridges by Bramber.</ogr:Notes>
      <ogr:Easting>519192</ogr:Easting>
      <ogr:Northing>110615</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.33">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>446756,122286</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brambridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Itchen</ogr:River>
      <ogr:Attested>11thC</ogr:Attested>
      <ogr:Built_by>1099</ogr:Built_by>
      <ogr:Place_name>(to) brombrygce</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 76</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>446756</ogr:Easting>
      <ogr:Northing>122286</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.34">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>409297,243815</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bretforton</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>c. 1200</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name>Bretfertona</ogr:Place_name>
      <ogr:Pn_element>bred</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 261â€“62; CDEPN 84; VEPN ii, 13-14</ogr:Other_ref>
      <ogr:Notes>PNWo interprets first element as OE 'brÄd' 'broad', CDEPN thinks oe 'bred' 'board' more likely, with later reinterpretation as OE 'brÄd'. There are several crossings that migth be the referrent.  The church is used as the grid reference here.</ogr:Notes>
      <ogr:Easting>409297</ogr:Easting>
      <ogr:Northing>243815</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.35">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>398556,268714</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridenbridge [lost]</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Worcester &amp; Birmingham Canal</ogr:River>
      <ogr:Attested>11thC</ogr:Attested>
      <ogr:Built_by>1099</ogr:Built_by>
      <ogr:Place_name>in bridenan brygge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 359â€“60</ogr:Other_ref>
      <ogr:Notes>Modern canalisation and name of the waterway.</ogr:Notes>
      <ogr:Easting>398556</ogr:Easting>
      <ogr:Northing>268714</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.36">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>618264,154230</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridge [Ke]</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>Nail Bourne</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Cullen 1997, 402; KePNs, 541; CDEPN, 85</ogr:Other_ref>
      <ogr:Notes>Where Nail Bourne crosses Watling St (M1a) (KePNs; CDEPN).</ogr:Notes>
      <ogr:Easting>618264</ogr:Easting>
      <ogr:Northing>154230</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.37">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>482808,435399</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridge Carr</ogr:Location>
      <ogr:County>YoE</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>13thC</ogr:Attested>
      <ogr:Built_by>1299</ogr:Built_by>
      <ogr:Place_name>Risebriggker, Risebrigger, Risebrigg'ker, Rysebriggker</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoE, 235</ogr:Other_ref>
      <ogr:Notes>Land there called 'le Liliclos' (Selby ii, 29 and 35).  There's a 'Lilly Wood' at SE 79664 37577.</ogr:Notes>
      <ogr:Easting>482808</ogr:Easting>
      <ogr:Northing>435399</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.38">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>365301,77720</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridge Fm [Do]</ogr:Location>
      <ogr:County>Do</ogr:County>
      <ogr:River>?causeway</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>(ad) Brigam, ?Brige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDo i, 268</ogr:Other_ref>
      <ogr:Notes>Probably preserving name of manor(s) called 'Brige' in DB; perhaps used of a crossing to Portland near Small Mouth: Leyland describes a causeway there in 16th c. (PNDo).</ogr:Notes>
      <ogr:Easting>365301</ogr:Easting>
      <ogr:Northing>77720</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.39">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>484825,153047</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridge Hill</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>?Puckridge Flash</ogr:River>
      <ogr:Attested>1287</ogr:Attested>
      <ogr:Built_by>1287</ogr:Built_by>
      <ogr:Place_name>de ponte de Cove (p)</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 108</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>484825</ogr:Easting>
      <ogr:Northing>153047</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.40">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>341260,242423</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridge Sollers</ogr:Location>
      <ogr:County>He</ogr:County>
      <ogr:River>Wye</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Bricge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>DEPN, 64; HeBann, 26; HePNs, 44; Noble 1983, 23</ogr:Other_ref>
      <ogr:Notes>NB Parish includes land north and south of Wye. See Noble for possible survival of Roman bridge at SO 44224 41231.</ogr:Notes>
      <ogr:Easting>341260</ogr:Easting>
      <ogr:Northing>242423</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.41">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>448599,129296</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridge St [Winchester]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Itchen</ogr:River>
      <ogr:Attested>1280</ogr:Attested>
      <ogr:Built_by>1280</ogr:Built_by>
      <ogr:Place_name>?in vico de Newebrigge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 10</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>448599</ogr:Easting>
      <ogr:Northing>129296</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.42">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>227483,102864</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridgerule</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>Tamar</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDe, 135â€“36; DCoPNs, 60; CDEPN, 85; DEPN, 64</ogr:Other_ref>
      <ogr:Notes>Personal name Hroaldr that of 1086 holder.</ogr:Notes>
      <ogr:Easting>227483</ogr:Easting>
      <ogr:Northing>102864</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.43">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>595774,285825</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridgham</ogr:Location>
      <ogr:County>Nf</ogr:County>
      <ogr:River>Thet</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>BrugÄ</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>CDEPN, 85; DEPN, 64</ogr:Other_ref>
      <ogr:Notes>Roman road runs down west of parish crossing River Thet at TL 94088 84080; another route crosses River Thet at TL 98896 86683 in east of parish. However, neither is close to the present settlement and it therefore impossible to decide which of the crossi</ogr:Notes>
      <ogr:Easting>595774</ogr:Easting>
      <ogr:Northing>285825</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.44">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>356525,123947</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridghampton</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Cam</ogr:River>
      <ogr:Attested>1281</ogr:Attested>
      <ogr:Built_by>1281</ogr:Built_by>
      <ogr:Place_name>Brugamton</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>DEPN, 64</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>356525</ogr:Easting>
      <ogr:Northing>123947</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.45">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>371871,293007</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridgnorth</ogr:Location>
      <ogr:County>Sh</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>by 1101</ogr:Attested>
      <ogr:Built_by>1101</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>W, 139â€’40</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>A Cuatbrucge recorded in the Anglo-Saxon Chronicle (A, s.a. 895) may refer to a bridge at Bridgnorth, in which case a bridge was in existence by teh 9th century. See PNSa (i, 56â€“59).</ogr:Notes>
      <ogr:Easting>371871</ogr:Easting>
      <ogr:Northing>293007</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.46">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>330041,137104</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bridgwater</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Parrett</ogr:River>
      <ogr:Attested>by 1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brugie</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise>S, 102â€’03</ogr:Jervoise>
      <ogr:Other_ref>CDEPN, 86; DEPN, 64; Mills, 76</ogr:Other_ref>
      <ogr:Notes>Part of the fee of Walter of Douai, said to have built a bridge across the Parrett (CDEPN).</ogr:Notes>
      <ogr:Easting>330041</ogr:Easting>
      <ogr:Northing>137104</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.47">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>513895,420059</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brigesti</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1260</ogr:Attested>
      <ogr:Built_by>1260</ogr:Built_by>
      <ogr:Place_name>Brigesti</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 155</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>513895</ogr:Easting>
      <ogr:Northing>420059</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.48">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>499857,407182</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brigg</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Ancholme</ogr:River>
      <ogr:Attested>1218</ogr:Attested>
      <ogr:Built_by>1218</ogr:Built_by>
      <ogr:Place_name>punt de Glanford</ogr:Place_name>
      <ogr:Pn_element>pont</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 56</ogr:Jervoise>
      <ogr:Other_ref>PNLi, 117â€“18; LiPNs, 86; CDEPN, 86; DEPN, 197</ogr:Other_ref>
      <ogr:Notes>Formerly the Glanford Bridge. First element influenced by ON cognate 'glaumr' (PNLi). Glanford Brigg (brycg/bryggja) in 1235.</ogr:Notes>
      <ogr:Easting>499857</ogr:Easting>
      <ogr:Northing>407182</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.49">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>511979,419180</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brigge</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Halton East Beck</ogr:River>
      <ogr:Attested>1294</ogr:Attested>
      <ogr:Built_by>1294</ogr:Built_by>
      <ogr:Place_name>del Brigge (p)</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 287</ogr:Other_ref>
      <ogr:Notes>Now a modern drain.</ogr:Notes>
      <ogr:Easting>511979</ogr:Easting>
      <ogr:Northing>419180</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.50">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>506350,454200</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brigham</ogr:Location>
      <ogr:County>YoE</ogr:County>
      <ogr:River>Hull</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>850</ogr:Built_by>
      <ogr:Place_name>Bringeha'</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>102</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoE, 90â€“91</ogr:Other_ref>
      <ogr:Notes>Remains of girder bridge over Hull found near Brigham.</ogr:Notes>
      <ogr:Easting>506350</ogr:Easting>
      <ogr:Northing>454200</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.51">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>308169,531283</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brigham [Cu]</ogr:Location>
      <ogr:County>Cu</ogr:County>
      <ogr:River>Derwent</ogr:River>
      <ogr:Attested>c. 1175</ogr:Attested>
      <ogr:Built_by>1175</ogr:Built_by>
      <ogr:Place_name>Briggham</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNCu, 355; DEPN, 64-65; CDEPN, 86</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>308169</ogr:Easting>
      <ogr:Northing>531283</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.52">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>414409,422564</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brighouse</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Calder</ogr:River>
      <ogr:Attested>1240</ogr:Attested>
      <ogr:Built_by>1240</ogr:Built_by>
      <ogr:Place_name>Brig(g)huses</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoW iii, 76; CDEPN, 86; DEPN, 65</ogr:Other_ref>
      <ogr:Notes>The Brig- form is due to ON influence by sound substitution, and is not from a ON 'bryggja' 'quay, jetty'; this was an ancient crossing of the River Calder (PNYoW).</ogr:Notes>
      <ogr:Easting>414409</ogr:Easting>
      <ogr:Northing>422564</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.53">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>525217,401696</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brigsley</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Waithe Beck</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brigeslai</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi iv, 60â€“62; DEPN, 65; CDEPN, 87</ogr:Other_ref>
      <ogr:Notes>Bridge suggested to be that over Waithe Beck by PNLi.</ogr:Notes>
      <ogr:Easting>525217</ogr:Easting>
      <ogr:Northing>401696</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.54">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>359000,172905</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bristol</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>Avon</ogr:River>
      <ogr:Attested>1009x17</ogr:Attested>
      <ogr:Built_by>1017</ogr:Built_by>
      <ogr:Place_name>BRIC</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise>S, 125</ogr:Jervoise>
      <ogr:Other_ref>AS Mint-Names, 42â€“46;  PNGl iii, 83-4, 87</ogr:Other_ref>
      <ogr:Notes>This is the location of Bristol Bridge which the survey volume suggests might have been the original bridge site. Several more occurences in eleventh century as a mint signature. Stone bridge in existence in 1215.</ogr:Notes>
      <ogr:Easting>359000</ogr:Easting>
      <ogr:Northing>172905</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.55">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>292691,125846</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brushford</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>Barle</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brige-, Brucheford</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>CDEPN, 95; DEPN, 71; Mills, 82</ogr:Other_ref>
      <ogr:Notes>Development may be due to folk etymological reinterpretation, brushwood being frequently used for causeways.</ogr:Notes>
      <ogr:Easting>292691</ogr:Easting>
      <ogr:Northing>125846</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.56">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>267628,107172</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Brushford</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>Taw</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brisforda, Brigeforda</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDe ii, 361; CDEPN, 95; DEPN, 71</ogr:Other_ref>
      <ogr:Notes>Original form must have been Bridgeford, i.e. ford with some kind of causeway laid across it; later, perhaps owing to the frequent use of brushwood causeways (cf. Rice Bridge, PN Sx 258), folk- etymology seems to have been at work (PNDe).</ogr:Notes>
      <ogr:Easting>267628</ogr:Easting>
      <ogr:Northing>107172</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.57">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>633789,289964</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bungay</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>Waveney</ogr:River>
      <ogr:Attested>by 1240</ogr:Attested>
      <ogr:Built_by>1240</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 123</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>633789</ogr:Easting>
      <ogr:Northing>289964</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.58">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>425530,323288</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Burton on Trent</ogr:Location>
      <ogr:County>St</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 5</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Discussion: H. Rye, 'The Great Bridge of Burton-on-Trent', Burton-on-Trent Natural History and Archaeological Society, 5.1 (1903), 4-21.</ogr:Notes>
      <ogr:Easting>425530</ogr:Easting>
      <ogr:Northing>323288</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.59">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>585815,264381</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Bury St Edmunds</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>Lark</ogr:River>
      <ogr:Attested>by 1230</ogr:Attested>
      <ogr:Built_by>1230</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 109</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Uncertain date.</ogr:Notes>
      <ogr:Easting>585815</ogr:Easting>
      <ogr:Northing>264381</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.60">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>442228,106606</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Butts Bridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>1280</ogr:Attested>
      <ogr:Built_by>1280</ogr:Built_by>
      <ogr:Place_name>Buttebrigg</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 198; HaCoates, 46</ogr:Other_ref>
      <ogr:Notes>HaPNs notes a William 'le But' in the parish in 1327 and suggests the first element refers to one of his ancestors.</ogr:Notes>
      <ogr:Easting>442228</ogr:Easting>
      <ogr:Northing>106606</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.61">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>544604,258987</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cambridge</ogr:Location>
      <ogr:County>Ca</ogr:County>
      <ogr:River>Cam</ogr:River>
      <ogr:Attested>9thC</ogr:Attested>
      <ogr:Built_by>800</ogr:Built_by>
      <ogr:Place_name>grontabricc</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 104â€’05</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Magdalen Bridge, formerly the Great Bridge. Attested in a 9th-century manuscript of the Life of St Guthlac, thought to have been written in the 8th century</ogr:Notes>
      <ogr:Easting>544604</ogr:Easting>
      <ogr:Northing>258987</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.62">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>340072,556563</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Carlisle</ogr:Location>
      <ogr:County>Cu</ogr:County>
      <ogr:River>Eden</ogr:River>
      <ogr:Attested>by 1200</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>N, 118â€’19</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>340072</ogr:Easting>
      <ogr:Northing>556563</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.63">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>443002,425987</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Castleford</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Aire</ogr:River>
      <ogr:Attested>10thC</ogr:Attested>
      <ogr:Built_by>999</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>34</ogr:Harrison>
      <ogr:Jervoise>N, 102</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Placename evidence for a bridge.</ogr:Notes>
      <ogr:Easting>443002</ogr:Easting>
      <ogr:Northing>425987</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.64">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>609928,232709</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cattawade</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>Stour (Suffolk)</ogr:River>
      <ogr:Attested>by 1256</ogr:Attested>
      <ogr:Built_by>1256</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 128â€’29</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Repaired in 1256.</ogr:Notes>
      <ogr:Easting>609928</ogr:Easting>
      <ogr:Northing>232709</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.65">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>471131,174632</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Caversham/Reading</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1231</ogr:Attested>
      <ogr:Built_by>1231</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 10</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>A ferry was also in operation. Reading had become the main settlement west of London by ninth to tenth centuries, being well located at the conjunction of the Thames and the Kennet.</ogr:Notes>
      <ogr:Easting>471131</ogr:Easting>
      <ogr:Northing>174632</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.66">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>509049,421026</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cf. Butforth Drain, -Lane</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1216â€“72</ogr:Attested>
      <ogr:Built_by>1272</ogr:Built_by>
      <ogr:Place_name>ad pontem de Budeford</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 18</ogr:Other_ref>
      <ogr:Notes>Butforth Lane doesn't now cross a watercourse.</ogr:Notes>
      <ogr:Easting>509049</ogr:Easting>
      <ogr:Northing>421026</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.67">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>490815,429209</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cf. Croft House</ogr:Location>
      <ogr:County>YoE</ogr:County>
      <ogr:River>Mill Beck</ogr:River>
      <ogr:Attested>1154</ogr:Attested>
      <ogr:Built_by>1154</ogr:Built_by>
      <ogr:Place_name>Brigg'croft, Croft</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoE, 225</ogr:Other_ref>
      <ogr:Notes>Location may not be accurate for 12th c. name.</ogr:Notes>
      <ogr:Easting>490815</ogr:Easting>
      <ogr:Northing>429209</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.68">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>393816,260400</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cf. Dean Brook</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Dean Brook</ogr:River>
      <ogr:Attested>1275</ogr:Attested>
      <ogr:Built_by>1275</ogr:Built_by>
      <ogr:Place_name>Denebrigge, pontem de la Dene</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 136</ogr:Other_ref>
      <ogr:Notes>Presumably located somewhere along the Dean Brook, i.e. the northern bounday of the parish. PNWo is not sure that the valley is well-marked enought to be a 'denu'.</ogr:Notes>
      <ogr:Easting>393816</ogr:Easting>
      <ogr:Northing>260400</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.69">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>435284,122908</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>cf. Great Bridge?</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Test</ogr:River>
      <ogr:Attested>1154â€“89</ogr:Attested>
      <ogr:Built_by>1289</ogr:Built_by>
      <ogr:Place_name>pons de Bradebrigge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 185</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>435284</ogr:Easting>
      <ogr:Northing>122908</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.70">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>438930,140986</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cf. Knight Fd</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Test</ogr:River>
      <ogr:Attested>13th</ogr:Attested>
      <ogr:Built_by>1299</ogr:Built_by>
      <ogr:Place_name>Cnythtebrigge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 256</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>438930</ogr:Easting>
      <ogr:Northing>140986</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.71">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>519503,411852</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cf. Long Bridge (1896) [2]</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1155â€“89</ogr:Attested>
      <ogr:Built_by>1189</ogr:Built_by>
      <ogr:Place_name>Briggedik, iuxta pontem</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 273</ogr:Other_ref>
      <ogr:Notes>PNLi does not link the Latin and English forms below.</ogr:Notes>
      <ogr:Easting>519503</ogr:Easting>
      <ogr:Northing>411852</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.72">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>366294,212018</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Chapmonebrugge</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1282</ogr:Attested>
      <ogr:Built_by>1282</ogr:Built_by>
      <ogr:Place_name>Chapmonebrugge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNGl ii, 224</ogr:Other_ref>
      <ogr:Notes>Place-name (English) Bicknor; parish enormous so unclear where this is.</ogr:Notes>
      <ogr:Easting>366294</ogr:Easting>
      <ogr:Northing>212018</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.73">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>340620,365780</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Chester</ogr:Location>
      <ogr:County>Ch</ogr:County>
      <ogr:River>Dee</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>W, 25â€’26</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Old Dee Bridge. Domesday Book mentions the bridge was being repaired in the eleventh century.</ogr:Notes>
      <ogr:Easting>340620</ogr:Easting>
      <ogr:Northing>365780</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.74">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>398869,564179</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Corbridge</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>South Tyne</ogr:River>
      <ogr:Attested>built 1235</ogr:Attested>
      <ogr:Built_by>1235</ogr:Built_by>
      <ogr:Place_name>Corebricg</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 23</ogr:Jervoise>
      <ogr:Other_ref>CDEPN, 157; DEPN, 122; NbDuPNs, 52â€’54</ogr:Other_ref>
      <ogr:Notes>First element (a shortned form of) Roman 'Corstopitum', with dissimiation of /r - r/ to /l - r/ in some forms. Originally Roman bridge at NY 98017 64624, place-name attested c. 1040.</ogr:Notes>
      <ogr:Easting>398869</ogr:Easting>
      <ogr:Northing>564179</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.75">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>396865,283327</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cornbow</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Stour (Warwickshire)</ogr:River>
      <ogr:Attested>1297</ogr:Attested>
      <ogr:Built_by>1297</ogr:Built_by>
      <ogr:Place_name>Cornbowe</ogr:Place_name>
      <ogr:Pn_element>boga</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 293</ogr:Other_ref>
      <ogr:Notes>PNWo suggests this is a reference to a bridge.</ogr:Notes>
      <ogr:Easting>396865</ogr:Easting>
      <ogr:Northing>283327</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.76">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>284608,101149</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Creedy Bridge</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>Creedy</ogr:River>
      <ogr:Attested>997</ogr:Attested>
      <ogr:Built_by>997</ogr:Built_by>
      <ogr:Place_name>(oÃ°) crydian bricge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDe ii, 405; CDEPN, 405</ogr:Other_ref>
      <ogr:Notes>Charter boundary clause evidence.</ogr:Notes>
      <ogr:Easting>284608</ogr:Easting>
      <ogr:Northing>101149</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.77">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>480880,361220</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Cromwell</ogr:Location>
      <ogr:County>Nt</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>early 8thC/9th C</ogr:Attested>
      <ogr:Built_by>825</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Baker and Brookes 2013, 162; Salisbury 1995</ogr:Other_ref>
      <ogr:Notes>Sapwood dendrochronologically dated to 693 but bridge could have been built later using mature wood (Baker and Brookes 2013). Discussion: C. Salisbury, 'An 8th-Century Mercian Bridge over the Trent at Cromwell, Nottinghamshire, England', Antiquity 69 (19</ogr:Notes>
      <ogr:Easting>480880</ogr:Easting>
      <ogr:Northing>361220</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.78">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>452764,111789</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Curbridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Curbridge Creek</ogr:River>
      <ogr:Attested>1236</ogr:Attested>
      <ogr:Built_by>1236</ogr:Built_by>
      <ogr:Place_name>Kernebrugge (p)</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 32; HaCoates, 62; CDEPN, 175</ogr:Other_ref>
      <ogr:Notes>Gover thinks this is 'bridge by a 'cweorn' or hand mill'; Coates, seeing a genitive plural, thinks this unlikely, and suggests 'bridge [made] of quernstones', but only tentatively. CDEPN suggests 'bridge made or supported by quernstones'.</ogr:Notes>
      <ogr:Easting>452764</ogr:Easting>
      <ogr:Northing>111789</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.79">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>433240,207120</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Curbridge [Ox]</ogr:Location>
      <ogr:County>Ox</ogr:County>
      <ogr:River>minor stream</ogr:River>
      <ogr:Attested>956â€“57</ogr:Attested>
      <ogr:Built_by>957</ogr:Built_by>
      <ogr:Place_name>(Ã¦t) Crydan brigce</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNOx ii, 315; DEPN, 136; Blair and Millard 1992.</ogr:Other_ref>
      <ogr:Notes>Near Ducklington.</ogr:Notes>
      <ogr:Easting>433240</ogr:Easting>
      <ogr:Northing>207120</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.80">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>457094,403614</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Doncaster</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Don</ogr:River>
      <ogr:Attested>by 1230s</ogr:Attested>
      <ogr:Built_by>1239</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>112</ogr:Harrison>
      <ogr:Jervoise>N, 110</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>In the 1230s the men of Doncaster received permission to collect a toll on their bridge for the purposes of rebuilding it in stone.</ogr:Notes>
      <ogr:Easting>457094</ogr:Easting>
      <ogr:Northing>403614</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.81">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>410590,334427</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Doveridge</ogr:Location>
      <ogr:County>Db</ogr:County>
      <ogr:River>Dove</ogr:River>
      <ogr:Attested>by 1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Dub(b)rig(e), Dub (b)rigge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise>E, 20</ogr:Jervoise>
      <ogr:Other_ref>PNDb iii, 549â€“50; DEPN, 149; CDEPN, 193</ogr:Other_ref>
      <ogr:Notes>Called Dubridge in Domesday Book.</ogr:Notes>
      <ogr:Easting>410590</ogr:Easting>
      <ogr:Northing>334427</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.82">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>431839,126251</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Dunbridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Dun</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Denebrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 188 and 190; HaCoates, 67-68</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>431839</ogr:Easting>
      <ogr:Northing>126251</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.83">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>427443,542431</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Durham</ogr:Location>
      <ogr:County>Du</ogr:County>
      <ogr:River>Wear</ogr:River>
      <ogr:Attested>1099x1128</ogr:Attested>
      <ogr:Built_by>1128</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 40</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>The first stone bridge in Durham was the Old Bridge, built by the bishop. The Elvet Bridge (coordinates used) was erected in 1153x95.</ogr:Notes>
      <ogr:Easting>427443</ogr:Easting>
      <ogr:Northing>542431</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.84">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>547296,211759</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Ealing Bridge</ogr:Location>
      <ogr:County>Ex</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1043â€“45</ogr:Attested>
      <ogr:Built_by>1045</ogr:Built_by>
      <ogr:Place_name>Gildenebrigge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNEx, 37</ogr:Other_ref>
      <ogr:Notes>Probably 'Guildsmens bridge'.</ogr:Notes>
      <ogr:Easting>547296</ogr:Easting>
      <ogr:Northing>211759</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.85">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>479774,149788</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>East Bridge [Crondall, Ha]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>1272</ogr:Attested>
      <ogr:Built_by>1272</ogr:Built_by>
      <ogr:Place_name>Echebrigge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 108</ogr:Other_ref>
      <ogr:Notes>On the stream flowing from Itchel House, but lack of &lt;l&gt; in earliest spellings means derivation from this name uncertain.</ogr:Notes>
      <ogr:Easting>479774</ogr:Easting>
      <ogr:Northing>149788</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.86">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>468077,343698</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>East Bridgford</ogr:Location>
      <ogr:County>Nt</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Brugeford(e)</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>CDEPN, 85; PNNt, 222</ogr:Other_ref>
      <ogr:Notes>Must have replaced the ancient ford at early date. Settlement at SK 69137 43136, with grid ref to Gunthorpe Bridge (EW). Affix distinguishes it from West Bridgford at SK 58129 38236 (Trent Bridge), SK 58717 37500 (settlement), in Newark South Division.</ogr:Notes>
      <ogr:Easting>468077</ogr:Easting>
      <ogr:Northing>343698</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.87">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>645280,266374</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Eastbridge</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>?Minsmere</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>?Briges, Bringas</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Baron, 37 and 47; CDEPN, 203</ogr:Other_ref>
      <ogr:Notes>Baron identifies with Bridge Fm in Dunwich, but Bridge in Blythburghis also a possibility. At Eastbridge is a crossing over the Minsmere River, although 'the plural DB form may indicated the existence of more than one crossing' (SfPNs 46).</ogr:Notes>
      <ogr:Easting>645280</ogr:Easting>
      <ogr:Northing>266374</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.88">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>614580,158095</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Eastbridge (Hospital)</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>Great Stour</ogr:River>
      <ogr:Attested>c. 1200</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name>Eastbrege</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Cullen 1997, 564; KePNs, 606</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>614580</ogr:Easting>
      <ogr:Northing>158095</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.89">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>607548,132168</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Eastbridge [Ke]</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Estbrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Cullen 1997, 220; KePNs, 463</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>607548</ogr:Easting>
      <ogr:Northing>132168</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.90">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>544429,145963</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Edenbridge</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>Eden</ogr:River>
      <ogr:Attested>c. 1100</ogr:Attested>
      <ogr:Built_by>1100</ogr:Built_by>
      <ogr:Place_name>Eadelmesbrege</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>KePNs, 73; KPN, 73; CDEPN, 208</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>544429</ogr:Easting>
      <ogr:Northing>145963</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.91">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>426836,327095</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Egginton</ogr:Location>
      <ogr:County>Db</ogr:County>
      <ogr:River>Dove</ogr:River>
      <ogr:Attested>by 1256</ogr:Attested>
      <ogr:Built_by>1256</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 22</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>On Ryknild Street, repaired in 1256.</ogr:Notes>
      <ogr:Easting>426836</ogr:Easting>
      <ogr:Northing>327095</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.92">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>491232,102124</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Elbridge [Sx]</ogr:Location>
      <ogr:County>Sx</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>985</ogr:Attested>
      <ogr:Built_by>985</ogr:Built_by>
      <ogr:Place_name>Ã¾elbrycg</ogr:Place_name>
      <ogr:Pn_element>brycg, Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNSx, 91</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>491232</ogr:Easting>
      <ogr:Northing>102124</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.93">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>620358,159618</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Elbridge Fm &amp; House</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>Lampen Stream</ogr:River>
      <ogr:Attested>948</ogr:Attested>
      <ogr:Built_by>948</ogr:Built_by>
      <ogr:Place_name>Ã¾Ã¦l brycge</ogr:Place_name>
      <ogr:Pn_element>brycg, Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Cullen 1997, 365; KPN, 277-78</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>620358</ogr:Easting>
      <ogr:Northing>159618</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.94">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>514953,167854</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Elmbridge Hundred</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Ember</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Amelebrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNSr, 86â€“87; EHNs iii, 60â€“61</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>514953</ogr:Easting>
      <ogr:Northing>167854</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.95">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>490542,143801</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Elstead</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Wey</ogr:River>
      <ogr:Attested>13thC; probably post 1233</ogr:Attested>
      <ogr:Built_by>1233</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 22â€’23</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Jervoise identifies six bridges over the Wey with an identical design. He suggests they were all constructed after the 1233 flood when many bridges in the district were damaged.</ogr:Notes>
      <ogr:Easting>490542</ogr:Easting>
      <ogr:Northing>143801</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.96">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>291656,92164</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Exeter</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>Exe</ogr:River>
      <ogr:Attested>1190x1200</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HE scheduled ancient monument: https://historicengland.org.uk/listing/the-list/list-entry/1020671</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>291656</ogr:Easting>
      <ogr:Northing>92164</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.97">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>585320,196539</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Fambridge (North and South)</ogr:Location>
      <ogr:County>Ex</ogr:County>
      <ogr:River>?connected to Crouch</ogr:River>
      <ogr:Attested>1017-35</ogr:Attested>
      <ogr:Built_by>1035</ogr:Built_by>
      <ogr:Place_name>Fanbrege</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNEx, 214â€“15; CDEPN, 224; DEPN, 173</ogr:Other_ref>
      <ogr:Notes>North and south of the River Crouch.</ogr:Notes>
      <ogr:Easting>585320</ogr:Easting>
      <ogr:Northing>196539</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.98">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>619761,339011</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Felbrigg</ogr:Location>
      <ogr:County>Nf</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Felebruge</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNNf iii, 14; DEPN, 177; Mills, 187; CDEPN, 227</ogr:Other_ref>
      <ogr:Notes>Ekwall suggests ON compound he translates as 'plank bridge' (DEPN 177), but PNNf points out that ON 'bryggja' was not used itself of a bridge, but normally denoted a jetty/quay. Hybrid name, with the second element influenced from OE 'brycg'? (Mills 187)</ogr:Notes>
      <ogr:Easting>619761</ogr:Easting>
      <ogr:Northing>339011</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.99">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>385885,267969</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Felgate [lost]</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1275</ogr:Attested>
      <ogr:Built_by>1275</ogr:Built_by>
      <ogr:Place_name>Felegate</ogr:Place_name>
      <ogr:Pn_element>Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 241</ogr:Other_ref>
      <ogr:Notes>This may survive as the TA names Fieldgates, Field Gates Piece (ER).</ogr:Notes>
      <ogr:Easting>385885</ogr:Easting>
      <ogr:Northing>267969</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.100">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>418526,600320</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Felton</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Coquet</ogr:River>
      <ogr:Attested>beginning of 13thC</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 8</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>418526</ogr:Easting>
      <ogr:Northing>600320</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.101">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>448310,424631</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Ferrybridge</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Aire</ogr:River>
      <ogr:Attested>by 1228</ogr:Attested>
      <ogr:Built_by>1228</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>208</ogr:Harrison>
      <ogr:Jervoise>N, 102</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>A very important bridge on the Old North Road/Ermine Street, with toll collection. The bridge was there by the end of the twelfth century. Called 'Ferie' in Domesday Book of 1086.</ogr:Notes>
      <ogr:Easting>448310</ogr:Easting>
      <ogr:Northing>424631</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.102">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>500950,118278</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Fittleworth</ogr:Location>
      <ogr:County>Sx</ogr:County>
      <ogr:River>Rother</ogr:River>
      <ogr:Attested>by 1199</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 56</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>500950</ogr:Easting>
      <ogr:Northing>118278</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.103">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>414936,114210</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Fordingbridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Avon</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Fordingebrige Hund', Forde</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 75</ogr:Jervoise>
      <ogr:Other_ref>HaPNs, 211 and 213â€“14; HaCoates, 78; DEPN, 184; CDEPN 236</ogr:Other_ref>
      <ogr:Notes>Hundred name. Two names: OE 'ford' and OE 'fordingabrycg' 'bridge of the dwellers by the ford' (HaPNs). In 1252 pontage was granted for the repair of the bridge.</ogr:Notes>
      <ogr:Easting>414936</ogr:Easting>
      <ogr:Northing>114210</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.104">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>427521,468355</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Fountains Abbey</ogr:Location>
      <ogr:County>YoN</ogr:County>
      <ogr:River>Ouse</ogr:River>
      <ogr:Attested>built c. 1147</ogr:Attested>
      <ogr:Built_by>1147</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 81</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Two bridges. The first was certainly built c. 1147, and a second one to the west was probably constructed in the thirteenth century.</ogr:Notes>
      <ogr:Easting>427521</ogr:Easting>
      <ogr:Northing>468355</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.105">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>561208,318575</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Freebridge Hundred</ogr:Location>
      <ogr:County>Nf</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Fredebrvge H' et dim', H' et dim' de Fredrebruge, H' de Fridrebruge, Fredreburge  H' et dim', H' et dim' de Fredrebruga, Fridebruge H'</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>EHNs i, 64â€“65; CDEPN, 240</ogr:Other_ref>
      <ogr:Notes>First element may be a personal name ON 'FrÃ¦Ã°i' or perhaps OE 'friÃ°, freoÃ°u' 'refuge, protection'. Anderson (EHNs) wonders about OE 'fyrhÃ°' 'a wood' and notes Frith Fields in Tilney All Saints.</ogr:Notes>
      <ogr:Easting>561208</ogr:Easting>
      <ogr:Northing>318575</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.106">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>532763,397121</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Fulstow Bridge [lost]</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>?1277</ogr:Attested>
      <ogr:Built_by>1277</ogr:Built_by>
      <ogr:Place_name>atte brigge (p)</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi iv, 82</ogr:Other_ref>
      <ogr:Notes>No evidence to indicate which bridge the forms refer to (PNLi).</ogr:Notes>
      <ogr:Easting>532763</ogr:Easting>
      <ogr:Northing>397121</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.107">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>382430,219070</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Gloucester</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>by 1200</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>W, 152</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>There were probabably several bridges in existence by this date. A charter in 1220 grants land &quot;between the bridges of Gloucester&quot;.</ogr:Notes>
      <ogr:Easting>382430</ogr:Easting>
      <ogr:Northing>219070</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.108">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>388358,326946</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Great Bridgeford</ogr:Location>
      <ogr:County>St</ogr:County>
      <ogr:River>Sow</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Bridgford</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>CDEPN, 85; DEPN, 64; StPNs, 148</ogr:Other_ref>
      <ogr:Notes>'The ford with a (foot-)bridge' or 'by a bridge' (CDEPN).</ogr:Notes>
      <ogr:Easting>388358</ogr:Easting>
      <ogr:Northing>326946</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.109">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>589887,191642</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Great Stambridge</ogr:Location>
      <ogr:County>Ex</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Stanbruge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNEx, 202; CDEPN, 568; DEPN, 436</ogr:Other_ref>
      <ogr:Notes>A collection of small settlements on the outskirts of Rochford.</ogr:Notes>
      <ogr:Easting>589887</ogr:Easting>
      <ogr:Northing>191642</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.110">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>531654,400850</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hakebrigam</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?unknown</ogr:River>
      <ogr:Attested>1154â€“89</ogr:Attested>
      <ogr:Built_by>1189</ogr:Built_by>
      <ogr:Place_name>Hakebrigam</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi v, 163</ogr:Other_ref>
      <ogr:Notes>1st element unglossed in PNLi.</ogr:Notes>
      <ogr:Easting>531654</ogr:Easting>
      <ogr:Northing>400850</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.111">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>615089,244592</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Handford Bridge</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>Gipping</ogr:River>
      <ogr:Attested>970</ogr:Attested>
      <ogr:Built_by>970</ogr:Built_by>
      <ogr:Place_name>Hageneforda brygge, Hagenefordabrycge, Hagenefordabricge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>SfPNs, 64; Blake 1962, xxxiv and 113</ogr:Other_ref>
      <ogr:Notes>Alternatively OE 'haga' 'enclosure, hedge' in genitive plural 'hagena' (SfPNs).</ogr:Notes>
      <ogr:Easting>615089</ogr:Easting>
      <ogr:Northing>244592</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.112">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>414546,110044</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Harbridge [Ha]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>?Avon or minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Herdebrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 219; HaCoates, 86; DEPN, 218</ogr:Other_ref>
      <ogr:Notes>HaPNs suggests alternatively an '-ingas' name, but this seems unnecessary given the infrequency of forms with medial &lt;-ing-&gt;.</ogr:Notes>
      <ogr:Easting>414546</ogr:Easting>
      <ogr:Northing>110044</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.113">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>495552,256530</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Harrold</ogr:Location>
      <ogr:County>Bd</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>by 1136x46</ogr:Attested>
      <ogr:Built_by>1146</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>E, 87</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>495552</ogr:Easting>
      <ogr:Northing>256530</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.114">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>424276,579977</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hartford</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Blyth</ogr:River>
      <ogr:Attested>by 1201</ogr:Attested>
      <ogr:Built_by>1201</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 13</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>424276</ogr:Easting>
      <ogr:Northing>579977</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.115">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>390696,249136</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hawbridge</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>13thC</ogr:Attested>
      <ogr:Built_by>1299</ogr:Built_by>
      <ogr:Place_name>Haubruggestrete</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 167</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>390696</ogr:Easting>
      <ogr:Northing>249136</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.116">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>399091,427095</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hebden Bridge</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Hebden</ogr:River>
      <ogr:Attested>1399</ogr:Attested>
      <ogr:Built_by>1399</ogr:Built_by>
      <ogr:Place_name>Hepdenbryge, Hepdenbrigg(e), Hepden Brig</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoW iii, 188; DEPN, 230; CDEPN, 293</ogr:Other_ref>
      <ogr:Notes>The bridge across Hebden water'.  Narrow bridge crossing the river at the upper end of Bridge Gate (PNYoW). Main variants Hepton and Hebden due respectively to progressive and retrogressive assimilation to the unvoiced /p/ and the voiced /d/ (PNYoW).</ogr:Notes>
      <ogr:Easting>399091</ogr:Easting>
      <ogr:Northing>427095</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.117">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>446200,330500</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hemington</ogr:Location>
      <ogr:County>Le</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>c.1000</ogr:Attested>
      <ogr:Built_by>1000</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Ripper and Cooper 2009</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>446200</ogr:Easting>
      <ogr:Northing>330500</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.118">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>476361,182642</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Henley</ogr:Location>
      <ogr:County>Ox</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1250</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>64</ogr:Harrison>
      <ogr:Jervoise>S, 10â€’11</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>476361</ogr:Easting>
      <ogr:Northing>182642</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.119">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>350813,239580</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hereford</ogr:Location>
      <ogr:County>He</ogr:County>
      <ogr:River>Wye</ogr:River>
      <ogr:Attested>by 1127</ogr:Attested>
      <ogr:Built_by>1127</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>37</ogr:Harrison>
      <ogr:Jervoise>W, 115</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Probably already in the eight century. For discussion on twelfth century bridge: J. Hillaby, 'Bishop Richard de Capella and the foundation of Herefordshire's market towns' in Essays in honour of Jim and Muriel Tonkin, ed. R. Lowe (Hereford, 2011).</ogr:Notes>
      <ogr:Easting>350813</ogr:Easting>
      <ogr:Northing>239580</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.120">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>517150,335671</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Holland causeway</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>modern South Forty Foot Drain / Hammond Beck</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>106</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Long embanked road from Donnington to Bridge End, enroute from Nottingham/Grantham to Boston. Mentioned in the 'History of William Marshall'.</ogr:Notes>
      <ogr:Easting>517150</ogr:Easting>
      <ogr:Northing>335671</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.121">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>515495,414312</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>hordberg'</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?unknown</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name>hordberg', yorthbrighe</ogr:Place_name>
      <ogr:Pn_element>eorÃ°-brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 145; Coates 2009, 94</ogr:Other_ref>
      <ogr:Notes>Uncertain, forms varied.  The second element seems to be OE/ON 'brycg/bryggja' in all but one form, which is amongst the earliest but contemporaneous with a 'brycg/bryggja' form. Coates (2009, 94) notes that OE '-burh' cannot be excluded as the generic.</ogr:Notes>
      <ogr:Easting>515495</ogr:Easting>
      <ogr:Northing>414312</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.122">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>434470,130515</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Horsebridge [Ha]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Test</ogr:River>
      <ogr:Attested>1236</ogr:Attested>
      <ogr:Built_by>1236</ogr:Built_by>
      <ogr:Place_name>Hosebrig'</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 185</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>434470</ogr:Easting>
      <ogr:Northing>130515</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.123">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>505535,441714</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hull Bridge</ogr:Location>
      <ogr:County>YoE</ogr:County>
      <ogr:River>Hull</ogr:River>
      <ogr:Attested>c. 1120</ogr:Attested>
      <ogr:Built_by>1120</ogr:Built_by>
      <ogr:Place_name>Ulbrigg</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoE, 202</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>505535</ogr:Easting>
      <ogr:Northing>441714</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.124">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>433876,168748</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Hungerford</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Kennet</ogr:River>
      <ogr:Attested>by 1241</ogr:Attested>
      <ogr:Built_by>1241</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 19</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>433876</ogr:Easting>
      <ogr:Northing>168748</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.125">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>524288,271469</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Huntingdon</ogr:Location>
      <ogr:County>Hu</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>1194</ogr:Attested>
      <ogr:Built_by>1194</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>24</ogr:Harrison>
      <ogr:Jervoise>E, 98</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Uncertain date, but the bridge was certainly in existence by mid-thirteenth century.</ogr:Notes>
      <ogr:Easting>524288</ogr:Easting>
      <ogr:Northing>271469</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.126">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>413782,93579</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Iford</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Stour (Dorset)</ogr:River>
      <ogr:Attested>1100â€“35</ogr:Attested>
      <ogr:Built_by>1135</ogr:Built_by>
      <ogr:Place_name>(pontem de) Huver, Hufvre</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 231; HaCoates, 173-74</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>413782</ogr:Easting>
      <ogr:Northing>93579</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.127">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>361083,313789</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Isombridge</ogr:Location>
      <ogr:County>Sh</ogr:County>
      <ogr:River>Tern</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Asnebrugge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNSh i, 164; PNSh vi, 173; DEPN, 267</ogr:Other_ref>
      <ogr:Notes>'Bridge of the servants'. 'The bridge was probably on the R. Roden, between Isombridge and Allscott' (PNSh i ).</ogr:Notes>
      <ogr:Easting>361083</ogr:Easting>
      <ogr:Northing>313789</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.128">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>521370,396189</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>iuxta pontem [Swinhope]</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?unknown</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name>iuxta pontem</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi vi, 164</ogr:Other_ref>
      <ogr:Notes>Have used crossing between church and manor house here; alternatively  perhaps TF 21208 95852, where the surviving road to Brookenby now crosses the river.</ogr:Notes>
      <ogr:Easting>521370</ogr:Easting>
      <ogr:Northing>396189</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.129">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>400362,99855</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Julian's Bridge</ogr:Location>
      <ogr:County>Do</ogr:County>
      <ogr:River>Stour (Dorset)</ogr:River>
      <ogr:Attested>by 1216</ogr:Attested>
      <ogr:Built_by>1216</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 82â€’83</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>400362</ogr:Easting>
      <ogr:Northing>99855</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.130">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>477597,355665</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Kelham</ogr:Location>
      <ogr:County>Nt</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>by 1225</ogr:Attested>
      <ogr:Built_by>1225</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 14</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>477597</ogr:Easting>
      <ogr:Northing>355665</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.131">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>514069,419668</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Kettlebridge Lane</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>c. 1260</ogr:Attested>
      <ogr:Built_by>1260</ogr:Built_by>
      <ogr:Place_name>Ketelbrige</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 153</ogr:Other_ref>
      <ogr:Notes>This is location of Kettlebridge Lane today.</ogr:Notes>
      <ogr:Easting>514069</ogr:Easting>
      <ogr:Northing>419668</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.132">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>432935,125595</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Kimbridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Test</ogr:River>
      <ogr:Attested>1202</ogr:Attested>
      <ogr:Built_by>1202</ogr:Built_by>
      <ogr:Place_name>Kinbrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 190; HaCoates, 103</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>432935</ogr:Easting>
      <ogr:Northing>125595</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.133">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>355090,132638</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Kinewards Bridge (now Tootle Bridge)</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Brue</ogr:River>
      <ogr:Attested>by 1135</ogr:Attested>
      <ogr:Built_by>1135</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 106</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>355090</ogr:Easting>
      <ogr:Northing>132638</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.134">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>273449,44171</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Kingsbridge</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>Kingsbridge Estuary</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name>cinges bricge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDe, 305; CDEPN, 346; DEPN, 277</ogr:Other_ref>
      <ogr:Notes>Charter boundary clause evidence (S 704); apparently of 10th-century date, but possibly an 11th-century forgery.</ogr:Notes>
      <ogr:Easting>273449</ogr:Easting>
      <ogr:Northing>44171</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.135">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>405658,177460</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Kingsbridge Hundred [Wi]</ogr:Location>
      <ogr:County>Wi</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Chinbrige, Chingbrigge hundred</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWi, 265; EHNs ii, 162-63</ogr:Other_ref>
      <ogr:Notes>Location as given in PNWi. OE 'cyne' 'royal' replaced by 'cyning' 'king' in later forms (EHNs).</ogr:Notes>
      <ogr:Easting>405658</ogr:Easting>
      <ogr:Northing>177460</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.136">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>517705,169426</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Kingston</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1219</ogr:Attested>
      <ogr:Built_by>1219</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 15</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>517705</ogr:Easting>
      <ogr:Northing>169426</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.137">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>450673,163414</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Knights Bridge [Ecchinswell, Ha]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Enborne</ogr:River>
      <ogr:Attested>1208</ogr:Attested>
      <ogr:Built_by>1208</ogr:Built_by>
      <ogr:Place_name>de Cnihtebrigge (p)</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 145</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>450673</ogr:Easting>
      <ogr:Northing>163414</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.138">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>527911,179758</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Knightsbridge</ogr:Location>
      <ogr:County>Mx</ogr:County>
      <ogr:River>Westbourne Stream</ogr:River>
      <ogr:Attested>1042â€“66</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name>(in) Cnihtebricge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNMx, 169; LdnPNs, 140-41; DEPN, 282</ogr:Other_ref>
      <ogr:Notes>LdnPNs notes reference to a guild of 'cnihtas' in 11th c. London. Crossing of Westbourne Stream.</ogr:Notes>
      <ogr:Easting>527911</ogr:Easting>
      <ogr:Northing>179758</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.139">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>468517,196635</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Knightsbridge Fm</ogr:Location>
      <ogr:County>Ox</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>10th</ogr:Attested>
      <ogr:Built_by>999</ogr:Built_by>
      <ogr:Place_name>Cnihtabryge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNOx i, 92</ogr:Other_ref>
      <ogr:Notes>OE 'cniht' in genitive plural.</ogr:Notes>
      <ogr:Easting>468517</ogr:Easting>
      <ogr:Northing>196635</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.140">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>348431,463897</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Lancaster</ogr:Location>
      <ogr:County>La</ogr:County>
      <ogr:River>Lune</ogr:River>
      <ogr:Attested>by 1216</ogr:Attested>
      <ogr:Built_by>1216</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>12</ogr:Harrison>
      <ogr:Jervoise>N, 132â€’33</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Skerton Bridge repaired in 1216.</ogr:Notes>
      <ogr:Easting>348431</ogr:Easting>
      <ogr:Northing>463897</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.141">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>381418,219578</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Langbridge Hundred [lost]</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>?Severn or causeway</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Langebrige hd', (In) Tolangebriges hd'</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNGl iii, 155</ogr:Other_ref>
      <ogr:Notes>To' part of prepostion 'into' (PNGl). PNGL, citing Rudder, notes this may refer to bridge over Severn between Highnam and Gloucester; PNGl suggests Over Causeway, a lengthy causeway. If so 'brycg' means 'hard, raised track through marshland' (PNGl).</ogr:Notes>
      <ogr:Easting>381418</ogr:Easting>
      <ogr:Northing>219578</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.142">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>341558,126637</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Langport</ogr:Location>
      <ogr:County>So</ogr:County>
      <ogr:River>Parrett</ogr:River>
      <ogr:Attested>by 1220</ogr:Attested>
      <ogr:Built_by>1220</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 100â€’01</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>341558</ogr:Easting>
      <ogr:Northing>126637</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.143">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>390725,264083</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Leather Bridge</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Salwarpre</ogr:River>
      <ogr:Attested>1229</ogr:Attested>
      <ogr:Built_by>1229</ogr:Built_by>
      <ogr:Place_name>Letherenebruge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 284</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>390725</ogr:Easting>
      <ogr:Northing>264083</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.144">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>421335,199336</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Lechlade</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1250</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>64</ogr:Harrison>
      <ogr:Jervoise>S, 2</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>421335</ogr:Easting>
      <ogr:Northing>199336</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.145">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>458144,304342</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Leicester</ogr:Location>
      <ogr:County>Le</ogr:County>
      <ogr:River>Soar</ogr:River>
      <ogr:Attested>by 1200</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>E, 44</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>458144</ogr:Easting>
      <ogr:Northing>304342</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.146">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>411725,309586</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Lichfield</ogr:Location>
      <ogr:County>St</ogr:County>
      <ogr:River>Curborough Brook</ogr:River>
      <ogr:Attested>possibly by pre-13thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>59</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>411725</ogr:Easting>
      <ogr:Northing>309586</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.147">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>497395,371148</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Lincoln</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Till</ogr:River>
      <ogr:Attested>by 1160</ogr:Attested>
      <ogr:Built_by>1160</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 59</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>497395</ogr:Easting>
      <ogr:Northing>371148</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.148">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>476542,171540</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Loddon Bridge</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Loddon</ogr:River>
      <ogr:Attested>by 1250</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 21</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Possibly confused with bridge at Twyford; see discussion in Jervoise.</ogr:Notes>
      <ogr:Easting>476542</ogr:Easting>
      <ogr:Northing>171540</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.149">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>507276,421437</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Loftbrige</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?The Beck</ogr:River>
      <ogr:Attested>c. 1160</ogr:Attested>
      <ogr:Built_by>1160</ogr:Built_by>
      <ogr:Place_name>Loftbrige</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 27</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>507276</ogr:Easting>
      <ogr:Northing>421437</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.150">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>531670,180920</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>London</ogr:Location>
      <ogr:County>Mx</ogr:County>
      <ogr:River>Fleet</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>102</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Excavated at Fleet Valley between the Blackfrriars and Holborn viaduct stations.</ogr:Notes>
      <ogr:Easting>531670</ogr:Easting>
      <ogr:Northing>180920</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.151">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>532691,180579</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>London</ogr:Location>
      <ogr:County>Mx</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1000</ogr:Attested>
      <ogr:Built_by>1000</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 16â€’17</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Rebuild from 1176.</ogr:Notes>
      <ogr:Easting>532691</ogr:Easting>
      <ogr:Northing>180579</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.152">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>494652,143813</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Lower Eashing 1 and 2</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Wey</ogr:River>
      <ogr:Attested>13thC; probably post 1233</ogr:Attested>
      <ogr:Built_by>1233</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 22â€’23</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Jervoise identifies six bridges over the Wey with an identical design. He suggests they were all constructed after the 1233 flood when many bridges in the district were damaged.</ogr:Notes>
      <ogr:Easting>494652</ogr:Easting>
      <ogr:Northing>143813</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.153">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>452044,206131</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Magdalen Bridge</ogr:Location>
      <ogr:County>Ox</ogr:County>
      <ogr:River>Cherwell</ogr:River>
      <ogr:Attested>1004</ogr:Attested>
      <ogr:Built_by>1004</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>53</ogr:Harrison>
      <ogr:Jervoise>S, 4</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>452044</ogr:Easting>
      <ogr:Northing>206131</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.154">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>366294,212018</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Malrlebrugge, -waye, -walle</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1282</ogr:Attested>
      <ogr:Built_by>1282</ogr:Built_by>
      <ogr:Place_name>Malrlebrugge, -waye, -walle</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNGl iii, 224</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>366294</ogr:Easting>
      <ogr:Northing>212018</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.155">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>444728,115519</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Mans Bridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Itchen</ogr:River>
      <ogr:Attested>by 932</ogr:Attested>
      <ogr:Built_by>932</ogr:Built_by>
      <ogr:Place_name>(to) mannes brycge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 64â€’65</ogr:Jervoise>
      <ogr:Other_ref>HaPNs, 34 and 42</ogr:Other_ref>
      <ogr:Notes>Hundred name. HaPNs suggests personal name Mann. Compare, however, 'Maneshou 1086', for which Parsons (2006, 169) suggests OE 'mann' 'a person' (and compares OE 'ge-mÃ¦Ì„nnes' 'community').</ogr:Notes>
      <ogr:Easting>444728</ogr:Easting>
      <ogr:Northing>115519</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.156">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>510614,389302</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Market Rasen</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Rase</ogr:River>
      <ogr:Attested>by 1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Rase, Rasa, Resne</ogr:Place_name>
      <ogr:Pn_element>rÃ¦sn</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>DLPN, 100; PNLi iii, 94-96; CDEPN, 492; DEPN, 341</ogr:Other_ref>
      <ogr:Notes>OE 'rÃ¦sn' probably denotes a plank bridge or planks laid across marshy ground. Grid reference given for Church Bridge on George St by be the older, more central road. Alternatively Jameson Bridge to the east of the settlement.</ogr:Notes>
      <ogr:Easting>510614</ogr:Easting>
      <ogr:Northing>389302</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.157">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>485125,186092</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Marlow</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1250</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>64</ogr:Harrison>
      <ogr:Jervoise>S, 10â€’11, 16</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>485125</ogr:Easting>
      <ogr:Northing>186092</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.158">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>601388,215060</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Mersea Island</ogr:Location>
      <ogr:County>Ex</ogr:County>
      <ogr:River>Coastal causeway</ogr:River>
      <ogr:Attested>c. 700</ogr:Attested>
      <ogr:Built_by>700</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>104</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>The Strood, lInking Mersea Island to Essex mainland</ogr:Notes>
      <ogr:Easting>601388</ogr:Easting>
      <ogr:Northing>215060</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.159">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>499150,160605</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Mimbridge</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Bourne</ogr:River>
      <ogr:Attested>956</ogr:Attested>
      <ogr:Built_by>956</ogr:Built_by>
      <ogr:Place_name>mint byrge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNSr, 129</ogr:Other_ref>
      <ogr:Notes>Cf. nearby 'mim feld' or 'mint feld' in the same charter bounds.</ogr:Notes>
      <ogr:Easting>499150</ogr:Easting>
      <ogr:Northing>160605</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.160">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>417066,585592</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Mitford</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Wansbeck</ogr:River>
      <ogr:Attested>13thC</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 10</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Uncertain date, possibly after 1250.</ogr:Notes>
      <ogr:Easting>417066</ogr:Easting>
      <ogr:Northing>585592</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.161">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>420033,585847</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Morpeth</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Wansbeck</ogr:River>
      <ogr:Attested>mid-13th C</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 11</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>420033</ogr:Easting>
      <ogr:Northing>585847</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.162">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>571149,206433</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Moulsham</ogr:Location>
      <ogr:County>Ex</ogr:County>
      <ogr:River>Chelmer</ogr:River>
      <ogr:Attested>1100x1135</ogr:Attested>
      <ogr:Built_by>1135</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 134</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>571149</ogr:Easting>
      <ogr:Northing>206433</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.163">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>479642,354132</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Newark</ogr:Location>
      <ogr:County>Np</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>1133x69</ogr:Attested>
      <ogr:Built_by>1169</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>44</ogr:Harrison>
      <ogr:Jervoise>E, 53</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Probably the Trent Bridge (i.e. the bridge by the castle).</ogr:Notes>
      <ogr:Easting>479642</ogr:Easting>
      <ogr:Northing>354132</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.164">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>425316,563782</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Newcastle</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Tyne</ogr:River>
      <ogr:Attested>by 1219-20</ogr:Attested>
      <ogr:Built_by>1220</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 29</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>The old bridge, built perhaps on top of Roman foundations, was burnt in 1248 and rebuilt in the 1250s. There was a 'bretasche' (defensive structure) on the bridge in 1219-20.</ogr:Notes>
      <ogr:Easting>425316</ogr:Easting>
      <ogr:Northing>563782</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.165">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>384722,345719</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Newcastle-under-Lyme</ogr:Location>
      <ogr:County>St</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>by 1169</ogr:Attested>
      <ogr:Built_by>1169</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 1</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>384722</ogr:Easting>
      <ogr:Northing>345719</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.166">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>623222,309011</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Norwich</ogr:Location>
      <ogr:County>Nf</ogr:County>
      <ogr:River>Wensum</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>103</ogr:Harrison>
      <ogr:Jervoise>E, 119â€’23</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>623222</ogr:Easting>
      <ogr:Northing>309011</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.167">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>458135,338252</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Nottingham (West Bridgeford)</ogr:Location>
      <ogr:County>Nt</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>by 924</ogr:Attested>
      <ogr:Built_by>924</ogr:Built_by>
      <ogr:Place_name>Brigeforde</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 8â€’14</ogr:Jervoise>
      <ogr:Other_ref>CDEPN, 85; PNNt, 231</ogr:Other_ref>
      <ogr:Notes>The most important crossing of the Trent in the 11th century, and a hub of the East Midlands road system.</ogr:Notes>
      <ogr:Easting>458135</ogr:Easting>
      <ogr:Northing>338252</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.168">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>476842,135470</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Oakhanger</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Oakhanger Stream</ogr:River>
      <ogr:Attested>by 1215</ogr:Attested>
      <ogr:Built_by>1215</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 22</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>476842</ogr:Easting>
      <ogr:Northing>135470</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.169">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>420121,445857</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Otley</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>Wharfe</ogr:River>
      <ogr:Attested>from 1228</ogr:Attested>
      <ogr:Built_by>1228</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 97</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>420121</ogr:Easting>
      <ogr:Northing>445857</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.170">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>432649,116767</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Ower Bridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Cadnam</ogr:River>
      <ogr:Attested>1279</ogr:Attested>
      <ogr:Built_by>1279</ogr:Built_by>
      <ogr:Place_name>Orebrugge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 195</ogr:Other_ref>
      <ogr:Notes>Headform from 1890s OS (not shown on 1870s OS). First element is the place-name Ower.</ogr:Notes>
      <ogr:Easting>432649</ogr:Easting>
      <ogr:Northing>116767</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.171">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>451438,205560</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Oxford</ogr:Location>
      <ogr:County>Ox</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>late 11thC</ogr:Attested>
      <ogr:Built_by>1099</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 154</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Called the Grandpont.</ogr:Notes>
      <ogr:Easting>451438</ogr:Easting>
      <ogr:Northing>205560</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.172">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>339052,258484</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Pembridge</ogr:Location>
      <ogr:County>He</ogr:County>
      <ogr:River>Arrow</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Penebrug(g)e</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>CDEPN, 465; HePNs, 156</ogr:Other_ref>
      <ogr:Notes>Alternative suggestions the OE personal name '*PÃ¦gna' (cf. Paignton) or OE 'penna' (gen. pl. of 'penn 'a pen') fit less well (CDEPN).</ogr:Notes>
      <ogr:Easting>339052</ogr:Easting>
      <ogr:Northing>258484</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.173">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>395234,245136</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Pershore</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Avon</ogr:River>
      <ogr:Attested>by 1238</ogr:Attested>
      <ogr:Built_by>1238</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>W, 167â€’68</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>395234</ogr:Easting>
      <ogr:Northing>245136</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.174">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>421450,515500</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Piercebridge</ogr:Location>
      <ogr:County>Du</ogr:County>
      <ogr:River>Tees</ogr:River>
      <ogr:Attested>c. 1040</ogr:Attested>
      <ogr:Built_by>1040</ogr:Built_by>
      <ogr:Place_name>Persebricge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 52â€’53</ogr:Jervoise>
      <ogr:Other_ref>DuPNs, 96; NbDuPNs, 157; DEPN, 366; CDEPN, 472</ogr:Other_ref>
      <ogr:Notes>Probably a Roman bridge, also refered to in the Assize Rolls of 1243. Or alternatively a causeway across marshy ground rather than the Tees, 'Osier bridge or causeway' (DEPN; DuPNs; CDEPN). (NbDuPNs had taken the specific as the personal name Piers.)</ogr:Notes>
      <ogr:Easting>421450</ogr:Easting>
      <ogr:Northing>515500</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.175">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>447093,422888</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Pontefract</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Aire</ogr:River>
      <ogr:Attested>1069</ogr:Attested>
      <ogr:Built_by>1069</ogr:Built_by>
      <ogr:Place_name>apud Pontemfractum, ad Pontemfractum</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>1</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoW ii, 75; CDEPN, 477; DEPN, 370</ogr:Other_ref>
      <ogr:Notes>Broken bridge'. In DB known as 'Tateshale' (later Tanshelf), and (perhaps later) the place may have been known as 'Kirkebi'. Both Latin and French origins. Early spellings &lt;Puntfreit , Pontfreit , Pountfreit&gt; etc., are from Old French, Anglo-Norman  'pon</ogr:Notes>
      <ogr:Easting>447093</ogr:Easting>
      <ogr:Northing>422888</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.176">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>521312,414989</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>pontem (de Haburc')</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?unknown</ogr:River>
      <ogr:Attested>1155â€“60</ogr:Attested>
      <ogr:Built_by>1160</ogr:Built_by>
      <ogr:Place_name>iuxta pontem</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 146</ogr:Other_ref>
      <ogr:Notes>Place-name Habrough. Localised according to information that bridge was 'between Stallingburgh and Habrough marshes' (see early forms), although it is possible that the forms refer to more than one bridge.</ogr:Notes>
      <ogr:Easting>521312</ogr:Easting>
      <ogr:Northing>414989</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.177">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>498862,420851</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>pontem de Saxfortesflet</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?unknown</ogr:River>
      <ogr:Attested>1154â€“89</ogr:Attested>
      <ogr:Built_by>1189</ogr:Built_by>
      <ogr:Place_name>pontem de Saxfortesflet</ogr:Place_name>
      <ogr:Pn_element>pons</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 116</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>498862</ogr:Easting>
      <ogr:Northing>420851</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.178">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>373672,290528</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Quatford</ogr:Location>
      <ogr:County>Sh</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>by 924</ogr:Attested>
      <ogr:Built_by>924</ogr:Built_by>
      <ogr:Place_name>Cwatbrycge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>W, 139â€’40</ogr:Jervoise>
      <ogr:Other_ref>PnSh vii, 18â€“23</ogr:Other_ref>
      <ogr:Notes>Possibly a reference to a bridge at Bridgnorth, the location of the bruidge in 1100.</ogr:Notes>
      <ogr:Easting>373672</ogr:Easting>
      <ogr:Northing>290528</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.179">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>428542,199464</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Radcot</ogr:Location>
      <ogr:County>Ox</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1250</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, x and 2â€’3</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Charter boundary clause evidence.</ogr:Notes>
      <ogr:Easting>428542</ogr:Easting>
      <ogr:Northing>199464</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.180">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>436962,113705</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Redbridge</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Test</ogr:River>
      <ogr:Attested>956</ogr:Attested>
      <ogr:Built_by>956</ogr:Built_by>
      <ogr:Place_name>(of, on) hreod brycge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise>S, 67</ogr:Jervoise>
      <ogr:Other_ref>HaPNs, 40 and 194; HaCoates, 137; DEPN, 383</ogr:Other_ref>
      <ogr:Notes>Carrying ancestor or A35 over Test; there are still reeds here (HaCoates).</ogr:Notes>
      <ogr:Easting>436962</ogr:Easting>
      <ogr:Northing>113705</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.181">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>570557,249992</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Risbridge Hundred</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Risebruge H'</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>SfPNs, 116; EHNs i, 95</ogr:Other_ref>
      <ogr:Notes>In the northeast of Barnardiston parish was  an area known as 'Monks Risbridge'. Anderson suggests the name referred to a crossing of a small stream on the southern boundary of this area (if I understand him correctly) (EHNs). Location from SfPNs.</ogr:Notes>
      <ogr:Easting>570557</ogr:Easting>
      <ogr:Northing>249992</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.182">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>384986,254515</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Risenbridge [lost]</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>?Severn</ogr:River>
      <ogr:Attested>13thC</ogr:Attested>
      <ogr:Built_by>1299</ogr:Built_by>
      <ogr:Place_name>Rysenbruge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 22</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>384986</ogr:Easting>
      <ogr:Northing>254515</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.183">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>388801,586552</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Risingham</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Rede</ogr:River>
      <ogr:Attested>Roman, apparently still extant in 18thC</ogr:Attested>
      <ogr:Built_by>200</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 15â€’16</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>The paved Roman Watling Street was still extant here in 1820.</ogr:Notes>
      <ogr:Easting>388801</ogr:Easting>
      <ogr:Northing>586552</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.184">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>573802,123817</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Robertsbridge</ogr:Location>
      <ogr:County>Sx</ogr:County>
      <ogr:River>Rother</ogr:River>
      <ogr:Attested>just after 1176</ogr:Attested>
      <ogr:Built_by>1176</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 46</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>573802</ogr:Easting>
      <ogr:Northing>123817</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.185">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>573968,168930</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Rochester</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>Medway</ogr:River>
      <ogr:Attested>Roman, medieval wooden bridge since at least 11thC</ogr:Attested>
      <ogr:Built_by>1050</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 38â€’40</ogr:Jervoise>
      <ogr:Other_ref>Brooks 1994</ogr:Other_ref>
      <ogr:Notes>Roman foundations probably used for a bridge at least from the 9th c. onwards, and the bridge was repaired in the early eleventh century.</ogr:Notes>
      <ogr:Easting>573968</ogr:Easting>
      <ogr:Northing>168930</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.186">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>486593,292292</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Rockingham</ogr:Location>
      <ogr:County>Np</ogr:County>
      <ogr:River>Welland</ogr:River>
      <ogr:Attested>by 1219</ogr:Attested>
      <ogr:Built_by>1219</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 62</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>486593</ogr:Easting>
      <ogr:Northing>292292</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.187">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>442656,392880</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Rotherham</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Don</ogr:River>
      <ogr:Attested>by 1252</ogr:Attested>
      <ogr:Built_by>1252</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 108</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>442656</ogr:Easting>
      <ogr:Northing>392880</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.188">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>435879,112771</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Rumbridge [Eling, Ha]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Bartley Water</ogr:River>
      <ogr:Attested>1180</ogr:Attested>
      <ogr:Built_by>1180</ogr:Built_by>
      <ogr:Place_name>Runbrigga</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 196; DEPN, 396</ogr:Other_ref>
      <ogr:Notes>HaPNs notes absence of medial &lt;e&gt; seems to rule out OE 'rÅ«m' 'spacious' or 'hruna' 'tree trunk' as the specific, and suggests instead OE 'rÅ«n' 'council'. DEPN accepts 'hruna' as a possibility.</ogr:Notes>
      <ogr:Easting>435879</ogr:Easting>
      <ogr:Northing>112771</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.189">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>414358,129057</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Salisbury</ogr:Location>
      <ogr:County>Wi</ogr:County>
      <ogr:River>Avon</ogr:River>
      <ogr:Attested>possibly by pre-13thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 72â€’73</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>The stone bridge (originally Ayleswade, later Harnham Bridge) was built in 1245 by Bishop Bingham. Other structures may have predated it.</ogr:Notes>
      <ogr:Easting>414358</ogr:Easting>
      <ogr:Northing>129057</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.190">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>450434,266249</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Sawbridge</ogr:Location>
      <ogr:County>Wa</ogr:County>
      <ogr:River>Leam</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Salwebrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWa, 151; CDEPN; DEPN, 405</ogr:Other_ref>
      <ogr:Notes>The DB form makes it almost certain that the first element is the OE  'sealh' 'willow', and it is on the border of Willoughby (i.e. 'Willow-tree settlement' or 'willow-tree ring').</ogr:Notes>
      <ogr:Easting>450434</ogr:Easting>
      <ogr:Northing>266249</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.191">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>462587,438712</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Scorce Bridge</ogr:Location>
      <ogr:County>YoE</ogr:County>
      <ogr:River>Dam Dike</ogr:River>
      <ogr:Attested>1227</ogr:Attested>
      <ogr:Built_by>1227</ogr:Built_by>
      <ogr:Place_name>Scalewisbrigg</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoE, 265â€“66</ogr:Other_ref>
      <ogr:Notes>PNYoE compares 'Skelwislandes' (1318, YD vi), a lost place in Yapham, and Scallow, Sx ('Scalewebregg(e)', 1385 and later forms; PNSx, 401).  The occurrence twice with OE 'brycg' 'bridge' is taken by PNYoE to indicate a meaningful word rather than a perso</ogr:Notes>
      <ogr:Easting>462587</ogr:Easting>
      <ogr:Northing>438712</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.192">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>455000,114025</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Shedfield</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>?Shawfords Lake</ogr:River>
      <ogr:Attested>956</ogr:Attested>
      <ogr:Built_by>956</ogr:Built_by>
      <ogr:Place_name>(to) scida felda</ogr:Place_name>
      <ogr:Pn_element>scÄ«d</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 47â€“48; HaCoates, 146; CDEPN, 540-41; DEPN, 415</ogr:Other_ref>
      <ogr:Notes>Coates notes KÃ¶keritz's suggestion that Shide (Wi) might mean 'footbridge', and thinks this would be appropriate in this parish, where the Roman road M 420 crossed four minor streams.  He notes OE 'scydd' 'shed' as a less likely possibility.</ogr:Notes>
      <ogr:Easting>455000</ogr:Easting>
      <ogr:Northing>114025</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.193">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>514484,239070</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Shefford [Bd]</ogr:Location>
      <ogr:County>Bd</ogr:County>
      <ogr:River>Hit</ogr:River>
      <ogr:Attested>1220</ogr:Attested>
      <ogr:Built_by>1220</ogr:Built_by>
      <ogr:Place_name>Sepford</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNBdHu, 172â€“73</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>514484</ogr:Easting>
      <ogr:Northing>239070</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.194">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>450396,88102</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Shide</ogr:Location>
      <ogr:County>Wt</ogr:County>
      <ogr:River>Medina</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Side, Sida</ogr:Place_name>
      <ogr:Pn_element>scÄ«d</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>WtKÃ¶, 179â€“80; WtPNs, 95; DEPN, 147</ogr:Other_ref>
      <ogr:Notes>It is thought that OE 'scÄ«d', whose meanings include 'board, plank', might have been used of a footbridge here (where the river is fairly narow) (WtKÃ¶).</ogr:Notes>
      <ogr:Easting>450396</ogr:Easting>
      <ogr:Northing>88102</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.195">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>428751,541042</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Shincliffe</ogr:Location>
      <ogr:County>Du</ogr:County>
      <ogr:River>Wear</ogr:River>
      <ogr:Attested>end of 12t C</ogr:Attested>
      <ogr:Built_by>1175</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 38</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>428751</ogr:Easting>
      <ogr:Northing>541042</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.196">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>349589,312368</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Shrewsbury, English Bridge</ogr:Location>
      <ogr:County>Sh</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>by 1121</ogr:Attested>
      <ogr:Built_by>1121</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>W, 132â€’33</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Charter reference to two bridges, presumably the English and Welsh bridges. Both English and Welsh Bridges are mentioned in a charter or King Henry I of 1228. The coordinates are for the English bridge.</ogr:Notes>
      <ogr:Easting>349589</ogr:Easting>
      <ogr:Northing>312368</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.197">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>348964,312795</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Shrewsbury, Welsh Bridge</ogr:Location>
      <ogr:County>Sh</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>by 1228</ogr:Attested>
      <ogr:Built_by>1228</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>W, 132â€’33</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Charter reference to two bridges, presumably the English and Welsh bridges. Both English and Welsh Bridges are mentioned in a charter of King Henry I in 1228.</ogr:Notes>
      <ogr:Easting>348964</ogr:Easting>
      <ogr:Northing>312795</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.198">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>374002,203554</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Slimbridge</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Heslinbruge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>26</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNGl ii, 247â€’48</ogr:Other_ref>
      <ogr:Notes>OE 'brycg' may here refer to a bridge over one of the streams here or a causeway across a muddy spot (PNGl).</ogr:Notes>
      <ogr:Easting>374002</ogr:Easting>
      <ogr:Northing>203554</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.199">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>350117,526913</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Sockbridge</ogr:Location>
      <ogr:County>We</ogr:County>
      <ogr:River>Lady Beck</ogr:River>
      <ogr:Attested>1170â€“80</ogr:Attested>
      <ogr:Built_by>1180</ogr:Built_by>
      <ogr:Place_name>Socabret, Socabreo, Socbridge</ogr:Place_name>
      <ogr:Pn_element>bred</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWe ii, 207â€“08; DEPN, 429</ogr:Other_ref>
      <ogr:Notes>Either OE '*socabred' â€˜board serving as a footbridge over marshy spots' (DEPN) or a compound of ME 'soc' â€˜ploughshareâ€™ (&lt; OE 'sÅcn' â€˜jurisdiction, estateâ€™ or Old French 'soc' â€˜ploughshareâ€™) and ME brede (&lt; OE 'brÇ£du') 'broad cultivated st</ogr:Notes>
      <ogr:Easting>350117</ogr:Easting>
      <ogr:Northing>526913</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.200">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>405893,423530</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Sowerby Bridge</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Calder</ogr:River>
      <ogr:Attested>1424</ogr:Attested>
      <ogr:Built_by>1424</ogr:Built_by>
      <ogr:Place_name>Sour(e)bybrig(g)(e), Sour(e)by Brygge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoW iii, 140; CDEPN, 563; DEPN, 432</ogr:Other_ref>
      <ogr:Notes>A bridge existed in 1315, when the township of Sowerby was fined for not repairing it. May have replaced 'Sowerby ford'.</ogr:Notes>
      <ogr:Easting>405893</ogr:Easting>
      <ogr:Northing>423530</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.201">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>531268,271153</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>St Ives</ogr:Location>
      <ogr:County>Hu</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>beginning of 12thC</ogr:Attested>
      <ogr:Built_by>1230</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>24</ogr:Harrison>
      <ogr:Jervoise>E, 102</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Uncertain date, but the bridge was certainly in existence by mid-thirteenth century.</ogr:Notes>
      <ogr:Easting>531268</ogr:Easting>
      <ogr:Northing>271153</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.202">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>518099,260213</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>St Neots</ogr:Location>
      <ogr:County>Hu</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>1180</ogr:Attested>
      <ogr:Built_by>1180</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>24</ogr:Harrison>
      <ogr:Jervoise>E, 95</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>518099</ogr:Easting>
      <ogr:Northing>260213</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.203">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>503199,171524</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Staines</ogr:Location>
      <ogr:County>Mx</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1242</ogr:Attested>
      <ogr:Built_by>1242</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>64</ogr:Harrison>
      <ogr:Jervoise>S, 13</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Probably considerably earlier.</ogr:Notes>
      <ogr:Easting>503199</ogr:Easting>
      <ogr:Northing>171524</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.204">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>373965,116392</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stalbridge</ogr:Location>
      <ogr:County>Do</ogr:County>
      <ogr:River>?Stour or Bibbern Brook</ogr:River>
      <ogr:Attested>860â€“86</ogr:Attested>
      <ogr:Built_by>886</ogr:Built_by>
      <ogr:Place_name>Stapulbrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDo iii, 280â€“81</ogr:Other_ref>
      <ogr:Notes>Bridge built on posts or piles'. The name may refer to a bridge over the Stour or Bibbern Brook (PNDo, citing Penn). Alternative at ST 74504 17236 or ST 76464 19024.</ogr:Notes>
      <ogr:Easting>373965</ogr:Easting>
      <ogr:Northing>116392</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.205">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>503055,306932</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stamford</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Welland</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 64â€’65</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>On the Old North Road/Ermine Street.</ogr:Notes>
      <ogr:Easting>503055</ogr:Easting>
      <ogr:Northing>306932</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.206">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>471146,455574</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stamfordbridge</ogr:Location>
      <ogr:County>YoE</ogr:County>
      <ogr:River>Derwent</ogr:River>
      <ogr:Attested>by 1066</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name>Stanford brycg</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>25</ogr:Harrison>
      <ogr:Jervoise>N, 71</ogr:Jervoise>
      <ogr:Other_ref>CDEPN, 568; PNYoE, 186â€“88</ogr:Other_ref>
      <ogr:Notes>Refers to crossing of Derwent by Roman road here (PNYoE).</ogr:Notes>
      <ogr:Easting>471146</ogr:Easting>
      <ogr:Northing>455574</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.207">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>496864,223009</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stanbridge</ogr:Location>
      <ogr:County>Bd</ogr:County>
      <ogr:River>Ouzel Brook</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Stanburge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>LPN, 69; PNBdHu, 113, 132</ogr:Other_ref>
      <ogr:Notes>PNBdHu suggests village took name from bridge at Stanbridgeford a mile to the south-east. Half-hundred named from Stanbridge; location just below Totternhoe.</ogr:Notes>
      <ogr:Easting>496864</ogr:Easting>
      <ogr:Northing>223009</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.208">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>435225,123263</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stanbridge (Earls, Ranville)</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Test</ogr:River>
      <ogr:Attested>1236</ogr:Attested>
      <ogr:Built_by>1236</ogr:Built_by>
      <ogr:Place_name>Stanbrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 184; HaCoates, 154-55</ogr:Other_ref>
      <ogr:Notes>Two manors and a deserted medieval village (HaCoates). Apparently a bridge over the Test (HaPNs; HaCoates).</ogr:Notes>
      <ogr:Easting>435225</ogr:Easting>
      <ogr:Northing>123263</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.209">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>421698,578362</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stannington</ogr:Location>
      <ogr:County>Nb</ogr:County>
      <ogr:River>Blyth</ogr:River>
      <ogr:Attested>mid-13th C</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 13</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>421698</ogr:Easting>
      <ogr:Northing>578362</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.210">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>538268,211824</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stanstead St Margarets [formerly 'Thele']</ogr:Location>
      <ogr:County>Ht</ogr:County>
      <ogr:River>Lea</ogr:River>
      <ogr:Attested>1189â€“99</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name>Pons de Thele</ogr:Place_name>
      <ogr:Pn_element>pons, Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNHt, 230; DEPN, 438</ogr:Other_ref>
      <ogr:Notes>The name refers to the bridge over the Lea here. The forms '(de) Ponte Tegule' and 'Punt de Tyulle' recorded form the thirteenth century mean 'tile bridge', and it is possible that this was later confused with 'Ã¾el' 'plank' for it is very unlikely that</ogr:Notes>
      <ogr:Easting>538268</ogr:Easting>
      <ogr:Northing>211824</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.211">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>433025,271437</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stare Bridge</ogr:Location>
      <ogr:County>Wa</ogr:County>
      <ogr:River>Avon (Warwickshire)</ogr:River>
      <ogr:Attested>1250s</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>W, 159</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Known as the Kingsbridge in the time of King Henry III (1216â€’72). It was in disrepair in 1278.</ogr:Notes>
      <ogr:Easting>433025</ogr:Easting>
      <ogr:Northing>271437</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.212">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>485769,103945</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stockbridge [Chichester]</ogr:Location>
      <ogr:County>Sx</ogr:County>
      <ogr:River>?Lavant</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Estocbrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNSx, 62</ogr:Other_ref>
      <ogr:Notes>Marked on Ordnance Survey Drawing no. 83.</ogr:Notes>
      <ogr:Easting>485769</ogr:Easting>
      <ogr:Northing>103945</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.213">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>435266,135158</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stockbridge [Ha]</ogr:Location>
      <ogr:County>Ha</ogr:County>
      <ogr:River>Test</ogr:River>
      <ogr:Attested>1221</ogr:Attested>
      <ogr:Built_by>1221</ogr:Built_by>
      <ogr:Place_name>Stocbrugge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HaPNs, 186; HaCoates, 155-56; CDEPN, 576; DEPN, 444</ogr:Other_ref>
      <ogr:Notes>Perhaps earlier 'Somborne' (CDEPN).</ogr:Notes>
      <ogr:Easting>435266</ogr:Easting>
      <ogr:Northing>135158</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.214">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>481676,430904</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stockbriggs Closes</ogr:Location>
      <ogr:County>YoE</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1199</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name>Stokebrige</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNYoE, 247</ogr:Other_ref>
      <ogr:Notes>Localised using copy of Enclosure Award Plan (East Riding of Yorkshire Archives, IA/22, parcels 19, 20 and 21).  Parcel 19 is westernmost, so feature may have been on road to Eastrington (SE 81488 30845).</ogr:Notes>
      <ogr:Easting>481676</ogr:Easting>
      <ogr:Northing>430904</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.215">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>389980,284811</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stourbridge</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Stour (Warwickshire)</ogr:River>
      <ogr:Attested>1255</ogr:Attested>
      <ogr:Built_by>1255</ogr:Built_by>
      <ogr:Place_name>Sturbrug, Sturesbrige (p)</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 311</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>389980</ogr:Easting>
      <ogr:Northing>284811</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.216">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>538250,184650</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stratford</ogr:Location>
      <ogr:County>Mx</ogr:County>
      <ogr:River>Lea</ogr:River>
      <ogr:Attested>Anglo-Saxon</ogr:Attested>
      <ogr:Built_by>850</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>45</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Timber features associated with river channels, such as the Channelsea, were recorded during the excavations at the Stratford Box, including a well-preserved Anglo-Saxon era wattle hurdle and timbers. Excavation site code: ARC SBX00. See also Bow bridge.</ogr:Notes>
      <ogr:Easting>538250</ogr:Easting>
      <ogr:Northing>184650</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.217">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>555340,278642</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Stuntney</ogr:Location>
      <ogr:County>Ca</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>12thC</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 103?</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>A great causeway from Stuntney and Soham to Ely.</ogr:Notes>
      <ogr:Easting>555340</ogr:Easting>
      <ogr:Northing>278642</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.218">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>436866,328724</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Swarkestone</ogr:Location>
      <ogr:County>Db</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>by 1204</ogr:Attested>
      <ogr:Built_by>1204</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 6â€’7</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>436866</ogr:Easting>
      <ogr:Northing>328724</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.219">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>497685,402603</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Sweinesbrig'</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?unknown</ogr:River>
      <ogr:Attested>1208</ogr:Attested>
      <ogr:Built_by>1208</ogr:Built_by>
      <ogr:Place_name>Sweinesbrig'</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi vi, 75</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>497685</ogr:Easting>
      <ogr:Northing>402603</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.220">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>261997,129999</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Swimbridge</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Birige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDe ii, 350</ogr:Other_ref>
      <ogr:Notes>First element apparently to be derived from the Sawin (OE personal name 'SÇ£wine') who held the manor of Birige in 1086 (DB f. 194 b). If this is so, the stress accent must later have been shifted to the second syllable. The bridge here is over a tributa</ogr:Notes>
      <ogr:Easting>261997</ogr:Easting>
      <ogr:Northing>129999</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.221">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>421100,303900</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tamworth</ogr:Location>
      <ogr:County>St</ogr:County>
      <ogr:River>Anker</ogr:River>
      <ogr:Attested>9thC</ogr:Attested>
      <ogr:Built_by>850</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>Rahtz and Meeson 1992Â </ogr:Other_ref>
      <ogr:Notes>Possible bridge excavated at 71 Bolebridge Street in association with the Tamworth watermills.</ogr:Notes>
      <ogr:Easting>421100</ogr:Easting>
      <ogr:Northing>303900</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.222">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>389372,233229</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tewkesbury</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>Avon</ogr:River>
      <ogr:Attested>c. 1205</ogr:Attested>
      <ogr:Built_by>1205</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>W, 171â€’72</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>389372</ogr:Easting>
      <ogr:Northing>233229</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.223">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>278661,112752</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Thelbridge</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Talebrua, Talebrige</ogr:Place_name>
      <ogr:Pn_element>brycg, Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDe ii, 395; CDEPN, 607; DEPN, 465</ogr:Other_ref>
      <ogr:Notes>'Plank bridge'.  This must have been over the little stream about half a mile north of the church (PNDe).</ogr:Notes>
      <ogr:Easting>278661</ogr:Easting>
      <ogr:Northing>112752</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.224">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>281921,104782</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Thelbridge Bridge</ogr:Location>
      <ogr:County>De</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>930</ogr:Attested>
      <ogr:Built_by>930</ogr:Built_by>
      <ogr:Place_name>Ã¾elbrycg</ogr:Place_name>
      <ogr:Pn_element>brycg, Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDe ii, 412</ogr:Other_ref>
      <ogr:Notes>'Plank bridge'. Shown as a ford on the OS 1st edn.</ogr:Notes>
      <ogr:Easting>281921</ogr:Easting>
      <ogr:Northing>104782</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.225">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>601853,278301</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Thelnetham</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>?unknown</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Teluetteham, Thelueteham</ogr:Place_name>
      <ogr:Pn_element>Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>SfPNs, 137; CDEPN, 607; DEPN, 465; MillsSf, 88</ogr:Other_ref>
      <ogr:Notes>Generic alternatively OE 'hÄm', as 'hamm' is not known to occur elsewhere in Norfolk or Suffolk, with specific a metathesized form of OE '*Ã¾Ä“felett' 'thicket' (SfPNs).</ogr:Notes>
      <ogr:Easting>601853</ogr:Easting>
      <ogr:Northing>278301</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.226">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>364967,387415</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Thelwall</ogr:Location>
      <ogr:County>Ch</ogr:County>
      <ogr:River>minor by Mersey</ogr:River>
      <ogr:Attested>920</ogr:Attested>
      <ogr:Built_by>920</ogr:Built_by>
      <ogr:Place_name>ThealwÃ¦le</ogr:Place_name>
      <ogr:Pn_element>Ã¾el</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNCh ii, 138; CDEPN, 607; DEPN, 465</ogr:Other_ref>
      <ogr:Notes>Deep pool at a plank' probably 'pool with a plank bidge' (PNCh). The Anglo-Saxon Chronicle refers to a burh established here in 922 by Eadward the Elder, presumably to guard the crossing of the Mersey at Latchford. The deep pool would probably be a place</ogr:Notes>
      <ogr:Easting>364967</ogr:Easting>
      <ogr:Northing>387415</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.227">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>499078,278629</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Thrapston</ogr:Location>
      <ogr:County>Np</ogr:County>
      <ogr:River>Nene</ogr:River>
      <ogr:Attested>by 1224</ogr:Attested>
      <ogr:Built_by>1224</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>58</ogr:Harrison>
      <ogr:Jervoise>E, 75â€’76</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>499078</ogr:Easting>
      <ogr:Northing>278629</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.228">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>396307,250011</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Throckmorton</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Piddle</ogr:River>
      <ogr:Attested>by 1229</ogr:Attested>
      <ogr:Built_by>1229</ogr:Built_by>
      <ogr:Place_name>Tuwelesbrugge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>W, 168</ogr:Jervoise>
      <ogr:Other_ref>PNWo, 170</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>396307</ogr:Easting>
      <ogr:Northing>250011</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.229">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>531184,406874</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Thrunsco Plat</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?Buck Beck</ogr:River>
      <ogr:Attested>1298</ogr:Attested>
      <ogr:Built_by>1298</ogr:Built_by>
      <ogr:Place_name>Thyernescobrig'</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi v, 120</ogr:Other_ref>
      <ogr:Notes>First element is the place-name Thrunscoe in Cleethorpes parish (TA 30943 07712).</ogr:Notes>
      <ogr:Easting>531184</ogr:Easting>
      <ogr:Northing>406874</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.230">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>487177,143500</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tilford 1</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Wey</ogr:River>
      <ogr:Attested>13thC; probably post 1233</ogr:Attested>
      <ogr:Built_by>1233</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 22â€’23</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Jervoise identifies six bridges over the Wey with an identical design. He suggests they were all constructed after the 1233 flood when many bridges in the district were damaged.</ogr:Notes>
      <ogr:Easting>487177</ogr:Easting>
      <ogr:Northing>143500</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.231">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>487376,143441</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tilford 2</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Wey</ogr:River>
      <ogr:Attested>13thC; probably post 1233</ogr:Attested>
      <ogr:Built_by>1233</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 22â€’23</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Jervoise identifies six bridges over the Wey with an identical design. He suggests they were all constructed after the 1233 flood when many bridges in the district were damaged.</ogr:Notes>
      <ogr:Easting>487376</ogr:Easting>
      <ogr:Northing>143441</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.232">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>559052,146495</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tonbridge</ogr:Location>
      <ogr:County>Ke</ogr:County>
      <ogr:River>Medway</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Tonebrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>KePNs, 180; CDEPN, 621</ogr:Other_ref>
      <ogr:Notes>Apparently originally a ford, later a bridge (CDEPN).</ogr:Notes>
      <ogr:Easting>559052</ogr:Easting>
      <ogr:Northing>146495</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.233">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>439811,475957</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Topcliffe</ogr:Location>
      <ogr:County>YoN</ogr:County>
      <ogr:River>Swale</ogr:River>
      <ogr:Attested>1227-1231</ogr:Attested>
      <ogr:Built_by>1227</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 89</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Wooden bridge attested in the thirteenth century.</ogr:Notes>
      <ogr:Easting>439811</ogr:Easting>
      <ogr:Northing>475957</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.234">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>385339,157997</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Trowbridge</ogr:Location>
      <ogr:County>Wi</ogr:County>
      <ogr:River>Biss</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Straburg</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWi, 133; Mills, 470; CDEPN, 629; DEPN, 481</ogr:Other_ref>
      <ogr:Notes>'Wooden bridge' (DEPN) or ' bridge made of tree trunks' (CDEPN).</ogr:Notes>
      <ogr:Easting>385339</ogr:Easting>
      <ogr:Northing>157997</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.235">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>511097,400177</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tunegatebrig</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>Nettleton Beck</ogr:River>
      <ogr:Attested>1245</ogr:Attested>
      <ogr:Built_by>1245</ogr:Built_by>
      <ogr:Place_name>Tunegatebrig</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi ii, 249</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>511097</ogr:Easting>
      <ogr:Northing>400177</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.236">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>493802,252376</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Turvey</ogr:Location>
      <ogr:County>Bd</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>by 1138x47</ogr:Attested>
      <ogr:Built_by>1147</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>23</ogr:Harrison>
      <ogr:Jervoise>E, 87</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>493802</ogr:Easting>
      <ogr:Northing>252376</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.237">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>460032,237950</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Turweston Bridge</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Great Ouse</ogr:River>
      <ogr:Attested>by 1252</ogr:Attested>
      <ogr:Built_by>1252</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 82</ogr:Jervoise>
      <ogr:Other_ref>CalInq i, 51.</ogr:Other_ref>
      <ogr:Notes>The location of the bridge cannot be closely identified, coordinates are to closest Ouse crossing by Turweston.</ogr:Notes>
      <ogr:Easting>460032</ogr:Easting>
      <ogr:Northing>237950</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.238">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>478338,176074</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Twyford</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Loddon</ogr:River>
      <ogr:Attested>by 1250</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>55</ogr:Harrison>
      <ogr:Jervoise>S, 21</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Ford replaced by a bridge by 1250.</ogr:Notes>
      <ogr:Easting>478338</ogr:Easting>
      <ogr:Northing>176074</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.239">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>384315,254739</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tybridge Street</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>by Severn</ogr:River>
      <ogr:Attested>1254</ogr:Attested>
      <ogr:Built_by>1254</ogr:Built_by>
      <ogr:Place_name>Tiebrigstrete</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNWo, 22â€“23</ogr:Other_ref>
      <ogr:Notes>PNWo gives the forms under the headform 'Turkey'.  However, there is a 'Tybridge Street' on the west bank of the river (the location of which is given here).</ogr:Notes>
      <ogr:Easting>384315</ogr:Easting>
      <ogr:Northing>254739</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.240">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>368882,215369</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Tymbrigge</ogr:Location>
      <ogr:County>Gl</ogr:County>
      <ogr:River>?Westbury Brook</ogr:River>
      <ogr:Attested>c. 1275</ogr:Attested>
      <ogr:Built_by>1275</ogr:Built_by>
      <ogr:Place_name>Tymbrigge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNGl iii, 233</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>368882</ogr:Easting>
      <ogr:Northing>215369</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.241">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>499267,145497</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Unstead</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Wey</ogr:River>
      <ogr:Attested>13thC; probably post 1233</ogr:Attested>
      <ogr:Built_by>1233</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>S, 24</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Jervoise identifies six bridges over the Wey with an identical design. He suggests they were all constructed after the 1233 flood when many bridges in the district were damaged.</ogr:Notes>
      <ogr:Easting>499267</ogr:Easting>
      <ogr:Northing>145497</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.242">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>505104,184627</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Uxbridge</ogr:Location>
      <ogr:County>Mx</ogr:County>
      <ogr:River>Colne</ogr:River>
      <ogr:Attested>c. 1145</ogr:Attested>
      <ogr:Built_by>1145</ogr:Built_by>
      <ogr:Place_name>Oxebruge, Wixebrug'</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>53</ogr:Harrison>
      <ogr:Jervoise>E, 148</ogr:Jervoise>
      <ogr:Other_ref>PNMx, 48â€“49; LdnPNs, 254; DEPN, 488; CDEPN, 640</ogr:Other_ref>
      <ogr:Notes>OE Group name 'Wixan' (OE '*Wihsan') as found in Waxlow (Mx), the Tribal Hidage and in place-names further afield (PNMx).</ogr:Notes>
      <ogr:Easting>505104</ogr:Easting>
      <ogr:Northing>184627</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.243">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>461017,189460</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Wallingford</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 1250</ogr:Attested>
      <ogr:Built_by>1250</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>64</ogr:Harrison>
      <ogr:Jervoise>S, 9</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>461017</ogr:Easting>
      <ogr:Northing>189460</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.244">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>507499,299116</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Wansford (Bridge)</ogr:Location>
      <ogr:County>Hu</ogr:County>
      <ogr:River>Nene</ogr:River>
      <ogr:Attested>c. 1200</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name>Wylmesford</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 79</ogr:Jervoise>
      <ogr:Other_ref>ECEE, 110; PNBdHu, 198; ClRH3 ii, 383</ogr:Other_ref>
      <ogr:Notes>On the important Old North Road/Ermine Street. Indulgences granted to all who gave 10d in alms for the repair of the bridge in 1221. In 1233 repairs were being conducted.</ogr:Notes>
      <ogr:Easting>507499</ogr:Easting>
      <ogr:Northing>299116</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.245">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>565130,310460</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Westbriggs</ogr:Location>
      <ogr:County>Nf</ogr:County>
      <ogr:River>?minor</ogr:River>
      <ogr:Attested>1086</ogr:Attested>
      <ogr:Built_by>1086</ogr:Built_by>
      <ogr:Place_name>Wesbruge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>DEPN, 507</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>565130</ogr:Easting>
      <ogr:Northing>310460</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.246">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>440408,447990</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Wetherby</ogr:Location>
      <ogr:County>YoW</ogr:County>
      <ogr:River>Wharfe</ogr:River>
      <ogr:Attested>by 1233</ogr:Attested>
      <ogr:Built_by>1233</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>198</ogr:Harrison>
      <ogr:Jervoise>N, 98</ogr:Jervoise>
      <ogr:Other_ref>WCA</ogr:Other_ref>
      <ogr:Notes>Bridge construction in progress in 1233. May refer instead to the repair of an existing bridge, since numerous records note its state and condition (WCA).</ogr:Notes>
      <ogr:Easting>440408</ogr:Easting>
      <ogr:Northing>447990</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.247">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>506900,164729</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Weybridge</ogr:Location>
      <ogr:County>Sr</ogr:County>
      <ogr:River>Wey</ogr:River>
      <ogr:Attested>1062</ogr:Attested>
      <ogr:Built_by>1062</ogr:Built_by>
      <ogr:Place_name>Weybrigga</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNSr, 98; Mills, 493; CDEPN, 668; DEPN, 510</ogr:Other_ref>
      <ogr:Notes>First element River Wey.</ogr:Notes>
      <ogr:Easting>506900</ogr:Easting>
      <ogr:Northing>164729</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.248">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>461203,205220</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Wheatley Bridge</ogr:Location>
      <ogr:County>Ox</ogr:County>
      <ogr:River>Thame</ogr:River>
      <ogr:Attested>1228â€“29</ogr:Attested>
      <ogr:Built_by>1229</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 151</ogr:Jervoise>
      <ogr:Other_ref>PNOx i, 142; S 587</ogr:Other_ref>
      <ogr:Notes>A ford is recorded here in S 587 (AD 956 (10th/11th c. copy)), and a 'pons de Harpesford' in 1228â€“29 (first element OE 'here-pÃ¦Ã°' 'main road').</ogr:Notes>
      <ogr:Easting>461203</ogr:Easting>
      <ogr:Northing>205220</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.249">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>521411,406447</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Wilgebrigge</ogr:Location>
      <ogr:County>Li</ogr:County>
      <ogr:River>?Laceby Beck</ogr:River>
      <ogr:Attested>1258â€“63</ogr:Attested>
      <ogr:Built_by>1263</ogr:Built_by>
      <ogr:Place_name>Wilgebrigge</ogr:Place_name>
      <ogr:Pn_element>brycg/bryggja</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNLi v, 135</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>521411</ogr:Easting>
      <ogr:Northing>406447</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.250">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>495707,177329</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Windsor</ogr:Location>
      <ogr:County>Be</ogr:County>
      <ogr:River>Thames</ogr:River>
      <ogr:Attested>by 13thC, possibly late 11thC</ogr:Attested>
      <ogr:Built_by>1200</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 149</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Certainly extant by 1275â€’76.</ogr:Notes>
      <ogr:Easting>495707</ogr:Easting>
      <ogr:Northing>177329</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.251">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>384615,118090</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Woodbridge</ogr:Location>
      <ogr:County>Do</ogr:County>
      <ogr:River>minor</ogr:River>
      <ogr:Attested>932</ogr:Attested>
      <ogr:Built_by>932</ogr:Built_by>
      <ogr:Place_name>(on) wde brigthe, (to) wde bricge, (to) wdebrige</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>PNDo iii, 105</ogr:Other_ref>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>384615</ogr:Easting>
      <ogr:Northing>118090</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.252">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>627100,249141</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Woodbridge [Sf]</ogr:Location>
      <ogr:County>Sf</ogr:County>
      <ogr:River>?Deben</ogr:River>
      <ogr:Attested>1042â€“66</ogr:Attested>
      <ogr:Built_by>1066</ogr:Built_by>
      <ogr:Place_name>Oddebruge</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>SfPNs, 157; CDEPN, 694; MillsSf, 99; DEPN, 530</ogr:Other_ref>
      <ogr:Notes>Woodbridge is located on the River Deben, although the bridge to which the name refers to appears to have been lost. CDEPN suggests instead 'the bridge leading to the wood'.</ogr:Notes>
      <ogr:Easting>627100</ogr:Easting>
      <ogr:Northing>249141</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.253">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>384532,254858</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Worcester</ogr:Location>
      <ogr:County>Wo</ogr:County>
      <ogr:River>Severn</ogr:River>
      <ogr:Attested>by 1088</ogr:Attested>
      <ogr:Built_by>1088</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>W, 144â€’45</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>384532</ogr:Easting>
      <ogr:Northing>254858</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.254">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>342527,230552</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Wormbridge</ogr:Location>
      <ogr:County>He</ogr:County>
      <ogr:River>Worm Brook</ogr:River>
      <ogr:Attested>1199</ogr:Attested>
      <ogr:Built_by>1199</ogr:Built_by>
      <ogr:Place_name>Winebrug</ogr:Place_name>
      <ogr:Pn_element>brycg</ogr:Pn_element>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise xsi:nil="true"/>
      <ogr:Other_ref>HePNs, 214</ogr:Other_ref>
      <ogr:Notes>Wrom Brook.</ogr:Notes>
      <ogr:Easting>342527</ogr:Easting>
      <ogr:Northing>230552</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.255">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>418548,316124</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Wychnor</ogr:Location>
      <ogr:County>St</ogr:County>
      <ogr:River>Trent</ogr:River>
      <ogr:Attested>by 1251</ogr:Attested>
      <ogr:Built_by>1251</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>E, 4</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes>Possibly only built in 1251.</ogr:Notes>
      <ogr:Easting>418548</ogr:Easting>
      <ogr:Northing>316124</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.256">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>441811,513157</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>Yarm Bridge</ogr:Location>
      <ogr:County>Du</ogr:County>
      <ogr:River>Tees</ogr:River>
      <ogr:Attested>by 1228</ogr:Attested>
      <ogr:Built_by>1228</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 57</ogr:Jervoise>
      <ogr:Other_ref xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Easting>441811</ogr:Easting>
      <ogr:Northing>513157</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:Bridges1250 fid="Bridges1250.257">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>460210,451655</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Location>York</ogr:Location>
      <ogr:County>YoN</ogr:County>
      <ogr:River>Ouse</ogr:River>
      <ogr:Attested>10thC</ogr:Attested>
      <ogr:Built_by>999</ogr:Built_by>
      <ogr:Place_name xsi:nil="true"/>
      <ogr:Pn_element xsi:nil="true"/>
      <ogr:Harrison>0</ogr:Harrison>
      <ogr:Jervoise>N, 83</ogr:Jervoise>
      <ogr:Other_ref>Stell 2003, 41</ogr:Other_ref>
      <ogr:Notes>Two bridges: the Ouse Bridge (coordinates given) and the Foss Bridge. Rebuilt in stone probably in late twelfth century. The earliest charter evidence is for the Ouse Bridge in 1189x1200 and for the Foss Bridge in 1145x48 (Stell).</ogr:Notes>
      <ogr:Easting>460210</ogr:Easting>
      <ogr:Northing>451655</ogr:Northing>
    </ogr:Bridges1250>
  </gml:featureMember>
</ogr:FeatureCollection>
