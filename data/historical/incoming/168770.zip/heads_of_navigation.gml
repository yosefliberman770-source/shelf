<?xml version="1.0" encoding="utf-8" ?>
<ogr:FeatureCollection
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://ogr.maptools.org/ heads_of_navigation.xsd"
     xmlns:ogr="http://ogr.maptools.org/"
     xmlns:gml="http://www.opengis.net/gml">
  <gml:boundedBy>
    <gml:Box>
      <gml:coord><gml:X>182928</gml:X><gml:Y>40605</gml:Y></gml:coord>
      <gml:coord><gml:X>647383</gml:X><gml:Y>633905</gml:Y></gml:coord>
    </gml:Box>
  </gml:boundedBy>
                                                                                                                                       
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.0">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>519212,110610</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Adur</ogr:Waterway>
      <ogr:Head_Navi>Bramber</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1304</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1301-1307, 287; Edwards 1987, 304</ogr:References>
      <ogr:Easting>519212</ogr:Easting>
      <ogr:Northing>110610</ogr:Northing>
      <ogr:Grid_Ref>TQ1921210610</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.1">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>518969,116100</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Adur</ogr:Waterway>
      <ogr:Head_Navi>Eaton's Farm</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton placename attested by 1086 and and hythe place-name attested by 1327 (Eaton Farm and Heath Barn 2 km downstream).</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 71, 80; Cole 2013, 320</ogr:References>
      <ogr:Easting>518969</ogr:Easting>
      <ogr:Northing>116100</ogr:Northing>
      <ogr:Grid_Ref>TQ1896916100</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.2">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>390859,454987</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Aire</ogr:Waterway>
      <ogr:Head_Navi>Coniston Cold</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Calder was navigated and Aire is recorded navigable downriver from Wheldale. In addition the section between Cononley and Coniston Cold was recorded as navigable in 1384. Cononley to Calder section unknown.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1381-1385, 414; Edwards 1987, 162-4</ogr:References>
      <ogr:Easting>390859</ogr:Easting>
      <ogr:Northing>454987</ogr:Northing>
      <ogr:Grid_Ref>SD9085954987</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.3">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>503160,391063</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ancholme</ogr:Waterway>
      <ogr:Head_Navi>Bishopsbridge</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1290</ogr:Last_Date>
      <ogr:Notes>1290 case of obstructions noted that Ancholme had been open for navigation up to Bishopsbridge in the past.</ogr:Notes>
      <ogr:Obstruct>1290, Bishopsbridge to Humber.</ogr:Obstruct>
      <ogr:References>CoPR 1281-1292, 400; Edwards 1987, 192-3</ogr:References>
      <ogr:Easting>503160</ogr:Easting>
      <ogr:Northing>391063</ogr:Northing>
      <ogr:Grid_Ref>TF0316091063</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.4">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>436322,291790</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Anker</ogr:Waterway>
      <ogr:Head_Navi>Nuneaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 321</ogr:References>
      <ogr:Easting>436322</ogr:Easting>
      <ogr:Northing>291790</ogr:Northing>
      <ogr:Grid_Ref>SP3632291790</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.5">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>310087,487055</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Annas</ogr:Waterway>
      <ogr:Head_Navi>Old Hyton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place-name at Old Hython by c. 1210. The old river estuary has silted and the modern course now deflected to the north.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 64; Cole 2013, 314</ogr:References>
      <ogr:Easting>310087</ogr:Easting>
      <ogr:Northing>487055</ogr:Northing>
      <ogr:Grid_Ref>SD1008787055</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.6">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>634433,326880</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ant</ogr:Waterway>
      <ogr:Head_Navi>East Ruston</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>c. 1348</ogr:Last_Date>
      <ogr:Notes>According to a report made in 1360 the river seems have become obstructed after the Black Death due to neglect.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 157; Edwards 1987, 244-6</ogr:References>
      <ogr:Easting>634433</ogr:Easting>
      <ogr:Northing>326880</ogr:Northing>
      <ogr:Grid_Ref>TG3443326880</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.7">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>510595,376348</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Appley Beck</ogr:Waterway>
      <ogr:Head_Navi>Bullington Priory</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>late 12th century</ogr:Last_Date>
      <ogr:Notes>Canal constructed by Bulington Priory.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 196</ogr:References>
      <ogr:Easting>510595</ogr:Easting>
      <ogr:Northing>376348</ogr:Northing>
      <ogr:Grid_Ref>TF1059576348</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.8">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>501971,107007</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Arun</ogr:Waterway>
      <ogr:Head_Navi>Arundel</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 392-3; Langdon 1993, 5</ogr:References>
      <ogr:Easting>501971</ogr:Easting>
      <ogr:Northing>107007</ogr:Northing>
      <ogr:Grid_Ref>TQ0197107007</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.9">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>501891,111260</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Arun</ogr:Waterway>
      <ogr:Head_Navi>North Stoke</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>12th century</ogr:Last_Date>
      <ogr:Notes>Large logboat find at North Stoke.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Kroger (forthcoming); Lanting 1998, 629; McGrail 1978, 244-6</ogr:References>
      <ogr:Easting>501891</ogr:Easting>
      <ogr:Northing>111260</ogr:Northing>
      <ogr:Grid_Ref>TQ0189111260</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.10">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>375005,164348</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Avon, Bristol</ogr:Waterway>
      <ogr:Head_Navi>Bath</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1276</ogr:Last_Date>
      <ogr:Notes>Port of Bristol remained open through the period. The charter ordering the improvement of navigation to Bath suggests passage of ships had been easier in the past.</ogr:Notes>
      <ogr:Obstruct>From 1276, above Bristol.</ogr:Obstruct>
      <ogr:References>CoCR 1272-1279, 354; Edwards 1987, 335-7</ogr:References>
      <ogr:Easting>375005</ogr:Easting>
      <ogr:Northing>164348</ogr:Northing>
      <ogr:Grid_Ref>ST7500564348</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.11">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>359965,172227</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Avon, Bristol</ogr:Waterway>
      <ogr:Head_Navi>Bristol</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port, hosted staple from 1313, named in the lists of large ship requisition ports of 1324 and 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183, 641; CoPR 1313-1317, 15, 56; Langdon 1993, 5</ogr:References>
      <ogr:Easting>359965</ogr:Easting>
      <ogr:Northing>172227</ogr:Northing>
      <ogr:Grid_Ref>ST5996572227</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.12">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>413970,129665</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Avon, Salisbury</ogr:Waterway>
      <ogr:Head_Navi>Salisbury</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>While the river's navigability to Salisbury is indicated for example by the order for the men of Salisbury to build barges to the king's fleet in the 1370s, it is probably that only relatively small vessels could reach that far upstream.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1370-1374, 219; Edwards 1987, 307-9</ogr:References>
      <ogr:Easting>413970</ogr:Easting>
      <ogr:Northing>129665</ogr:Northing>
      <ogr:Grid_Ref>SU1397029665</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.13">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>404000,243684</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Avon, Warwickshire</ogr:Waterway>
      <ogr:Head_Navi>Evesham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 337-8; Rogers 1882, iv, 696-7</ogr:References>
      <ogr:Easting>404000</ogr:Easting>
      <ogr:Northing>243684</ogr:Northing>
      <ogr:Grid_Ref>SP0400043684</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.14">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>351417,145624</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Axe</ogr:Waterway>
      <ogr:Head_Navi>Wookey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>A hythe was attested in Bleadney in 712, indicating that the river was used for navigation from the Early Middle Ages. Axe was straightened between Lower Weare and Clewer Bridge in 1316; both the old and the new course are given.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 71; Cole 2013, 317; Rippon 2007, 207-227; Russet 1991, 60-6</ogr:References>
      <ogr:Easting>351417</ogr:Easting>
      <ogr:Northing>145624</ogr:Northing>
      <ogr:Grid_Ref>ST5141745624</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.15">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>572503,326527</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Babingley</ogr:Waterway>
      <ogr:Head_Navi>Flitcham</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes>Together with nearby coastal town of Heacham, the town of Flitcham was ordered to send one ship to Berwick. This suggests that Flitcham may have been a port, although  it is possible that Flitcham's the contribution was financial.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1292-1301, 583</ogr:References>
      <ogr:Easting>572503</ogr:Easting>
      <ogr:Northing>326527</ogr:Northing>
      <ogr:Grid_Ref>TF7250326527</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.16">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>525500,369394</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bain</ogr:Waterway>
      <ogr:Head_Navi>Horncastle</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>Shipping activity attested in 1200 at Coningsby. Horncastle named in Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 201; Lambert 2011, 212</ogr:References>
      <ogr:Easting>525500</ogr:Easting>
      <ogr:Northing>369394</ogr:Northing>
      <ogr:Grid_Ref>TF2550069394</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.17">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>431240,202980</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bampton Canal</ogr:Waterway>
      <ogr:Head_Navi>Bampton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Constructed by 1005, probably in decline in the fourteenth century. Blair suggests that the Bampton mill was causing flooding and degradation of the watercourse by 1220s.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Blair 2007b, 272-8</ogr:References>
      <ogr:Easting>431240</ogr:Easting>
      <ogr:Northing>202980</ogr:Northing>
      <ogr:Grid_Ref>SP3124002980</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.18">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>338796,161910</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Banwell</ogr:Waterway>
      <ogr:Head_Navi>Eton (near Way Wick)</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name by 1325. Eton is today a lost settlement.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>338796</ogr:Easting>
      <ogr:Northing>161910</ogr:Northing>
      <ogr:Grid_Ref>ST3879661910</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.19">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>511106,370752</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bardney Abbey canal</ogr:Waterway>
      <ogr:Head_Navi>Bardney Abbey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Cut to serve Bardney Abbey.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 196</ogr:References>
      <ogr:Easting>511106</ogr:Easting>
      <ogr:Northing>370752</ogr:Northing>
      <ogr:Grid_Ref>TF1110670752</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.20">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>509017,373616</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Barlings Eau</ogr:Waterway>
      <ogr:Head_Navi>Barling Abbey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Partially diverted, at Barling Abbey.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 196</ogr:References>
      <ogr:Easting>509017</ogr:Easting>
      <ogr:Northing>373616</ogr:Northing>
      <ogr:Grid_Ref>TF0901773616</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.21">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>438737,102327</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Beaulieu</ogr:Waterway>
      <ogr:Head_Navi>Beaulieu</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1208</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 397</ogr:References>
      <ogr:Easting>438737</ogr:Easting>
      <ogr:Northing>102327</ogr:Northing>
      <ogr:Grid_Ref>SU3873702327</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.22">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>450170,433698</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bishop Dyke</ogr:Waterway>
      <ogr:Head_Navi>Sherburne in Elmet</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>An artificial watercourse of uncertain date and function. It has been suggested that it was constructed to carry stone querried from Huddleston. Out of use by the fifteenth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 197-8</ogr:References>
      <ogr:Easting>450170</ogr:Easting>
      <ogr:Northing>433698</ogr:Northing>
      <ogr:Grid_Ref>SE5017033698</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.23">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>586083,218125</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Blackwater</ogr:Waterway>
      <ogr:Head_Navi>Kelvedon</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1294</ogr:Last_Date>
      <ogr:Notes>The tenants of Westminster Abbey owed a customary payment called 'schipur' (ship-hire) in lieu of transporting goods from Kelveden, along River Blackwater, to estuary/coastal destinations at Salcott, Maldon and Haybridge.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Blair 2007a, 14n</ogr:References>
      <ogr:Easting>586083</ogr:Easting>
      <ogr:Northing>218125</ogr:Northing>
      <ogr:Grid_Ref>TL8608318125</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.24">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>585792,206808</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Blackwater</ogr:Waterway>
      <ogr:Head_Navi>Maldon</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324. 1422 IPM refers to shipping tolls at the port of Maldon. There is a hythe at Maldon.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; E-CIPM, 22-61</ogr:References>
      <ogr:Easting>585792</ogr:Easting>
      <ogr:Northing>206808</ogr:Northing>
      <ogr:Grid_Ref>TL8579206808</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.25">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>645230,275580</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Blyth</ogr:Waterway>
      <ogr:Head_Navi>Blythburgh</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Blyth originally flowed into the sea at Dunwich, but this outflow was blocked by sand by 1336 and the river now flows out at Walberswick.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1389-1392, 228; Edwards 1987, 247-9</ogr:References>
      <ogr:Easting>645230</ogr:Easting>
      <ogr:Northing>275580</ogr:Northing>
      <ogr:Grid_Ref>TM4523075580</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.26">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>452091,441913</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bolton Percy Foss</ogr:Waterway>
      <ogr:Head_Navi>Hornington</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1224</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 295</ogr:References>
      <ogr:Easting>452091</ogr:Easting>
      <ogr:Northing>441913</ogr:Northing>
      <ogr:Grid_Ref>SE5209141913</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.27">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>553025,262610</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bottisham Lode</ogr:Waterway>
      <ogr:Head_Navi>near Bottisham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1279</ogr:Last_Date>
      <ogr:Notes>A canal, probably constructed in the Anglo-Saxon period. In use in 1279, and probably in continued use in the Later Middle Ages.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 185; Fenland 10, 112; Fowler 1933, 113; Oosthuizen 2012, 213</ogr:References>
      <ogr:Easting>553025</ogr:Easting>
      <ogr:Northing>262610</ogr:Northing>
      <ogr:Grid_Ref>TL5302562610</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.28">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>587846,118074</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Brede</ogr:Waterway>
      <ogr:Head_Navi>Float Farm</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 386-7; Gardiner 2007, 102-3</ogr:References>
      <ogr:Easting>587846</ogr:Easting>
      <ogr:Northing>118074</ogr:Northing>
      <ogr:Grid_Ref>TQ8784618074</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.29">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>582686,117477</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Brede</ogr:Waterway>
      <ogr:Head_Navi>hythe near Brede</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>From an Anglo-Saxon charter boundary dated to 1005.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 386-7; Cole 2007, 72; Gardiner 2007, 102-3</ogr:References>
      <ogr:Easting>582686</ogr:Easting>
      <ogr:Northing>117477</ogr:Northing>
      <ogr:Grid_Ref>TQ8268617477</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.30">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>602572,242149</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Brett</ogr:Waterway>
      <ogr:Head_Navi>Hadleigh</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>In Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Lambert 2011, 213</ogr:References>
      <ogr:Easting>602572</ogr:Easting>
      <ogr:Northing>242149</ogr:Northing>
      <ogr:Grid_Ref>TM0257242149</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.31">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>350200,137515</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Brue</ogr:Waterway>
      <ogr:Head_Navi>Glastonbury</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>The date of Brue diversion west at Glastonbury is unknown but the new channel extended from Glastonbury to to Meare by 1091, and from Lichlake to the Bristol Channel by 1189. Pilrow channel was perhaps the original course from Lichlake to the sea.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 323-4; Hollinrake and Hollinrake 2007b, 235-43; Rippon 2007, 215-26</ogr:References>
      <ogr:Easting>350200</ogr:Easting>
      <ogr:Northing>137515</ogr:Northing>
      <ogr:Grid_Ref>ST5020037515</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.32">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>353250,134597</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Brue</ogr:Waterway>
      <ogr:Head_Navi>hythe east of Wallyer's Bridge</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Indicated by a hythe ('the yth on Begedswer') in an Anglo-Saxon charter boundary.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 74; Edwards 1987, 323-4; Hollinrake and Hollinrake 2007b, 235-43; Rippon 2007, 215-26</ogr:References>
      <ogr:Easting>353250</ogr:Easting>
      <ogr:Northing>134597</ogr:Northing>
      <ogr:Grid_Ref>ST5325034597</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.33">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>619735,327570</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bure</ogr:Waterway>
      <ogr:Head_Navi>Aylsham</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1291</ogr:Last_Date>
      <ogr:Notes>Court case involving fishing boats on the river between Aylesham and Burgh. These were not passanger/cargo boats but given that Wroxham was used as a purveyance port it seems possible that navigation was possible some distance above it.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 343</ogr:References>
      <ogr:Easting>619735</ogr:Easting>
      <ogr:Northing>327570</ogr:Northing>
      <ogr:Grid_Ref>TG1973527570</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.34">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>630310,318115</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Bure</ogr:Waterway>
      <ogr:Head_Navi>Wroxham</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 244; Langdon 1993, 5</ogr:References>
      <ogr:Easting>630310</ogr:Easting>
      <ogr:Northing>318115</ogr:Northing>
      <ogr:Grid_Ref>TG3031018115</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.35">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>558415,267375</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Burwell Lode</ogr:Waterway>
      <ogr:Head_Navi>Burwell</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1325</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 181; Edwards 1987, 226; Fowler 1933, 116; Langdon 1993, 5; Oosthuizen 2012, 219-20</ogr:References>
      <ogr:Easting>558415</ogr:Easting>
      <ogr:Northing>267375</ogr:Northing>
      <ogr:Grid_Ref>TL5841567375</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.36">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>637388,248940</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Butley Priory canal</ogr:Waterway>
      <ogr:Head_Navi>Butley Priory</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 192</ogr:References>
      <ogr:Easting>637388</ogr:Easting>
      <ogr:Northing>248940</ogr:Northing>
      <ogr:Grid_Ref>TM3738848940</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.37">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>639245,248100</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Butley River</ogr:Waterway>
      <ogr:Head_Navi>to Butley Prior canal</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 192</ogr:References>
      <ogr:Easting>639245</ogr:Easting>
      <ogr:Northing>248100</ogr:Northing>
      <ogr:Grid_Ref>TM3924548100</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.38">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>435617,423016</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Calder</ogr:Waterway>
      <ogr:Head_Navi>Stanley Ferry</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>mid-12th century</ogr:Last_Date>
      <ogr:Notes>Logboat find at Stanley Ferry dated to 10th-11th century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Kroger (forthcoming); Lanting 1998, 629; McGrail 1978, 257-6</ogr:References>
      <ogr:Easting>435617</ogr:Easting>
      <ogr:Northing>423016</ogr:Northing>
      <ogr:Grid_Ref>SE3561723016</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.39">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>544714,258955</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cam</ogr:Waterway>
      <ogr:Head_Navi>Cambridge</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>544714</ogr:Easting>
      <ogr:Northing>258955</ogr:Northing>
      <ogr:Grid_Ref>TL4471458955</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.40">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>550510,242640</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cam</ogr:Waterway>
      <ogr:Head_Navi>Great Chesterford</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1271</ogr:Last_Date>
      <ogr:Notes>Navigation to Cam well attested to the period after 1348. Rogers lists the costs of carriage from Great Chesterford downstream in 1271, but his source is unknown.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 338-9; Rogers 1866, ii, 600</ogr:References>
      <ogr:Easting>550510</ogr:Easting>
      <ogr:Northing>242640</ogr:Northing>
      <ogr:Grid_Ref>TL5051042640</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.41">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>510821,315158</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Car Dyke</ogr:Waterway>
      <ogr:Head_Navi>Kate's Bridge</ogr:Head_Navi>
      <ogr:Class>DE, IE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Disafforestment grant in 1230 refers to Car Dyke between Swaton and Market Deeping, indicating it may have been navigable, and a survey of ancient lodes and trenches in 1342 names Walton (between Peterborough and Market Deeping).</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 325-7; Edwards 1987, 216, 221-2; Fenland 5, passim.</ogr:References>
      <ogr:Easting>510821</ogr:Easting>
      <ogr:Northing>315158</ogr:Northing>
      <ogr:Grid_Ref>TF1082115158</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.42">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>511047,324033</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Car Dyke</ogr:Waterway>
      <ogr:Head_Navi>Morton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>A cargo of dressed Barnack stone was found in the Car Dyke near Morton, showing that at minimum the stretch of waterway between Morton and Kate's Bridge was in use during the medieval period.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 222</ogr:References>
      <ogr:Easting>511047</ogr:Easting>
      <ogr:Northing>324033</ogr:Northing>
      <ogr:Grid_Ref>TF1104724033</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.43">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>519847,297923</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Car Dyke</ogr:Waterway>
      <ogr:Head_Navi>Peterborough</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Baston, between Market Deeping and Kate's Bridge, named in 1349 as one of the vills whose navigation was degraded by the closure of a sewer connecting the Welland with the South Eau, so it is plausible Peterborough-Baston section had been in use.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 325-7; Edwards 1987, 216, 221-2, Fenland 5, passim.</ogr:References>
      <ogr:Easting>519847</ogr:Easting>
      <ogr:Northing>297923</ogr:Northing>
      <ogr:Grid_Ref>TL1984797923</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.44">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>513820,336609</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Car Dyke</ogr:Waterway>
      <ogr:Head_Navi>Swaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Disafforestment grant in 1230 refers to Car Dyke between Swaton and Market Deeping, indicating it may have been navigable, and a survey of ancient lodes and trenches in 1342 names Walton (between Peterborough and Market Deeping).</ogr:Notes>
      <ogr:Obstruct>A twelfth-century moated enclosure at Sempringham, 4 km south of Swaton, must have thereonwards disconnected the northermost stretch to Swaton from the rest of the dyke.</ogr:Obstruct>
      <ogr:References>Caffyn 2010, 325-7; Edwards 1987, 216, 221-2; Fenland 5, passim.</ogr:References>
      <ogr:Easting>513820</ogr:Easting>
      <ogr:Northing>336609</ogr:Northing>
      <ogr:Grid_Ref>TF1382036609</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.45">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>581363,314757</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Castle Acre Priory Canal</ogr:Waterway>
      <ogr:Head_Navi>Castle Acre Priory</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>The canal was connected to a grain-processing complex built c. 1360, but may somewhat pre-date it. It appears to have remained in use at least until the priory was dissolved in 1537.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Wilcox 2002, 19, 32-6, 46-7, 50-1</ogr:References>
      <ogr:Easting>581363</ogr:Easting>
      <ogr:Northing>314757</ogr:Northing>
      <ogr:Grid_Ref>TF8136314757</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.46">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>522705,298975</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cat's Water</ogr:Waterway>
      <ogr:Head_Navi>Nene</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Artificial water course, probably constructed in the Early Middle Ages.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Chisholm 2010, 130; Fenland 2, 36-7</ogr:References>
      <ogr:Easting>522705</ogr:Easting>
      <ogr:Northing>298975</ogr:Northing>
      <ogr:Grid_Ref>TL2270598975</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.47">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>546054,281305</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Catchwater Drain</ogr:Waterway>
      <ogr:Head_Navi>Witcham Hythe</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Navigable waterway indicated by a hythe at Witcham Hythe attested by 1251. The full route is difficult to reconstruct; here it is indicated by the modern Catchwater Drain and may have extended further east towards Ely.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 68-9; Cole 2013, 229; Oosthuizen 2012, 216-17</ogr:References>
      <ogr:Easting>546054</ogr:Easting>
      <ogr:Northing>281305</ogr:Northing>
      <ogr:Grid_Ref>TL4605481305</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.48">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>344979,152493</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cheddar Yeo</ogr:Waterway>
      <ogr:Head_Navi>Hythe by Cheddar and Hythe House at Cross near Axbridge</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place-name by 1212.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 71; Cole 2013, 317</ogr:References>
      <ogr:Easting>344979</ogr:Easting>
      <ogr:Northing>152493</ogr:Northing>
      <ogr:Grid_Ref>ST4497952493</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.49">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>452319,213711</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cherwell</ogr:Waterway>
      <ogr:Head_Navi>Ray</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1375</ogr:Last_Date>
      <ogr:Notes>Also Eaton place-name attested by 1086 at Water Eaton and Woodeaton, less than 2 km downriver of the confluence of Cherwell and Ray.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Blair 2007b, 259; Cole 2013,320; Edwards 1987, 283-4</ogr:References>
      <ogr:Easting>452319</ogr:Easting>
      <ogr:Northing>213711</ogr:Northing>
      <ogr:Grid_Ref>SP5231913711</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.50">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>483610,103634</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Chichester Channel</ogr:Waterway>
      <ogr:Head_Navi>Chichester</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Staple port from 1313.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1313-1317, 15, 56</ogr:References>
      <ogr:Easting>483610</ogr:Easting>
      <ogr:Northing>103634</ogr:Northing>
      <ogr:Grid_Ref>SU8361003634</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.51">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>302382,377828</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Clwyd</ogr:Waterway>
      <ogr:Head_Navi>Rhuddlan</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1324</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324. River improved for navigation and for transporting stone for the Rhuddlan Castle after Edward I's campaign of 1277.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Bond 2007, 201-2</ogr:References>
      <ogr:Easting>302382</ogr:Easting>
      <ogr:Northing>377828</ogr:Northing>
      <ogr:Grid_Ref>SJ0238277828</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.52">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>522218,296342</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cnute's Dyke</ogr:Waterway>
      <ogr:Head_Navi>Nene</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Probably a medieval canal constructed in the tenth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 6, 42</ogr:References>
      <ogr:Easting>522218</ogr:Easting>
      <ogr:Northing>296342</ogr:Northing>
      <ogr:Grid_Ref>TL2221896342</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.53">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>600382,225943</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Colne</ogr:Waterway>
      <ogr:Head_Navi>Colchester</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct>1353, complaints of obstruction to Colchester.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 253-6; Langdon 1993, 5</ogr:References>
      <ogr:Easting>600382</ogr:Easting>
      <ogr:Northing>225943</ogr:Northing>
      <ogr:Grid_Ref>TM0038225943</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.54">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>592902,227112</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Colne</ogr:Waterway>
      <ogr:Head_Navi>Fordham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>In Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct>1353, complaints of obstruction to Colchester</ogr:Obstruct>
      <ogr:References>Edwards 1987, 253-6; Lambert 2011, 213; Langdon 1993, 5</ogr:References>
      <ogr:Easting>592902</ogr:Easting>
      <ogr:Northing>227112</ogr:Northing>
      <ogr:Grid_Ref>TL9290227112</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.55">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>347832,454625</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Conder</ogr:Waterway>
      <ogr:Head_Navi>Hubbersty</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Stathe place-name attested in 1236. Hubbersty is no longer in use as a name.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 75; Cole 2013, 318</ogr:References>
      <ogr:Easting>347832</ogr:Easting>
      <ogr:Northing>454625</ogr:Northing>
      <ogr:Grid_Ref>SD4783254625</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.56">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>278503,377498</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Conwy</ogr:Waterway>
      <ogr:Head_Navi>Conwy</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 352-3</ogr:References>
      <ogr:Easting>278503</ogr:Easting>
      <ogr:Northing>377498</ogr:Northing>
      <ogr:Grid_Ref>SH7850377498</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.57">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>279848,361496</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Conwy</ogr:Waterway>
      <ogr:Head_Navi>Llanwrst</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1332</ogr:Last_Date>
      <ogr:Notes>Timber from the forest of Snowdonia to be taken and carried by the River Conwy. By its location Llanewrst was the probable harbour.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1330-1334, 367; Edwards 1987, 352-3</ogr:References>
      <ogr:Easting>279848</ogr:Easting>
      <ogr:Northing>361496</ogr:Northing>
      <ogr:Grid_Ref>SH7984861496</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.58">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>424841,606238</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Coquet</ogr:Waterway>
      <ogr:Head_Navi>Warkworth</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1324-1327, 311; Edwards 1987, 125</ogr:References>
      <ogr:Easting>424841</ogr:Easting>
      <ogr:Northing>606238</ogr:Northing>
      <ogr:Grid_Ref>NU2484106238</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.59">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>537700,202995</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cornmill Stream</ogr:Waterway>
      <ogr:Head_Navi>Lea</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1200?</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 190</ogr:References>
      <ogr:Easting>537700</ogr:Easting>
      <ogr:Northing>202995</ogr:Northing>
      <ogr:Grid_Ref>TL3770002995</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.60">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>545312,268721</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cottenham Lode</ogr:Waterway>
      <ogr:Head_Navi>Cottenham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Cottenham Lode connecting to the Old West River in use already 1066.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 182; Fenland 10, 132, 137</ogr:References>
      <ogr:Easting>545312</ogr:Easting>
      <ogr:Northing>268721</ogr:Northing>
      <ogr:Grid_Ref>TL4531268721</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.61">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>353343,305757</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Cound Brook</ogr:Waterway>
      <ogr:Head_Navi>Eaton Mascott</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>353343</ogr:Easting>
      <ogr:Northing>305757</ogr:Northing>
      <ogr:Grid_Ref>SJ5334305757</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.62">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>386939,364767</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Dane</ogr:Waterway>
      <ogr:Head_Navi>Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name by c. 1262</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 319</ogr:References>
      <ogr:Easting>386939</ogr:Easting>
      <ogr:Northing>364767</ogr:Northing>
      <ogr:Grid_Ref>SJ8693964767</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.63">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>546768,288995</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Darcey Lode</ogr:Waterway>
      <ogr:Head_Navi>Oxlode</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>A canal. 'Darsey' was attested in 1437, but it may have been referred to as 'moneyeslode' already in 1251.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 6, 81</ogr:References>
      <ogr:Easting>546768</ogr:Easting>
      <ogr:Northing>288995</ogr:Northing>
      <ogr:Grid_Ref>TL4676888995</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.64">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>554451,174531</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Darent</ogr:Waterway>
      <ogr:Head_Navi>Dartford</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1374-1377, 233; Edwards 1987, 278</ogr:References>
      <ogr:Easting>554451</ogr:Easting>
      <ogr:Northing>174531</ogr:Northing>
      <ogr:Grid_Ref>TQ5445174531</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.65">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>280673,60299</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Dart</ogr:Waterway>
      <ogr:Head_Navi>Totnes</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes>Named in the lists of large ship requisition ports of 1324 and 1326, as was Dartmouth downstream. Ahsburton further upstream was named as a staple site from 1327, but Totnes may have served as its port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 184, 642</ogr:References>
      <ogr:Easting>280673</ogr:Easting>
      <ogr:Northing>60299</ogr:Northing>
      <ogr:Grid_Ref>SX8067360299</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.66">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>200395,211457</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Daugleddau</ogr:Waterway>
      <ogr:Head_Navi>Cleddau (western Cleddau)</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes>Or Milford Haven, a ria.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1296-1302, 500; Edwards 1987, 350</ogr:References>
      <ogr:Easting>200395</ogr:Easting>
      <ogr:Northing>211457</ogr:Northing>
      <ogr:Grid_Ref>SN0039511457</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.67">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>627886,249179</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Deben</ogr:Waterway>
      <ogr:Head_Navi>Woodbridge</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1389-1392, 140; Edwards 1987, 249-50</ogr:References>
      <ogr:Easting>627886</ogr:Easting>
      <ogr:Northing>249179</ogr:Northing>
      <ogr:Grid_Ref>TM2788649179</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.68">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>340709,365758</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Dee</ogr:Waterway>
      <ogr:Head_Navi>Chester</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324, hosted staple from 1313.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1313-1317, 15, 56; Edwards 1987, 353-57</ogr:References>
      <ogr:Easting>340709</ogr:Easting>
      <ogr:Northing>365758</ogr:Northing>
      <ogr:Grid_Ref>SJ4070965758</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.69">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>336532,341971</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Dee</ogr:Waterway>
      <ogr:Head_Navi>Overton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1303x4</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 353-57</ogr:References>
      <ogr:Easting>336532</ogr:Easting>
      <ogr:Northing>341971</ogr:Northing>
      <ogr:Grid_Ref>SJ3653241971</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.70">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>482585,431271</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Delph Drain</ogr:Waterway>
      <ogr:Head_Navi>Hive</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place-name attested in 959. Cole suggests Delph Drain connected Hive to Foulness.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 317-18</ogr:References>
      <ogr:Easting>482585</ogr:Easting>
      <ogr:Northing>431271</ogr:Northing>
      <ogr:Grid_Ref>SE8258531271</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.71">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>312047,530839</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Derwent, Cumberland</ogr:Waterway>
      <ogr:Head_Navi>Cockermouth</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324, as was Workington further downstream.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 369</ogr:References>
      <ogr:Easting>312047</ogr:Easting>
      <ogr:Northing>530839</ogr:Northing>
      <ogr:Grid_Ref>NY1204730839</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.72">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>435478,336416</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Derwent, Derbyshire</ogr:Waterway>
      <ogr:Head_Navi>Derby</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1269 and again by 1378</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct>Mills built on the river from 1268 appear to have obstructed the Derwent. But in 1378 the townsmen of Derby were commissioned by the king to build a balinger so the river appears to have been once again navigable.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 187-9</ogr:References>
      <ogr:Easting>435478</ogr:Easting>
      <ogr:Northing>336416</ogr:Northing>
      <ogr:Grid_Ref>SK3547836416</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.73">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>498797,484785</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Derwent, Yorkshire</ogr:Waterway>
      <ogr:Head_Navi>East Ayton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 321</ogr:References>
      <ogr:Easting>498797</ogr:Easting>
      <ogr:Northing>484785</ogr:Northing>
      <ogr:Grid_Ref>SE9879784785</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.74">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>471147,455577</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Derwent, Yorkshire</ogr:Waterway>
      <ogr:Head_Navi>Stamford Bridge</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>early 14th century?</ogr:Last_Date>
      <ogr:Notes>Derwent had become obstructed by 1332, but was recorded as having previously been opento navigation up to Stamford Bridge  'from time before memory'. A ship was recorded on Derwent by Wressle in 1317.</ogr:Notes>
      <ogr:Obstruct>1332, mouth to Stamford Bridge.</ogr:Obstruct>
      <ogr:References>CoIM, 107-1349, 320; Edwards 1987, 154</ogr:References>
      <ogr:Easting>471147</ogr:Easting>
      <ogr:Northing>455577</ogr:Northing>
      <ogr:Grid_Ref>SE7114755577</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.75">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>456941,403492</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Don</ogr:Waterway>
      <ogr:Head_Navi>Doncaster</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>456941</ogr:Easting>
      <ogr:Northing>403492</ogr:Northing>
      <ogr:Grid_Ref>SE5694103492</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.76">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>442484,392261</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Don</ogr:Waterway>
      <ogr:Head_Navi>Rotherham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1322</ogr:Last_Date>
      <ogr:Notes>At some point by the early fifteenth century Don was canalised and turned northwards at Thorne to join the Aire.</ogr:Notes>
      <ogr:Obstruct>1326 onwards, to the junction with Trent. Stretch downriver from Doncaster navigable in 1394.</ogr:Obstruct>
      <ogr:References>Cole 2007, 64-6; Edwards 1987, 165-7</ogr:References>
      <ogr:Easting>442484</ogr:Easting>
      <ogr:Northing>392261</ogr:Northing>
      <ogr:Grid_Ref>SK4248492261</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.77">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>647383,270709</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Dunwich</ogr:Waterway>
      <ogr:Head_Navi>Dunwich</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1336</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324. The original river mouth at Dunwich was had become blocked by sand by 1336, after which the use of the river declined.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 247-9</ogr:References>
      <ogr:Easting>647383</ogr:Easting>
      <ogr:Northing>270709</ogr:Northing>
      <ogr:Grid_Ref>TM4738370709</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.78">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>349966,290110</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Eaton Brook</ogr:Waterway>
      <ogr:Head_Navi>Eaton under Heywood</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1227.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>349966</ogr:Easting>
      <ogr:Northing>290110</ogr:Northing>
      <ogr:Grid_Ref>SO4996690110</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.79">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>488620,401113</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Eau</ogr:Waterway>
      <ogr:Head_Navi>Scotter</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>It was reported that navigation had become hindered at Scotter by a weir in 1375, suggesting that the river was navigable an unknown distance upstream.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 191-2</ogr:References>
      <ogr:Easting>488620</ogr:Easting>
      <ogr:Northing>401113</ogr:Northing>
      <ogr:Grid_Ref>SE8862001113</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.80">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>335087,559272</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Eden</ogr:Waterway>
      <ogr:Head_Navi>Beaumont</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>There were boats at Beaumont in 1373. A charter from 1401 indicates that merchandise may have been shipped to Scotland via Carlisle, but the wording is uncertain.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1399-1402, 317; CoPR 1370-1374, 311; Edwards 1987, 370</ogr:References>
      <ogr:Easting>335087</ogr:Easting>
      <ogr:Northing>559272</ogr:Northing>
      <ogr:Grid_Ref>NY3508759272</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.81">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>509598,439036</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Eschedike</ogr:Waterway>
      <ogr:Head_Navi>Meaux Abbey (Monk Dyke)</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1160x82</ogr:Last_Date>
      <ogr:Notes>Constructed by Meaux Abbey.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 195</ogr:References>
      <ogr:Easting>509598</ogr:Easting>
      <ogr:Northing>439036</ogr:Northing>
      <ogr:Grid_Ref>TA0959839036</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.82">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>308403,496134</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Esk</ogr:Waterway>
      <ogr:Head_Navi>Ravenglass</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1324</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 368</ogr:References>
      <ogr:Easting>308403</ogr:Easting>
      <ogr:Northing>496134</ogr:Northing>
      <ogr:Grid_Ref>SD0840396134</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.83">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>291649,92050</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Exe</ogr:Waterway>
      <ogr:Head_Navi>Exeter</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1320</ogr:Last_Date>
      <ogr:Notes>Staple from 1327. But there were recurring complaints of obstruction on the Exe from 1290 and as by 1327 it seems that the river had become permanently blocked to navigation the coastal vill of Topsham became Exeter's port.</ogr:Notes>
      <ogr:Obstruct>From 1290, below Exeter.</ogr:Obstruct>
      <ogr:References>CoPR 1327-1330, 98; Edwards 1987, 315-16</ogr:References>
      <ogr:Easting>291649</ogr:Easting>
      <ogr:Northing>92050</ogr:Northing>
      <ogr:Grid_Ref>SX9164992050</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.84">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>185031,40605</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Fal</ogr:Waterway>
      <ogr:Head_Navi>Truro</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1347</ogr:Last_Date>
      <ogr:Notes>Truro, further up River Truro, was a staple port from 1327.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1327-1330, 98; Edwards 1987, 324</ogr:References>
      <ogr:Easting>185031</ogr:Easting>
      <ogr:Northing>40605</ogr:Northing>
      <ogr:Grid_Ref>SW8503140605</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.85">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>531638,181176</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Fleet</ogr:Waterway>
      <ogr:Head_Navi>London</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>13th century?</ogr:Last_Date>
      <ogr:Notes>Stone carried on the Fleet for the rebuilding of St Paul's in 1110-33.</ogr:Notes>
      <ogr:Obstruct>Obstructed in 1307.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 282-3</ogr:References>
      <ogr:Easting>531638</ogr:Easting>
      <ogr:Northing>181176</ogr:Northing>
      <ogr:Grid_Ref>TQ3163881176</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.86">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>510837,439304</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Forthdyke</ogr:Waterway>
      <ogr:Head_Navi>Monk Dyke</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1221-35</ogr:Last_Date>
      <ogr:Notes>Constructed by Meaux Abbey.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 195</ogr:References>
      <ogr:Easting>510837</ogr:Easting>
      <ogr:Northing>439304</ogr:Northing>
      <ogr:Grid_Ref>TA1083739304</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.87">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>483368,378137</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Foss Dyke</ogr:Waterway>
      <ogr:Head_Navi>Trent</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>483368</ogr:Easting>
      <ogr:Northing>378137</ogr:Northing>
      <ogr:Grid_Ref>SK8336878137</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.88">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>497176,371156</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Foss Dyke</ogr:Waterway>
      <ogr:Head_Navi>Witham</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port. Navigable (at least partially) in 1066, but fully opened by Henry I in 1121.</ogr:Notes>
      <ogr:Obstruct>Obstructions reported from 1299 and the canal may have been periodically unnavigable during the fourteenth century, and probably was unnavigable by the end of the century.</ogr:Obstruct>
      <ogr:References>Bond 2007, 175-6; Edwards 1987, 197-9; Jones 2000, 64-5; Langdon 1993, 5</ogr:References>
      <ogr:Easting>497176</ogr:Easting>
      <ogr:Northing>371156</ogr:Northing>
      <ogr:Grid_Ref>SK9717671156</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.89">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>462626,460570</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Foss, Yorkshire</ogr:Waterway>
      <ogr:Head_Navi>Strensall</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1323</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1321-1324, 379; Edwards 1987, 155-6</ogr:References>
      <ogr:Easting>462626</ogr:Easting>
      <ogr:Northing>460570</ogr:Northing>
      <ogr:Grid_Ref>SE6262660570</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.90">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>482040,432469</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Foulness</ogr:Waterway>
      <ogr:Head_Navi>Delph Drain</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place-name (by Delph Drain) attested in 959. Historically marshy area, possible navigation reconstructed from Domesday hundredal boundaries.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 317-18</ogr:References>
      <ogr:Easting>482040</ogr:Easting>
      <ogr:Northing>432469</ogr:Northing>
      <ogr:Grid_Ref>SE8204032469</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.91">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>210617,59810</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Fowey</ogr:Waterway>
      <ogr:Head_Navi>Lostwithiel</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1326, hosted staple from 1327.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 642; Edwards 1987, 317</ogr:References>
      <ogr:Easting>210617</ogr:Easting>
      <ogr:Northing>59810</ogr:Northing>
      <ogr:Grid_Ref>SX1061759810</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.92">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>392353,87144</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Frome, Dorset</ogr:Waterway>
      <ogr:Head_Navi>Wareham</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1326. It appears that Frome had began to silt up by the late 13th century. The last mention of Wareham as a major port was in 1347.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 642; EUS Wareham; Edwards 1987, 309</ogr:References>
      <ogr:Easting>392353</ogr:Easting>
      <ogr:Northing>87144</ogr:Northing>
      <ogr:Grid_Ref>SY9235387144</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.93">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>384830,205091</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Frome, Gloucestershire</ogr:Waterway>
      <ogr:Head_Navi>Stroud</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes>Stroud is named in lists of requisition ports for 50 tun ships in 1320s. However, given it is unlikely that the River Frome could have allowed passage for such large vessels this may refer to an outport by the Severn.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 641</ogr:References>
      <ogr:Easting>384830</ogr:Easting>
      <ogr:Northing>205091</ogr:Northing>
      <ogr:Grid_Ref>SO8483005091</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.94">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>349910,138606</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Glastonbury Canal</ogr:Waterway>
      <ogr:Head_Navi>Glastonbury</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Anglo-Saxon canal, connecting River Brue with Glastonbury. Charles and Nancy Hollinrake argue it was constructed in the mid-tenth century, and it was probably filled in in the early thirteenth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Hollinrake and Hollinrake 2007b, 235-43</ogr:References>
      <ogr:Easting>349910</ogr:Easting>
      <ogr:Northing>138606</ogr:Northing>
      <ogr:Grid_Ref>ST4991038606</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.95">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>510821,315158</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Glen</ogr:Waterway>
      <ogr:Head_Navi>Kate's Bridge</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1336</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 215; Langdon 1993, 5</ogr:References>
      <ogr:Easting>510821</ogr:Easting>
      <ogr:Northing>315158</ogr:Northing>
      <ogr:Grid_Ref>TF1082115158</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.96">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>524290,271468</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Great Ouse</ogr:Waterway>
      <ogr:Head_Navi>Huntingdon</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1338</ogr:Last_Date>
      <ogr:Notes>Historical ourse has been subject to significant changes by human activity and natural processes. Portions of its historic length include West Water, Old West River and Old Croft River.</ogr:Notes>
      <ogr:Obstruct>From 1275x78 onwards, to Huntingdon.</ogr:Obstruct>
      <ogr:References>Caffyn 2010, 327-32; Chisholm 2010, 126, 131-3,  Edwards 1987, 222-5; Jones 2000, 67; see also The Fenland Project, passim.</ogr:References>
      <ogr:Easting>524290</ogr:Easting>
      <ogr:Northing>271468</ogr:Northing>
      <ogr:Grid_Ref>TL2429071468</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.97">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>488029,244041</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Great Ouse</ogr:Waterway>
      <ogr:Head_Navi>Ouzel</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086 by Ouzel. In 1279 a court case complained that a mill build in Offord Cluny restricted navigation between Huntingdon and Bedford, so navigation would otherwise have been possible to Bedford.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 329; Cole 2007, 82; Cole 2013, 319</ogr:References>
      <ogr:Easting>488029</ogr:Easting>
      <ogr:Northing>244041</ogr:Northing>
      <ogr:Grid_Ref>SP8802944041</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.98">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>531271,271155</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Great Ouse</ogr:Waterway>
      <ogr:Head_Navi>St Ives</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>531271</ogr:Easting>
      <ogr:Northing>271155</ogr:Northing>
      <ogr:Grid_Ref>TL3127171155</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.99">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>240689,206855</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Gwendraeth</ogr:Waterway>
      <ogr:Head_Navi>Kidwelly</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1297</ogr:Last_Date>
      <ogr:Notes>Kidwelly is listed among sea ports in a prohibition of travel abroad without license from the king.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1296-1302, 83; Edwards 1987, 349</ogr:References>
      <ogr:Easting>240689</ogr:Easting>
      <ogr:Northing>206855</ogr:Northing>
      <ogr:Grid_Ref>SN4068906855</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.100">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>353256,140789</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Hartlake</ogr:Waterway>
      <ogr:Head_Navi>Whitelake</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes>Canalised in 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Rippon 2007, 218-19</ogr:References>
      <ogr:Easting>353256</ogr:Easting>
      <ogr:Northing>140789</ogr:Northing>
      <ogr:Grid_Ref>ST5325640789</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.101">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>569761,336421</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Heacham</ogr:Waterway>
      <ogr:Head_Navi>Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in mid-13th century. If open for navigation, the River Heacham would connect the coast to Icknield Way and Peddars Way.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 80; Cole 2013, 320</ogr:References>
      <ogr:Easting>569761</ogr:Easting>
      <ogr:Northing>336421</ogr:Northing>
      <ogr:Grid_Ref>TF6976136421</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.102">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>522479,428648</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Hedon</ogr:Waterway>
      <ogr:Head_Navi>Burstwick</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1345</ogr:Last_Date>
      <ogr:Notes>Diversions of the watercourse above Hedon appear to have hindered passage to Burstwick.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoFR 1337-1347, 407; Edwards 1987, 147</ogr:References>
      <ogr:Easting>522479</ogr:Easting>
      <ogr:Northing>428648</ogr:Northing>
      <ogr:Grid_Ref>TA2247928648</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.103">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>518183,428054</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Hedon</ogr:Waterway>
      <ogr:Head_Navi>Hedon</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1345</ogr:Last_Date>
      <ogr:Notes>Purveyance account port. The ditch connecting Hedon to Humber had become dry by 1392.</ogr:Notes>
      <ogr:Obstruct>1338, Hedon to Burstwick.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 147; Langdon 1993, 5</ogr:References>
      <ogr:Easting>518183</ogr:Easting>
      <ogr:Northing>428054</ogr:Northing>
      <ogr:Grid_Ref>TA1818328054</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.104">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>572003,183743</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Holehaven Creek / Vange Creek</ogr:Waterway>
      <ogr:Head_Navi>Fobbing</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>In Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Lambert 2011, 213</ogr:References>
      <ogr:Easting>572003</ogr:Easting>
      <ogr:Northing>183743</ogr:Northing>
      <ogr:Grid_Ref>TQ7200383743</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.105">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>506100,456206</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Hull</ogr:Waterway>
      <ogr:Head_Navi>Wansford</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1309</ogr:Last_Date>
      <ogr:Notes>Berverley was the port named in the purveyance accounts. Grain transport from Malton and Pocklington to Wansford, whence it was shipped down the river.</ogr:Notes>
      <ogr:Obstruct>1268, stretch unspecified, river was navigable in 1309 to Wansford.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 148</ogr:References>
      <ogr:Easting>506100</ogr:Easting>
      <ogr:Northing>456206</ogr:Northing>
      <ogr:Grid_Ref>TA0610056206</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.106">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>530232,420575</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Humber Delve</ogr:Waterway>
      <ogr:Head_Navi>Patrington Haven</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>early 14th century</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>530232</ogr:Easting>
      <ogr:Northing>420575</ogr:Northing>
      <ogr:Grid_Ref>TA3023220575</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.107">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>465714,393140</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Idle</ogr:Waterway>
      <ogr:Head_Navi>Bawtry</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>465714</ogr:Easting>
      <ogr:Northing>393140</ogr:Northing>
      <ogr:Grid_Ref>SK6571493140</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.108">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>470954,377993</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Idle</ogr:Waterway>
      <ogr:Head_Navi>Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 82, Cole 2013, 320</ogr:References>
      <ogr:Easting>470954</ogr:Easting>
      <ogr:Northing>377993</ogr:Northing>
      <ogr:Grid_Ref>SK7095477993</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.109">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>468975,389526</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Idle</ogr:Waterway>
      <ogr:Head_Navi>Mattersey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1322</ogr:Last_Date>
      <ogr:Notes>Before 1086 the original course of Idle had been diverted east to join Trent through Bycarr's Dyke. The course of old Idle can be partially seen in the historic Yorkshire-Lincolnshire border, and 'Old Idle' joined 'Old Don' hear Hatdfield Chase.</ogr:Notes>
      <ogr:Obstruct>1363, Elkesley to downriver.</ogr:Obstruct>
      <ogr:References>Cole 2007, 65-6; Edwards 1987, 189-91</ogr:References>
      <ogr:Easting>468975</ogr:Easting>
      <ogr:Northing>389526</ogr:Northing>
      <ogr:Grid_Ref>SK6897589526</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.110">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>555487,187067</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ingrebourne</ogr:Waterway>
      <ogr:Head_Navi>Havering</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1266</ogr:Last_Date>
      <ogr:Notes>Timber ordered to be transported 'by water' from Havering to Westminster by the Thames.</ogr:Notes>
      <ogr:Obstruct>1351-2, a dispute about clearing the river below Havering.</ogr:Obstruct>
      <ogr:References>CoLR 1260-1267, 203; Edwards 1987, 278</ogr:References>
      <ogr:Easting>555487</ogr:Easting>
      <ogr:Northing>187067</ogr:Northing>
      <ogr:Grid_Ref>TQ5548787067</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.111">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>564219,274665</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Isleham cut</ogr:Waterway>
      <ogr:Head_Navi>Isleham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>A cut connecting Isleham to the Lark. Dates unknown, but possibly late twelfth-century or early thirteenth-century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Oosthuizen 1993, 29-35</ogr:References>
      <ogr:Easting>564219</ogr:Easting>
      <ogr:Northing>274665</ogr:Northing>
      <ogr:Grid_Ref>TL6421974665</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.112">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>445281,115571</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Itchen</ogr:Waterway>
      <ogr:Head_Navi>Gater's Mill</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Fieldwork evidence of an Anglo-Saxon canalised section between Wood Mill and Gater's Mill above Southampton. A major international fair at Winchester from 1096 suggests that the river was navigable there, but this is difficult to prove directly.</ogr:Notes>
      <ogr:Obstruct>The river was deemed unnavigable in 1276-7.</ogr:Obstruct>
      <ogr:References>Cole 2007, 74-7; Currie 2007, 244-53</ogr:References>
      <ogr:Easting>445281</ogr:Easting>
      <ogr:Northing>115571</ogr:Northing>
      <ogr:Grid_Ref>SU4528115571</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.113">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>305322,260996</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ithon</ogr:Waterway>
      <ogr:Head_Navi>Llandrindod Wells</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>11th or 12th century</ogr:Last_Date>
      <ogr:Notes>Boat find, with timber and stone landing place, dated via radiocarbon.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Grimes 1931; Kroger (forthcoming); Lanting 1998, 629; McGrail 1978, 230-2</ogr:References>
      <ogr:Easting>305322</ogr:Easting>
      <ogr:Northing>260996</ogr:Northing>
      <ogr:Grid_Ref>SO0532260996</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.114">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>438647,167533</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Kennet</ogr:Waterway>
      <ogr:Head_Navi>Kintbury</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place-name attested in 984. Cole writes Hidden at Kintbury refers to 'valley with a hythe'.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 71; Cole 2013, 313</ogr:References>
      <ogr:Easting>438647</ogr:Easting>
      <ogr:Northing>167533</ogr:Northing>
      <ogr:Grid_Ref>SU3864767533</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.115">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>471514,173092</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Kennet</ogr:Waterway>
      <ogr:Head_Navi>Reading</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>medieval</ogr:Last_Date>
      <ogr:Notes>Archaeological excavations have revealed a network of medieval canals connected to the Kennet in Reading. Changes to and work on these waterways contined to the Early modern period.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Ford 2013</ogr:References>
      <ogr:Easting>471514</ogr:Easting>
      <ogr:Northing>173092</ogr:Northing>
      <ogr:Grid_Ref>SU7151473092</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.116">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>522836,296252</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>King's Dyke</ogr:Waterway>
      <ogr:Head_Navi>Nene</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>A canal, dates unknown. Possible tenth century and used mostly for drainage.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 2, 46</ogr:References>
      <ogr:Easting>522836</ogr:Easting>
      <ogr:Northing>296252</ogr:Northing>
      <ogr:Grid_Ref>TL2283696252</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.117">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>273563,43996</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Kingsbridge Estuary</ogr:Waterway>
      <ogr:Head_Navi>Kingsbridge</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1347</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1346-1349, 328; Edwards 1987, 324</ogr:References>
      <ogr:Easting>273563</ogr:Easting>
      <ogr:Northing>43996</ogr:Northing>
      <ogr:Grid_Ref>SX7356343996</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.118">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>571048,283177</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lakenheath Old Lode</ogr:Waterway>
      <ogr:Head_Navi>Lakenheath</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place-name by 945.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 68; Cole 2013, 317</ogr:References>
      <ogr:Easting>571048</ogr:Easting>
      <ogr:Northing>283177</ogr:Northing>
      <ogr:Grid_Ref>TL7104883177</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.119">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>585787,264358</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lark</ogr:Waterway>
      <ogr:Head_Navi>Bury St Edmunds</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1379</ogr:Last_Date>
      <ogr:Notes>Along with 11 other vills, the bailiff and citizens of Thetford and Bury St Edmunds were ordered to array a balinger for the king in 1379. All other vills were coastal or along a navigated river, so Lark may have been navigable to the Bury as well.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1377-1381, 181-2</ogr:References>
      <ogr:Easting>585787</ogr:Easting>
      <ogr:Northing>264358</ogr:Northing>
      <ogr:Grid_Ref>TL8578764358</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.120">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>570787,274259</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lark</ogr:Waterway>
      <ogr:Head_Navi>Mildenhall</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1253</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 168, 188; Edwards 1987, 227</ogr:References>
      <ogr:Easting>570787</ogr:Easting>
      <ogr:Northing>274259</ogr:Northing>
      <ogr:Grid_Ref>TL7078774259</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.121">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>538267,211825</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lea</ogr:Waterway>
      <ogr:Head_Navi>Thele</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>538267</ogr:Easting>
      <ogr:Northing>211825</ogr:Northing>
      <ogr:Grid_Ref>TL3826711825</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.122">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>535590,214249</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lea</ogr:Waterway>
      <ogr:Head_Navi>Ware</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348?</ogr:Last_Date>
      <ogr:Notes>River in known use in 1258 when wine was carried by water from Ware on the Lea to Westminster on the Thames.</ogr:Notes>
      <ogr:Obstruct>From 1300 through the fourteenth century, from Ware downriver.</ogr:Obstruct>
      <ogr:References>CoLR 1251-1260, 444, 447; Edwards 1987, 278-81</ogr:References>
      <ogr:Easting>535590</ogr:Easting>
      <ogr:Northing>214249</ogr:Northing>
      <ogr:Grid_Ref>TL3559014249</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.123">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>538805,286633</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Leam</ogr:Waterway>
      <ogr:Head_Navi>Chatteris</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>A medieval canal of uncertain date. Also known as Elm River and Doddington Leam.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 2, 46-7</ogr:References>
      <ogr:Easting>538805</ogr:Easting>
      <ogr:Northing>286633</ogr:Northing>
      <ogr:Grid_Ref>TL3880586633</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.124">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>456769,510291</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Leven</ogr:Waterway>
      <ogr:Head_Navi>Little Ayton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name by 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 82; Cole 2013, 321</ogr:References>
      <ogr:Easting>456769</ogr:Easting>
      <ogr:Northing>510291</ogr:Northing>
      <ogr:Grid_Ref>NZ5676910291</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.125">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>581749,287849</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Little Ouse</ogr:Waterway>
      <ogr:Head_Navi>Santon Downham</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>581749</ogr:Easting>
      <ogr:Northing>287849</ogr:Northing>
      <ogr:Grid_Ref>TL8174987849</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.126">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>586672,283180</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Little Ouse</ogr:Waterway>
      <ogr:Head_Navi>Thetford</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Santon Downham, some 9.5 km downstream of Thetford, was a purveyance port in the early fourteeth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn, 334-6; Edwards 1987, 228</ogr:References>
      <ogr:Easting>586672</ogr:Easting>
      <ogr:Northing>283180</ogr:Northing>
      <ogr:Grid_Ref>TL8667283180</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.127">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>350841,258272</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lugg</ogr:Waterway>
      <ogr:Head_Navi>Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086. The river was presumably navigable 1 km further upstream to Leominster.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>350841</ogr:Easting>
      <ogr:Northing>258272</ogr:Northing>
      <ogr:Grid_Ref>SO5084158272</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.128">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>361326,478823</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lune</ogr:Waterway>
      <ogr:Head_Navi>Kirby Lonsdale</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>A 1365 grant of pontage indicates that Lune was navigable from Kirby Lonsdale to 'Gratrehals', an uncertain location further upstream.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1364-1367, 129; Edwards 1987, 367</ogr:References>
      <ogr:Easting>361326</ogr:Easting>
      <ogr:Northing>478823</ogr:Northing>
      <ogr:Grid_Ref>SD6132678823</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.129">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>348183,462901</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Lune</ogr:Waterway>
      <ogr:Head_Navi>Lancaster</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 367</ogr:References>
      <ogr:Easting>348183</ogr:Easting>
      <ogr:Northing>462901</ogr:Northing>
      <ogr:Grid_Ref>SD4818362901</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.130">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>450117,89391</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Medina</ogr:Waterway>
      <ogr:Head_Navi>Newport</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1342</ogr:Last_Date>
      <ogr:Notes>Named in the lists of large ship requisition ports of 1324 and 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183, 641; Edwards 1987, 307</ogr:References>
      <ogr:Easting>450117</ogr:Easting>
      <ogr:Northing>89391</ogr:Northing>
      <ogr:Grid_Ref>SZ5011789391</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.131">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>575766,155541</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Medway</ogr:Waterway>
      <ogr:Head_Navi>Maidstone</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port, named in the list of large ship requisition ports of 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 641; Edwards 1987, 274-77; Jones 2000, 63, 65-6; Langdon 1993, 5</ogr:References>
      <ogr:Easting>575766</ogr:Easting>
      <ogr:Northing>155541</ogr:Northing>
      <ogr:Grid_Ref>TQ7576655541</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.132">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>372659,393526</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Mersey</ogr:Waterway>
      <ogr:Head_Navi>Irlam</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>12th century</ogr:Last_Date>
      <ogr:Notes>Logboat find at Irlam dated c. twelfth century. Warburton some 5 km downriver was navigated in 1364.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 362-4; Kroger (forthcoming); Lanting 1998, 629; McGrail 1978, 220-22</ogr:References>
      <ogr:Easting>372659</ogr:Easting>
      <ogr:Northing>393526</ogr:Northing>
      <ogr:Grid_Ref>SJ7265993526</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.133">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>367312,387838</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Mersey</ogr:Waterway>
      <ogr:Head_Navi>Lymm</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the lists of large ship requisition ports of 1324 and 1326. Staithe place-name at Statham by Lymm.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183, 641; Cole 2013, 59, 318; Edwards 1987, 362-4</ogr:References>
      <ogr:Easting>367312</ogr:Easting>
      <ogr:Northing>387838</ogr:Northing>
      <ogr:Grid_Ref>SJ6731287838</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.134">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>349085,139761</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Mill Stream, Glastonbury</ogr:Waterway>
      <ogr:Head_Navi>Brue</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Lode place-name first attested c. 1180.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 78; Rippon 2007, 210</ogr:References>
      <ogr:Easting>349085</ogr:Easting>
      <ogr:Northing>139761</ogr:Northing>
      <ogr:Grid_Ref>ST4908539761</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.135">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>510309,444089</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Monk Dyke</ogr:Waterway>
      <ogr:Head_Navi>Leven</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1210-20</ogr:Last_Date>
      <ogr:Notes>Constructed by Meaux Abbey.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 195</ogr:References>
      <ogr:Easting>510309</ogr:Easting>
      <ogr:Northing>444089</ogr:Northing>
      <ogr:Grid_Ref>TA1030944089</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.136">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>519962,283098</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Monk's Lode</ogr:Waterway>
      <ogr:Head_Navi>Sawtry Abbey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1342</ogr:Last_Date>
      <ogr:Notes>A canal constructed by Sawtry Abbey by 1176 to carry building stone.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 187-8</ogr:References>
      <ogr:Easting>519962</ogr:Easting>
      <ogr:Northing>283098</ogr:Northing>
      <ogr:Grid_Ref>TL1996283098</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.137">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>345735,220267</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Monnow</ogr:Waterway>
      <ogr:Head_Navi>Skenfrith</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>12th century</ogr:Last_Date>
      <ogr:Notes>Twelfth-century wharf was excavated at the Skenrift Castle. Extent of navigation further upstream unknown.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Evans et al. 2003, 76</ogr:References>
      <ogr:Easting>345735</ogr:Easting>
      <ogr:Northing>220267</ogr:Northing>
      <ogr:Grid_Ref>SO4573520267</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.138">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>582042,314994</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Nar</ogr:Waterway>
      <ogr:Head_Navi>Castle Acre</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 188; Edwards 1987, 229</ogr:References>
      <ogr:Easting>582042</ogr:Easting>
      <ogr:Northing>314994</ogr:Northing>
      <ogr:Grid_Ref>TF8204214994</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.139">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>513156,296257</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Nene</ogr:Waterway>
      <ogr:Head_Navi>Alwalton</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>513156</ogr:Easting>
      <ogr:Northing>296257</ogr:Northing>
      <ogr:Grid_Ref>TL1315696257</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.140">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>505732,286924</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Nene</ogr:Waterway>
      <ogr:Head_Navi>Barnwell</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1322x41</ogr:Last_Date>
      <ogr:Notes>Course substantially modified several times in the medieval and post-medieval periods; see the Fenland Project for details down to parish level. Barwell was navigated in 1322x41, and Water Newton west of Peterborough was open for navigation in 1348.</ogr:Notes>
      <ogr:Obstruct>1314 onwards, obstruction at Outwell as well as places further uptream to Peterborough, Sawtry and Yaxley. Nene waters found a channel in the Well Creek, flowing east towards the Great Ouse and King's Lynn.</ogr:Obstruct>
      <ogr:References>Bond 2007, 189; Edwards 1987, 217-21; Fenland 2, 46 and The Fenland Project, passim.</ogr:References>
      <ogr:Easting>505732</ogr:Easting>
      <ogr:Northing>286924</ogr:Northing>
      <ogr:Grid_Ref>TL0573286924</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.141">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>477636,375594</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>North Beck</ogr:Waterway>
      <ogr:Head_Navi>East Drayton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1316</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 304</ogr:References>
      <ogr:Easting>477636</ogr:Easting>
      <ogr:Northing>375594</ogr:Northing>
      <ogr:Grid_Ref>SK7763675594</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.142">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>346941,146331</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Northlode canal</ogr:Waterway>
      <ogr:Head_Navi>Theale</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Lode place-name at Northlode by 1308. The actual course of the presumed canal is unknown; best guess traced on the map.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 78; Cole 2013, 60, 238</ogr:References>
      <ogr:Easting>346941</ogr:Easting>
      <ogr:Northing>146331</ogr:Northing>
      <ogr:Grid_Ref>ST4694146331</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.143">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>348157,138076</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Old Brue</ogr:Waterway>
      <ogr:Head_Navi>Brue</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1273</ogr:Last_Date>
      <ogr:Notes>Hythe at Bleadney attested in 712. Date of Brue diversion unknown, but the new channel connected Glastonbury to Meare by 1091. Old course still used for transport in 1273, and some portion of the waters still flowed through it in the sixteenth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 71; Cole 2013, 317; Rippon 2007, 207-227</ogr:References>
      <ogr:Easting>348157</ogr:Easting>
      <ogr:Northing>138076</ogr:Northing>
      <ogr:Grid_Ref>ST4815738076</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.144">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>352151,135016</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Old Rhyne / Cunlease Rhine</ogr:Waterway>
      <ogr:Head_Navi>hythe north of Butleigh</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Course marked by three hythes recorded in Anglo-Saxon charter boundaries. The easternmost was 'Welesyth' (Welsh hythe).</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 74; Hollinrake and Hollinrake 2007b, 241-2</ogr:References>
      <ogr:Easting>352151</ogr:Easting>
      <ogr:Northing>135016</ogr:Northing>
      <ogr:Grid_Ref>ST5215135016</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.145">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>539293,274702</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Old West River</ogr:Waterway>
      <ogr:Head_Navi>Great Ouse</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>late 13th century</ogr:Last_Date>
      <ogr:Notes>Cottenham Lode connecting to the Old West River in use already 1066. The importance of this connection between Great Ouse and Cam seems to have grown in the late thirteenth century as the Nene/Great Ouse outlet at Wisbech began to silt up.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 165; Edwards 1987, 22; Fowler 1933, 117-24</ogr:References>
      <ogr:Easting>539293</ogr:Easting>
      <ogr:Northing>274702</ogr:Northing>
      <ogr:Grid_Ref>TL3929374702</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.146">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>337476,289677</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Onny</ogr:Waterway>
      <ogr:Head_Navi>Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1291-2.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>337476</ogr:Easting>
      <ogr:Northing>289677</ogr:Northing>
      <ogr:Grid_Ref>SO3747689677</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.147">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>642575,249480</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ore</ogr:Waterway>
      <ogr:Head_Navi>Orford</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the lists of large ship requisition ports of 1324 and 1326. Ore originally entered the sea near Orford, but the mouth has been pushed southwards over the centuries.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183, 641; Edwards 1987, 249</ogr:References>
      <ogr:Easting>642575</ogr:Easting>
      <ogr:Northing>249480</ogr:Northing>
      <ogr:Grid_Ref>TM4257549480</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.148">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>616330,243942</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Orwell</ogr:Waterway>
      <ogr:Head_Navi>Ipswich</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324, hosted staple from 1313.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; CoPR 1313-1317, 15, 56; Edwards 1987, 250-2</ogr:References>
      <ogr:Easting>616330</ogr:Easting>
      <ogr:Northing>243942</ogr:Northing>
      <ogr:Grid_Ref>TM1633043942</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.149">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>425545,568092</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ouse Burn</ogr:Waterway>
      <ogr:Head_Navi>South Gosforth</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>In Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Lambert 2011, 211</ogr:References>
      <ogr:Easting>425545</ogr:Easting>
      <ogr:Northing>568092</ogr:Northing>
      <ogr:Grid_Ref>NZ2554568092</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.150">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>541941,110229</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ouse, Sussex</ogr:Waterway>
      <ogr:Head_Navi>Lewes</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1409-1413, 184; Edwards 1987, 303-4</ogr:References>
      <ogr:Easting>541941</ogr:Easting>
      <ogr:Northing>110229</ogr:Northing>
      <ogr:Grid_Ref>TQ4194110229</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.151">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>448280,460154</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ouse, Yorkshire</ogr:Waterway>
      <ogr:Head_Navi>Ure</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct>Several fourteenth-century references to obstructions.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 149-55</ogr:References>
      <ogr:Easting>448280</ogr:Easting>
      <ogr:Northing>460154</ogr:Northing>
      <ogr:Grid_Ref>SE4828060154</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.152">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>488335,232954</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ouzel</ogr:Waterway>
      <ogr:Head_Navi>Water Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086. Cole also suggests Eaton Bray further upstream, but this name probably derives from a different root (Eleanor Rye, pers. comm.).</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 82; Cole 2013, 319</ogr:References>
      <ogr:Easting>488335</ogr:Easting>
      <ogr:Northing>232954</ogr:Northing>
      <ogr:Grid_Ref>SP8833532954</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.153">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>549958,283804</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Oxlode</ogr:Waterway>
      <ogr:Head_Navi>Little Downham Hythe</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>A medieval canal, dates unknown.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 6, 81</ogr:References>
      <ogr:Easting>549958</ogr:Easting>
      <ogr:Northing>283804</ogr:Northing>
      <ogr:Grid_Ref>TL4995883804</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.154">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>342683,122885</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Parrett</ogr:Waterway>
      <ogr:Head_Navi>Thorney</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 319-21; Langdon 1993, 5</ogr:References>
      <ogr:Easting>342683</ogr:Easting>
      <ogr:Northing>122885</ogr:Northing>
      <ogr:Grid_Ref>ST4268322885</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.155">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>198273,201652</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Pembroke</ogr:Waterway>
      <ogr:Head_Navi>Pembroke</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1297</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 350</ogr:References>
      <ogr:Easting>198273</ogr:Easting>
      <ogr:Northing>201652</ogr:Northing>
      <ogr:Grid_Ref>SM9827301652</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.156">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>390135,311075</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Penk</ogr:Waterway>
      <ogr:Head_Navi>Water Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 940.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 321</ogr:References>
      <ogr:Easting>390135</ogr:Easting>
      <ogr:Northing>311075</ogr:Northing>
      <ogr:Grid_Ref>SJ9013511075</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.157">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>343356,319222</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Perry</ogr:Waterway>
      <ogr:Head_Navi>Yeaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>343356</ogr:Easting>
      <ogr:Northing>319222</ogr:Northing>
      <ogr:Grid_Ref>SJ4335619222</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.158">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>340077,144724</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Pilrow</ogr:Waterway>
      <ogr:Head_Navi>Brue</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Canal constructed by 1235. It is possible that Pilrow represent the first course of canalised Brue, and the section connecting Brue from its intersection with Pilrow to the Bristol Channel was added later. It was still in use in 1500.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 197; Rippon 2007, 207-27</ogr:References>
      <ogr:Easting>340077</ogr:Easting>
      <ogr:Northing>144724</ogr:Northing>
      <ogr:Grid_Ref>ST4007744724</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.159">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>588413,196619</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Pudsey</ogr:Waterway>
      <ogr:Head_Navi>Crouch</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place at Pudsey ('Podes(h)ethe') attested in 1361, and also at Creekside ('Krikesheth') some 5 km further downstream in 1240.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 61; Cole 2013, 314</ogr:References>
      <ogr:Easting>588413</ogr:Easting>
      <ogr:Northing>196619</ogr:Northing>
      <ogr:Grid_Ref>TQ8841396619</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.160">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>529025,285190</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ramsey Lode</ogr:Waterway>
      <ogr:Head_Navi>Ramsey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Lode, built to connect Ramsey Abbey to the Nene. Construction and improvements carried out in the twelfth and thirteenth centuries with the lode having been filled in by 1539.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 6, 47; Oosthuizen 2012, 210-11, Spoerry 2008, 176, 186-90, 199-202</ogr:References>
      <ogr:Easting>529025</ogr:Easting>
      <ogr:Northing>285190</ogr:Northing>
      <ogr:Grid_Ref>TL2902585190</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.161">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>456991,216169</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ray</ogr:Waterway>
      <ogr:Head_Navi>Otmoor</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1375</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct>1271, at Otmoor.</ogr:Obstruct>
      <ogr:References>Blair 2007b, 259; Edwards 1987, 283-4</ogr:References>
      <ogr:Easting>456991</ogr:Easting>
      <ogr:Northing>216169</ogr:Northing>
      <ogr:Grid_Ref>SP5699116169</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.162">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>556490,266505</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Reach Lode</ogr:Waterway>
      <ogr:Head_Navi>Reach</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>A canal, probably constructed in the Anglo-Saxon period.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 185; Fenland 10, 112; Fowler 1933, 113-14; Oosthuizen 2012, 213, 219</ogr:References>
      <ogr:Easting>556490</ogr:Easting>
      <ogr:Northing>266505</ogr:Northing>
      <ogr:Grid_Ref>TL5649066505</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.163">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>595687,128837</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Rhee Wall</ogr:Waterway>
      <ogr:Head_Navi>Appledore</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>c. 1300</ogr:Last_Date>
      <ogr:Notes>13thC canal diverting Rother and connecting Appledore with Romney. Primary purpose probably to channel the water to clear the estuary of silts. Sparse references to navigation until c. 1300 and it is unclear how regularly it was used for shipping.</ogr:Notes>
      <ogr:Obstruct>Degraded by great storms in the later thirteenth century, the last of which took place in 1287.</ogr:Obstruct>
      <ogr:References>Eddison 2002, 127-39</ogr:References>
      <ogr:Easting>595687</ogr:Easting>
      <ogr:Northing>128837</ogr:Northing>
      <ogr:Grid_Ref>TQ9568728837</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.164">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>352774,428839</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ribble</ogr:Waterway>
      <ogr:Head_Navi>Preston</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 366</ogr:References>
      <ogr:Easting>352774</ogr:Easting>
      <ogr:Northing>428839</ogr:Northing>
      <ogr:Grid_Ref>SD5277428839</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.165">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>571600,126342</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Rother</ogr:Waterway>
      <ogr:Head_Navi>Etchingham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1348</ogr:Last_Date>
      <ogr:Notes>In the Middle Ages the river split into two channels at Maythan, surrounding the Isle of Oxney. The northern channel (Upper Rother) passed Appledore before recombining with its twin, and can be traced through parish boundaries and the Reading Sewer.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 382-6; Edwards 1987, 300-3; Gardiner 2007, 100-3</ogr:References>
      <ogr:Easting>571600</ogr:Easting>
      <ogr:Northing>126342</ogr:Northing>
      <ogr:Grid_Ref>TQ7160026342</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.166">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>589330,129936</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Rother</ogr:Waterway>
      <ogr:Head_Navi>Small Hythe</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>589330</ogr:Easting>
      <ogr:Northing>129936</ogr:Northing>
      <ogr:Grid_Ref>TQ8933029936</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.167">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>595184,213661</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Salcott Creek</ogr:Waterway>
      <ogr:Head_Navi>Salcot</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>In Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Lambert 2011, 214</ogr:References>
      <ogr:Easting>595184</ogr:Easting>
      <ogr:Northing>213661</ogr:Northing>
      <ogr:Grid_Ref>TL9518413661</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.168">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>451146,429636</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Selby Canal</ogr:Waterway>
      <ogr:Head_Navi>Monk Fryston</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>probably by 1123</ogr:Last_Date>
      <ogr:Notes>Construction probably connected to the rebuilding of the Selby Abbey under Hugh de Lacy (1097-1123).</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 190</ogr:References>
      <ogr:Easting>451146</ogr:Easting>
      <ogr:Northing>429636</ogr:Northing>
      <ogr:Grid_Ref>SE5114629636</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.169">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>343191,315311</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Severn</ogr:Waterway>
      <ogr:Head_Navi>Montford Bridge</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Tolls dated 1285-1412 show boats were passing Montford Bridge. Navigation may have extended at least as far Welshpool, the next major commercial site further upstream. Welshpool was a 13thC borough with a market by 1252 and five recorded annual fairs.</ogr:Notes>
      <ogr:Obstruct>1277, at Gloucester and Worcester.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 330-4</ogr:References>
      <ogr:Easting>343191</ogr:Easting>
      <ogr:Northing>315311</ogr:Northing>
      <ogr:Grid_Ref>SJ4319115311</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.170">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>349587,312361</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Severn</ogr:Waterway>
      <ogr:Head_Navi>Shrewsbury</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Staple port from 1327.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1327-1330, 98; Edwards 1987, 330-4</ogr:References>
      <ogr:Easting>349587</ogr:Easting>
      <ogr:Northing>312361</ogr:Northing>
      <ogr:Grid_Ref>SJ4958712361</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.171">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>350814,143921</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Sheppey</ogr:Waterway>
      <ogr:Head_Navi>Fenny Castle</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Canalised by embankment for navigation by the fourteenth century. It is difficult to judge how far the navigation extended but the river was embanked at least as far as Fenny Castle.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Rippon 2007, 218-19</ogr:References>
      <ogr:Easting>350814</ogr:Easting>
      <ogr:Northing>143921</ogr:Northing>
      <ogr:Grid_Ref>ST5081443921</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.172">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>504079,454821</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Skerndile</ogr:Waterway>
      <ogr:Head_Navi>Skerne</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1249-69</ogr:Last_Date>
      <ogr:Notes>Constructed by Meaux Abbey.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 195-6</ogr:References>
      <ogr:Easting>504079</ogr:Easting>
      <ogr:Northing>454821</ogr:Northing>
      <ogr:Grid_Ref>TA0407954821</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.173">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>537592,283834</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Slade Lode</ogr:Waterway>
      <ogr:Head_Navi>West Water / Great Ouse</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>by 13th century</ogr:Last_Date>
      <ogr:Notes>A canal. Lode place-name attested by thirteenth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 6, 94</ogr:References>
      <ogr:Easting>537592</ogr:Easting>
      <ogr:Northing>283834</ogr:Northing>
      <ogr:Grid_Ref>TL3759283834</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.174">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>511082,349278</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Slea</ogr:Waterway>
      <ogr:Head_Navi>Holmilne' (possibly near Haverholme Priory)</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>511082</ogr:Easting>
      <ogr:Northing>349278</ogr:Northing>
      <ogr:Grid_Ref>TF1108249278</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.175">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>506811,345727</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Slea</ogr:Waterway>
      <ogr:Head_Navi>Sleaford</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct>Slea reported obstructed in 1342.</ogr:Obstruct>
      <ogr:References>Caffyn 2010, 316-17; Edwards 1987, 199-201</ogr:References>
      <ogr:Easting>506811</ogr:Easting>
      <ogr:Northing>345727</ogr:Northing>
      <ogr:Grid_Ref>TF0681145727</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.176">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>523942,310241</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>South Eau</ogr:Waterway>
      <ogr:Head_Navi>Crowland Abbet / Welland</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1303</ogr:Last_Date>
      <ogr:Notes>Most of the Crowland-Tydd St Mary route can be traced by boundary lines, but Dowsdale-Welland connection is uncertain. Two likely sewers (Oldee and Shepeau in 1349) used but these may be only a part of a complicated landscape of waterways and canals.</ogr:Notes>
      <ogr:Obstruct>Westernmost section connecting to the Welland blocked by Abbot Richard of Crowland (1280-1303), although it may have been periodically open. The Crowland blockage was still being contested in 1349.</ogr:Obstruct>
      <ogr:References>Caffyn 2010, 324; Edwards 1987, 216; Chisholm 2010, 127-31</ogr:References>
      <ogr:Easting>523942</ogr:Easting>
      <ogr:Northing>310241</ogr:Northing>
      <ogr:Grid_Ref>TF2394210241</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.177">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>517339,335622</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>South Forty Foot Drain</ogr:Waterway>
      <ogr:Head_Navi>Bridgend</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>early 14th century</ogr:Last_Date>
      <ogr:Notes>Purveyance account port. Langdon suggests that the water route from Bridgend to Boston went roughly along the present South Forty Foot Drain (constructed from 1765). Its medieval predecessor was the Midfen Dyke.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>517339</ogr:Easting>
      <ogr:Northing>335622</ogr:Northing>
      <ogr:Grid_Ref>TF1733935622</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.178">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>394572,322875</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Sow</ogr:Waterway>
      <ogr:Head_Navi>Penk</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name at Water Eaton on Penk attestd in 940. Cole believes Stafford 3 km upriver from Penk confluence derives from 'staithe', meaning landing place, but this interpretation is uncertain (Eleanor Rye pers.comm.).</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 75, 81; Cole 2013, 321</ogr:References>
      <ogr:Easting>394572</ogr:Easting>
      <ogr:Northing>322875</ogr:Northing>
      <ogr:Grid_Ref>SJ9457222875</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.179">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>549789,358625</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Steeping</ogr:Waterway>
      <ogr:Head_Navi>Wainfleet all Saints</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes>Purveyance account port, named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 194; Langdon 1993, 5</ogr:References>
      <ogr:Easting>549789</ogr:Easting>
      <ogr:Northing>358625</ogr:Northing>
      <ogr:Grid_Ref>TF4978958625</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.180">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>614122,157467</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Stour, Kent</ogr:Waterway>
      <ogr:Head_Navi>Canterbury</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1309</ogr:Last_Date>
      <ogr:Notes>It is probable only small vessels (referred to as 'navicule' in a 1264 Canterbury document relating to building a bridge sufficiently tall so as not to impede river traffic) could reach Canterbury.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1307-1313, 178; Edwards 1987, 298-301</ogr:References>
      <ogr:Easting>614122</ogr:Easting>
      <ogr:Northing>157467</ogr:Northing>
      <ogr:Grid_Ref>TR1412257467</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.181">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>617965,159802</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Stour, Kent</ogr:Waterway>
      <ogr:Head_Navi>Fordwich</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port. In the Middle Ages the broad Watsum Channel separated the Isle of Thanet from the mainland. The course of the waterway below Fordwich is therefore the modern and much reduced course of the river.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>617965</ogr:Easting>
      <ogr:Northing>159802</ogr:Northing>
      <ogr:Grid_Ref>TR1796559802</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.182">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>603511,235079</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Stour, Suffolk</ogr:Waterway>
      <ogr:Head_Navi>Brett</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Hadleigh on River Brett is in Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 252-3; Lambert 2011, 213</ogr:References>
      <ogr:Easting>603511</ogr:Easting>
      <ogr:Northing>235079</ogr:Northing>
      <ogr:Grid_Ref>TM0351135079</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.183">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>555515,263250</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Swaffham Lode</ogr:Waterway>
      <ogr:Head_Navi>Commercial End</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>A canal, probably constructed in the Anglo-Saxon period. Still in use in the fifteenth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 185; Fenland 10, 112; Fowler 1933, 113; Oosthuizen 2012, 212-13</ogr:References>
      <ogr:Easting>555515</ogr:Easting>
      <ogr:Northing>263250</ogr:Northing>
      <ogr:Grid_Ref>TL5551563250</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.184">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>601340,161540</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Swale, Kent</ogr:Waterway>
      <ogr:Head_Navi>Faversham</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1326.</ogr:Notes>
      <ogr:Obstruct>1353, stretch unspecified.</ogr:Obstruct>
      <ogr:References>CoCR 1323-1327, 641; Edwards 1987, 272-4</ogr:References>
      <ogr:Easting>601340</ogr:Easting>
      <ogr:Northing>161540</ogr:Northing>
      <ogr:Grid_Ref>TR0134061540</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.185">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>431884,491847</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Swale, Yorkshire</ogr:Waterway>
      <ogr:Head_Navi>Morton-on-Swale</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1317</ogr:Last_Date>
      <ogr:Notes>Mention of boats on the river.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 156-7; Caffyn 2010, 296-7</ogr:References>
      <ogr:Easting>431884</ogr:Easting>
      <ogr:Northing>491847</ogr:Northing>
      <ogr:Grid_Ref>SE3188491847</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.186">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>536218,269168</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Swavesey canal</ogr:Waterway>
      <ogr:Head_Navi>Swavesey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>medieval</ogr:Last_Date>
      <ogr:Notes>Hythe place-name attested in 1066: 'Swaef's landing place'. Archaeology shows that the town ditch was improved for navigation, probably between 1150-1350. It is not entirely clear by which route this unnamed waterway connected to the Great Ouse.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 229, 314; Sayer 2009, 140-1</ogr:References>
      <ogr:Easting>536218</ogr:Easting>
      <ogr:Northing>269168</ogr:Northing>
      <ogr:Grid_Ref>TL3621869168</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.187">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>451457,196734</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Swift Ditch</ogr:Waterway>
      <ogr:Head_Navi>Thames</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Thames diversion, cut between 1052-65.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 179; Blair 2007b, 266-8</ogr:References>
      <ogr:Easting>451457</ogr:Easting>
      <ogr:Northing>196734</ogr:Northing>
      <ogr:Grid_Ref>SU5145796734</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.188">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>317980,175912</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Taff</ogr:Waterway>
      <ogr:Head_Navi>Cardiff</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Hosted staple from 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1324-1327, 274</ogr:References>
      <ogr:Easting>317980</ogr:Easting>
      <ogr:Northing>175912</ogr:Northing>
      <ogr:Grid_Ref>ST1798075912</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.189">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>244655,69656</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tamar</ogr:Waterway>
      <ogr:Head_Navi>Morwellham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1339</ogr:Last_Date>
      <ogr:Notes>Quay of the water of Tamar' noted at Morwellham.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoIM 1307-1349, 409; Edwards 1987, 316-17</ogr:References>
      <ogr:Easting>244655</ogr:Easting>
      <ogr:Northing>69656</ogr:Northing>
      <ogr:Grid_Ref>SX4465569656</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.190">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>420512,303811</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tame</ogr:Waterway>
      <ogr:Head_Navi>Anker</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name by Anker attested in 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 321</ogr:References>
      <ogr:Easting>420512</ogr:Easting>
      <ogr:Northing>303811</ogr:Northing>
      <ogr:Grid_Ref>SK2051203811</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.191">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>255782,132931</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Taw</ogr:Waterway>
      <ogr:Head_Navi>Barnstaple</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Major requistion port in 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 642; Edwards 1987, 318-19</ogr:References>
      <ogr:Easting>255782</ogr:Easting>
      <ogr:Northing>132931</ogr:Northing>
      <ogr:Grid_Ref>SS5578232931</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.192">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>441806,513154</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tees</ogr:Waterway>
      <ogr:Head_Navi>Yarm</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1347</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 131-4; Langdon 1993, 5</ogr:References>
      <ogr:Easting>441806</ogr:Easting>
      <ogr:Northing>513154</ogr:Northing>
      <ogr:Grid_Ref>NZ4180613154</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.193">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>217778,245812</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Teifi</ogr:Waterway>
      <ogr:Head_Navi>Cardigan</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 350-2</ogr:References>
      <ogr:Easting>217778</ogr:Easting>
      <ogr:Northing>245812</ogr:Northing>
      <ogr:Grid_Ref>SN1777845812</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.194">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>219698,243004</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Teifi</ogr:Waterway>
      <ogr:Head_Navi>Cilgerran</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1340</ogr:Last_Date>
      <ogr:Notes>Navigation was improved by the removal of weirs at Cilgerran in the early fourteenth century, but obstructed again in 1340. Probable head of navigation above Cilgerran at Cenarth some 12 km distant, where a waterfall would have stopped navigation.</ogr:Notes>
      <ogr:Obstruct>Fourteenth century, weirs at Cilgerran.</ogr:Obstruct>
      <ogr:References>CoIM 1307-1349, 420; Edwards 1987, 350-2</ogr:References>
      <ogr:Easting>219698</ogr:Easting>
      <ogr:Northing>243004</ogr:Northing>
      <ogr:Grid_Ref>SN1969843004</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.195">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>286371,72458</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Teign</ogr:Waterway>
      <ogr:Head_Navi>Kingsteignton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>Boat find, wood dated to fourteenth century.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Dudley 2001, 266-72; Kroger (forthcoming)</ogr:References>
      <ogr:Easting>286371</ogr:Easting>
      <ogr:Northing>72458</ogr:Northing>
      <ogr:Grid_Ref>SX8637172458</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.196">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>348485,276623</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Teme</ogr:Waterway>
      <ogr:Head_Navi>Onny</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name (by Onny) attested in 1291-2.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>348485</ogr:Easting>
      <ogr:Northing>276623</ogr:Northing>
      <ogr:Grid_Ref>SO4848576623</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.197">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>364904,323112</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tern</ogr:Waterway>
      <ogr:Head_Navi>Eaton upon Tern</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1255-6.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320</ogr:References>
      <ogr:Easting>364904</ogr:Easting>
      <ogr:Northing>323112</ogr:Northing>
      <ogr:Grid_Ref>SJ6490423112</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.198">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>436834,113981</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Test</ogr:Waterway>
      <ogr:Head_Navi>Redbridge</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>A 1358 charter mentions vessels passing under the bridge of Redbridge indicating that the river was navigated further on, possibly to Romsey some 10 km upstream.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1358-1361, 29; Edwards 1987, 306</ogr:References>
      <ogr:Easting>436834</ogr:Easting>
      <ogr:Northing>113981</ogr:Northing>
      <ogr:Grid_Ref>SU3683413981</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.199">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>476365,182644</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Thames (lower)</ogr:Waterway>
      <ogr:Head_Navi>Henley (to Radcot)</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port at Henley. Thames divided into three sections by navigability. Sea-Henley (lower) was always open to navigation up and downstream.</ogr:Notes>
      <ogr:Obstruct>Fishing weirs on the Thames and Medway were already a concern in Magna Carta of 1216. The section above Henley appears to have become obstructed by the fifteenth century. Route from London to Henley is reported as heavily obstructed already in 1348.</ogr:Obstruct>
      <ogr:References>Blair 2007b, 254-86; Caffyn 2010, 352-67; CoPR 1348-1350, 76; Edwards 1987, 265-72; Jones 2000, 66; Langdon 1993, 5</ogr:References>
      <ogr:Easting>476365</ogr:Easting>
      <ogr:Northing>182644</ogr:Northing>
      <ogr:Grid_Ref>SU7636582644</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.200">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>451443,205559</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Thames (middle)</ogr:Waterway>
      <ogr:Head_Navi>Oxford (to Radcot)</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port at Oxford. Thames divided into three sections by navigability. Henley-Oxford (middle) was an important route but shipping probably mostly took place downstream with westwards traffic being carried overland.</ogr:Notes>
      <ogr:Obstruct>Fishing weirs on the Thames and Medway were already a concern in Magna Carta of 1216. The section above Henley appears to have become obstructed by the fifteenth century. Route from London to Henley is reported as heavily obstructed already in 1348.</ogr:Obstruct>
      <ogr:References>Blair 2007b, 254-86; Caffyn 2010, 352-67; CoPR 1348-1350, 76; Edwards 1987, 265-72; Jones 2000, 66; Langdon 1993, 5</ogr:References>
      <ogr:Easting>451443</ogr:Easting>
      <ogr:Northing>205559</ogr:Northing>
      <ogr:Grid_Ref>SP5144305559</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.201">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>428561,199401</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Thames (upper)</ogr:Waterway>
      <ogr:Head_Navi>Radcot</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1271</ogr:Last_Date>
      <ogr:Notes>Thames divided into three sections by navigability. Above Oxford (upper) it was probably navigated mostly by smaller boats and the shipping may have been local in its prevailing character.</ogr:Notes>
      <ogr:Obstruct>Fishing weirs on the Thames and Medway were already a concern in Magna Carta of 1216. The section above Henley appears to have become obstructed by the fifteenth century. Route from London to Henley is reported as heavily obstructed already in 1348.</ogr:Obstruct>
      <ogr:References>Blair 2007b, 254-86; Caffyn 2010, 352-67; Edwards 1987, 265-72; Jones 2000, 66</ogr:References>
      <ogr:Easting>428561</ogr:Easting>
      <ogr:Northing>199401</ogr:Northing>
      <ogr:Grid_Ref>SU2856199401</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.202">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>412471,193907</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Thames (upper)</ogr:Waterway>
      <ogr:Head_Navi>Water Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086. Cole suggests that the river was get navigable further 5,5 km upstream to Cricklade, where there was a transhipment point.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 80; Cole 2013, 321</ogr:References>
      <ogr:Easting>412471</ogr:Easting>
      <ogr:Northing>193907</ogr:Northing>
      <ogr:Grid_Ref>SU1247193907</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.203">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>490395,382379</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Till</ogr:Waterway>
      <ogr:Head_Navi>Stow</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>13th century</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 302</ogr:References>
      <ogr:Easting>490395</ogr:Easting>
      <ogr:Northing>382379</ogr:Northing>
      <ogr:Grid_Ref>SK9039582379</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.204">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>329654,126356</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tone</ogr:Waterway>
      <ogr:Head_Navi>near Curry Bridge</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Curry Bridge was listed as a purveyance account port. Along the old course of the Tone two lodes ('Coglode' and Curload) appear to refer to short now disappeared waterways.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>329654</ogr:Easting>
      <ogr:Northing>126356</ogr:Northing>
      <ogr:Grid_Ref>ST2965426356</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.205">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>322657,124815</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tone</ogr:Waterway>
      <ogr:Head_Navi>Taunton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1342x75</ogr:Last_Date>
      <ogr:Notes>Along the old course of the Tone two lodes ('Coglode' and Curload) appear to refer to short now disappeared waterways.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 78; Edwards 1987, 321-2; Hollinrake and Hollinrake 2007a, 231</ogr:References>
      <ogr:Easting>322657</ogr:Easting>
      <ogr:Northing>124815</ogr:Northing>
      <ogr:Grid_Ref>ST2265724815</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.206">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>246435,128992</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Torridge</ogr:Waterway>
      <ogr:Head_Navi>Hyde</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Hythe place-name by 1333</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 314</ogr:References>
      <ogr:Easting>246435</ogr:Easting>
      <ogr:Northing>128992</ogr:Northing>
      <ogr:Grid_Ref>SS4643528992</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.207">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>241385,219854</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Towy</ogr:Waterway>
      <ogr:Head_Navi>Carmarthen</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324, hosted staple from 1327.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; CoPR 1327-1330, 98; Edwards 1987, 349-50; Stratchey 1767 ii, 246</ogr:References>
      <ogr:Easting>241385</ogr:Easting>
      <ogr:Northing>219854</ogr:Northing>
      <ogr:Grid_Ref>SN4138519854</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.208">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>458139,338245</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Trent</ogr:Waterway>
      <ogr:Head_Navi>Nottingham</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>458139</ogr:Easting>
      <ogr:Northing>338245</ogr:Northing>
      <ogr:Grid_Ref>SK5813938245</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.209">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>399501,322586</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Trent</ogr:Waterway>
      <ogr:Head_Navi>Sow</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name at Water Eaton on the Penk attested in 940.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 75, 81; Cole 2013, 321</ogr:References>
      <ogr:Easting>399501</ogr:Easting>
      <ogr:Northing>322586</ogr:Northing>
      <ogr:Grid_Ref>SJ9950122586</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.210">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>436896,328515</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Trent</ogr:Waterway>
      <ogr:Head_Navi>Swarkestone</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1338</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct>Periodic complaints raised from 1268, first from above Torksey.</ogr:Obstruct>
      <ogr:References>CoPR 1338-1340, 22; Edwards 1987, 180-7</ogr:References>
      <ogr:Easting>436896</ogr:Easting>
      <ogr:Northing>328515</ogr:Northing>
      <ogr:Grid_Ref>SK3689628515</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.211">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>182928,44705</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Truro</ogr:Waterway>
      <ogr:Head_Navi>Truro</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1347</ogr:Last_Date>
      <ogr:Notes>Staple port from 1327.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1327-1330, 98; Edwards 1987, 324</ogr:References>
      <ogr:Easting>182928</ogr:Easting>
      <ogr:Northing>44705</ogr:Northing>
      <ogr:Grid_Ref>SW8292844705</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.212">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>514408,367970</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tupholme Abbey canal</ogr:Waterway>
      <ogr:Head_Navi>Tupholme Abbey</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1189</ogr:Last_Date>
      <ogr:Notes>Cut to serve Tupholme Abbey.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 196</ogr:References>
      <ogr:Easting>514408</ogr:Easting>
      <ogr:Northing>367970</ogr:Northing>
      <ogr:Grid_Ref>TF1440867970</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.213">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>371189,633905</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tweed</ogr:Waterway>
      <ogr:Head_Navi>Roxburgh</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1401</ogr:Last_Date>
      <ogr:Notes>Mentioned as port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1399-1401, 468; Edwards 1987, 124</ogr:References>
      <ogr:Easting>371189</ogr:Easting>
      <ogr:Northing>633905</ogr:Northing>
      <ogr:Grid_Ref>NT7118933905</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.214">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>384379,564374</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tyne</ogr:Waterway>
      <ogr:Head_Navi>Haydon Bridge</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1265x1350</ogr:Last_Date>
      <ogr:Notes>Ship toll, but it has been suggested the record is a clerical error.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 281</ogr:References>
      <ogr:Easting>384379</ogr:Easting>
      <ogr:Northing>564374</ogr:Northing>
      <ogr:Grid_Ref>NY8437964374</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.215">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>425278,563753</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Tyne</ogr:Waterway>
      <ogr:Head_Navi>Newcastle-upon-Tyne</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1362</ogr:Last_Date>
      <ogr:Notes>Staple port from 1313, named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct>1344, stretch unspecified; 1367 known to be open to Newcastle; 1371 obstructions Newcastle-Prudhoe.</ogr:Obstruct>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 125-30; Strachey, vol. 2, 246</ogr:References>
      <ogr:Easting>425278</ogr:Easting>
      <ogr:Northing>563753</ogr:Northing>
      <ogr:Grid_Ref>NZ2527863753</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.216">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>439313,467103</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Ure</ogr:Waterway>
      <ogr:Head_Navi>Boroughbridge</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port. References to navigation by Boroughbridge often indicate ship toll, which indicated the river was navigable some distance past the town.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 297; Edwards 1987, 157-9; Langdon 1993, 5</ogr:References>
      <ogr:Easting>439313</ogr:Easting>
      <ogr:Northing>467103</ogr:Northing>
      <ogr:Grid_Ref>SE3931367103</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.217">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>337417,200732</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Usk</ogr:Waterway>
      <ogr:Head_Navi>Usk</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1342</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 348</ogr:References>
      <ogr:Easting>337417</ogr:Easting>
      <ogr:Northing>200732</ogr:Northing>
      <ogr:Grid_Ref>SO3741700732</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.218">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>568025,110844</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Waller's Haven</ogr:Waterway>
      <ogr:Head_Navi>Hooe</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century</ogr:Last_Date>
      <ogr:Notes>In Lambert's list of requisition ports 1320-60.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Lambert 2011, 212</ogr:References>
      <ogr:Easting>568025</ogr:Easting>
      <ogr:Northing>110844</ogr:Northing>
      <ogr:Grid_Ref>TQ6802510844</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.219">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>624728,163387</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wantsum Channel</ogr:Waterway>
      <ogr:Head_Navi>Stour</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>In the Middle Ages the Wantsum Channel was a strait that encircled the Isle of Thanet. This location represents an approximation of the site where the Stour flowed into it.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References xsi:nil="true"/>
      <ogr:Easting>624728</ogr:Easting>
      <ogr:Northing>163387</ogr:Northing>
      <ogr:Grid_Ref>TR2472863387</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.220">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>641889,290416</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Waveney</ogr:Waterway>
      <ogr:Head_Navi>Beccles</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1325</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 242-3; Langdon 1993, 5</ogr:References>
      <ogr:Easting>641889</ogr:Easting>
      <ogr:Northing>290416</ogr:Northing>
      <ogr:Grid_Ref>TM4188990416</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.221">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>317040,551881</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Waver</ogr:Waterway>
      <ogr:Head_Navi>Abbeytown</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1324</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324. Abbeytown was previously called Holm Cultram, by which name medieval sources relating to navigation there refer to it. Large ships are unlikely have reached the town itself.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 369-70</ogr:References>
      <ogr:Easting>317040</ogr:Easting>
      <ogr:Northing>551881</ogr:Northing>
      <ogr:Grid_Ref>NY1704051881</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.222">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>427243,542432</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wear</ogr:Waterway>
      <ogr:Head_Navi>Durham</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>1336-1415</ogr:Last_Date>
      <ogr:Notes>Payments for transport of stone by boat made at Durham.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 283</ogr:References>
      <ogr:Easting>427243</ogr:Easting>
      <ogr:Northing>542432</ogr:Northing>
      <ogr:Grid_Ref>NZ2724342432</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.223">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>365698,373757</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Weaver</ogr:Waterway>
      <ogr:Head_Navi>Dane</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name by c. 1262 (by River Dane). Eaton Hall (SJ415610), attested by c. 1050, some 3.5 km further upriver from the Dane confluence may have also been an eaton, but the spellings are inconclusive.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 319</ogr:References>
      <ogr:Easting>365698</ogr:Easting>
      <ogr:Northing>373757</ogr:Northing>
      <ogr:Grid_Ref>SJ6569873757</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.224">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>352996,378453</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Weaver</ogr:Waterway>
      <ogr:Head_Navi>Frodsham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1324</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 365</ogr:References>
      <ogr:Easting>352996</ogr:Easting>
      <ogr:Northing>378453</ogr:Northing>
      <ogr:Grid_Ref>SJ5299678453</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.225">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>551325,303758</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Well Creek</ogr:Waterway>
      <ogr:Head_Navi>Wellstream</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes>Diversion of the Nene and Wellstream waters towards the new course of the Great Ouse, constructed by late thirteenth century.</ogr:Notes>
      <ogr:Obstruct>1301, near Outwell, forcing boats coming from the west to use the Old Croft River section of the Wellstream to detour via Littleport on their way to King's Lynn.</ogr:Obstruct>
      <ogr:References>Bond 2007, 186-7</ogr:References>
      <ogr:Easting>551325</ogr:Easting>
      <ogr:Northing>303758</ogr:Northing>
      <ogr:Grid_Ref>TF5132503758</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.226">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>523942,310241</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Welland</ogr:Waterway>
      <ogr:Head_Navi>Crowland</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>523942</ogr:Easting>
      <ogr:Northing>310241</ogr:Northing>
      <ogr:Grid_Ref>TF2394210241</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.227">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>503012,306931</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Welland</ogr:Waterway>
      <ogr:Head_Navi>Stamford</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1303</ogr:Last_Date>
      <ogr:Notes>The section between Crowland and Waldram Hall by the Welland was navigable in 1369.</ogr:Notes>
      <ogr:Obstruct>1334, at waterways connected to Spalding. But in 1336 grain was shipped from Crowland (upstream from Spalding) to Boston and the section between Crowland and Waldram Hall by the Welland was navigable in 1369. See Chisholm 2010, 136.</ogr:Obstruct>
      <ogr:References>Chisholm 2010, 136; Edwards 1987, 212-15</ogr:References>
      <ogr:Easting>503012</ogr:Easting>
      <ogr:Northing>306931</ogr:Northing>
      <ogr:Grid_Ref>TF0301206931</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.228">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>553523,274634</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wellstream</ogr:Waterway>
      <ogr:Head_Navi>Cam / Great Ouse</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes>Old course of the Great Ouse, part of which is also called the Old Croft River. By late thirteenth century new channels at Littleport and Upwell diverted water east and Wellstream seems to have declined in use.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Bond 2007, 186-7; Chisholm 2010, 131-2</ogr:References>
      <ogr:Easting>553523</ogr:Easting>
      <ogr:Northing>274634</ogr:Northing>
      <ogr:Grid_Ref>TL5352374634</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.229">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>612818,316743</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wensum</ogr:Waterway>
      <ogr:Head_Navi>Morton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1291</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 345-6; Edwards 1987, 241-2</ogr:References>
      <ogr:Easting>612818</ogr:Easting>
      <ogr:Northing>316743</ogr:Northing>
      <ogr:Grid_Ref>TG1281816743</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.230">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>622790,308863</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wensum</ogr:Waterway>
      <ogr:Head_Navi>Norwich</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 345-6; Edwards 1987, 241-2; Langdon 1993, 5</ogr:References>
      <ogr:Easting>622790</ogr:Easting>
      <ogr:Northing>308863</ogr:Northing>
      <ogr:Grid_Ref>TG2279008863</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.231">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>539293,274702</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>West Water</ogr:Waterway>
      <ogr:Head_Navi>Great Ouse</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>14th century?</ogr:Last_Date>
      <ogr:Notes>Canalised branch of the Great Ouse: see lode names 'Hollode', Horningslade', 'Grauelode'. May have declined by 1200 but Slade Lode and a hythe at Chatteris suggests navigation in 13thC, as do records of the bishopric of Ely in 14thC.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Chisholm 2010, 133; Cole 2007, 77; Cole 2013, 60, 238; Fenland 6, 94</ogr:References>
      <ogr:Easting>539293</ogr:Easting>
      <ogr:Northing>274702</ogr:Northing>
      <ogr:Grid_Ref>TL3929374702</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.232">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>195517,215689</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Western Cleddau</ogr:Waterway>
      <ogr:Head_Navi>Haverfordwest</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1301</ogr:Last_Date>
      <ogr:Notes>Named in the list of large ship requisition ports of 1324.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 183; Edwards 1987, 350</ogr:References>
      <ogr:Easting>195517</ogr:Easting>
      <ogr:Northing>215689</ogr:Northing>
      <ogr:Grid_Ref>SM9551715689</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.233">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>533172,324434</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Whaplode</ogr:Waterway>
      <ogr:Head_Navi>Holbeach</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>14th century?</ogr:Last_Date>
      <ogr:Notes>Purveyance account port, lode place-name attested by 1086 at Whaplode.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 60, 238; Langdon 1993, 5</ogr:References>
      <ogr:Easting>533172</ogr:Easting>
      <ogr:Northing>324434</ogr:Northing>
      <ogr:Grid_Ref>TF3317224434</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.234">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>448745,443451</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wharfe</ogr:Waterway>
      <ogr:Head_Navi>Tadcaster</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Edwards 1987, 160-1; Langdon 1993, 5</ogr:References>
      <ogr:Easting>448745</ogr:Easting>
      <ogr:Northing>443451</ogr:Northing>
      <ogr:Grid_Ref>SE4874543451</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.235">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>357517,140080</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Whitelake</ogr:Waterway>
      <ogr:Head_Navi>Pilton</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes>Partially canalised in 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Rippon 2007, 218-19</ogr:References>
      <ogr:Easting>357517</ogr:Easting>
      <ogr:Northing>140080</ogr:Northing>
      <ogr:Grid_Ref>ST5751740080</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.236">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>556312,270477</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wicken Lode</ogr:Waterway>
      <ogr:Head_Navi>near Wicken</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>unknown</ogr:Last_Date>
      <ogr:Notes>Medieval lode and hythe near Wicken. Dates of use unknown.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fowler 1933, 116; Oosthuizen 2012, 217</ogr:References>
      <ogr:Easting>556312</ogr:Easting>
      <ogr:Northing>270477</ogr:Northing>
      <ogr:Grid_Ref>TL5631270477</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.237">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>573479,299546</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wissey</ogr:Waterway>
      <ogr:Head_Navi>Oxborough</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1325</ogr:Last_Date>
      <ogr:Notes>Purveyance account port. A hythe was recorded at Methold Hythe (TL712948) some 5 km south of Wissey in 1277. Presumably a man-made waterway linked the hythe to the river, but its course cannot now be recovered.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2013, 316; Edwards 1987, 228; Langdon 1993, 5</ogr:References>
      <ogr:Easting>573479</ogr:Easting>
      <ogr:Northing>299546</ogr:Northing>
      <ogr:Grid_Ref>TL7347999546</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.238">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>487340,353881</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Witham</ogr:Waterway>
      <ogr:Head_Navi>Beckingham</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1336</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 312-15; Edwards 1987, 194-7</ogr:References>
      <ogr:Easting>487340</ogr:Easting>
      <ogr:Northing>353881</ogr:Northing>
      <ogr:Grid_Ref>SK8734053881</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.239">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>484243,348895</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Witham</ogr:Waterway>
      <ogr:Head_Navi>Claypole</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>before 1328</ogr:Last_Date>
      <ogr:Notes>Commissions to remove obstructions from Witham to Claypole recorded from 1328. Since the river was navigable to Beckingham in 1336, only 4 km downtream from Claypole, it is possible that navigation reached Claypole in the Middle Ages as well.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoPR 1327-1330, 349; CoPR 1334-1338, 220; Edwards 1987, 194-7</ogr:References>
      <ogr:Easting>484243</ogr:Easting>
      <ogr:Northing>348895</ogr:Northing>
      <ogr:Grid_Ref>SK8424348895</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.240">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>497176,371156</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Witham</ogr:Waterway>
      <ogr:Head_Navi>Lincoln</ogr:Head_Navi>
      <ogr:Class>KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Langdon 1993, 5</ogr:References>
      <ogr:Easting>497176</ogr:Easting>
      <ogr:Northing>371156</ogr:Northing>
      <ogr:Grid_Ref>SK9717671156</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.241">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>542020,350214</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wrangle Drain</ogr:Waterway>
      <ogr:Head_Navi>Wrangle</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>1189x1206</ogr:Last_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 312</ogr:References>
      <ogr:Easting>542020</ogr:Easting>
      <ogr:Northing>350214</ogr:Northing>
      <ogr:Grid_Ref>TF4202050214</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.242">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>353377,194239</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wye</ogr:Waterway>
      <ogr:Head_Navi>Chepstow</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes>Named in the lists of large ship requisition ports of 1324 and 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 184, 642; Edwards 1987, 440-1</ogr:References>
      <ogr:Easting>353377</ogr:Easting>
      <ogr:Northing>194239</ogr:Northing>
      <ogr:Grid_Ref>ST5337794239</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.243">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>301252,256389</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Wye</ogr:Waterway>
      <ogr:Head_Navi>Ithon</ogr:Head_Navi>
      <ogr:Class>DE</ogr:Class>
      <ogr:Last_Date>before 1301</ogr:Last_Date>
      <ogr:Notes>The 1301 survey charter notes that the river was previously navigable between Monmouth and Hereford. Eaton at Eaton Bishop. Boat find by Ithon indicates possibility of navigation upstream, but its extent between Hereford(Bishop Eaton and Ithon unknown.</ogr:Notes>
      <ogr:Obstruct>1301, between Hereford and Monmouth.</ogr:Obstruct>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Edwards 1987, 440-1</ogr:References>
      <ogr:Easting>301252</ogr:Easting>
      <ogr:Northing>256389</ogr:Northing>
      <ogr:Grid_Ref>SO0125256389</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.244">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>620228,305896</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Yare</ogr:Waterway>
      <ogr:Head_Navi>Eaton</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Eaton place-name attested in 1086.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Cole 2007, 82; Cole 2013, 320</ogr:References>
      <ogr:Easting>620228</ogr:Easting>
      <ogr:Northing>305896</ogr:Northing>
      <ogr:Grid_Ref>TG2022805896</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.245">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>625033,307806</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Yare</ogr:Waterway>
      <ogr:Head_Navi>Wensum</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Norwich, near where the Wensum joins the Yare, was a purveyance account port.</ogr:Notes>
      <ogr:Obstruct>1422 onwards efforts were made to improve navigation.</ogr:Obstruct>
      <ogr:References>Edwards 1987, 238-41</ogr:References>
      <ogr:Easting>625033</ogr:Easting>
      <ogr:Northing>307806</ogr:Northing>
      <ogr:Grid_Ref>TG2503307806</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.246">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>518881,292068</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Yaxley Lode</ogr:Waterway>
      <ogr:Head_Navi>Yaxley</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>post-1348</ogr:Last_Date>
      <ogr:Notes>Purveyance account port.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Fenland 6, 22; Langdon 1993, 5</ogr:References>
      <ogr:Easting>518881</ogr:Easting>
      <ogr:Northing>292068</ogr:Northing>
      <ogr:Grid_Ref>TL1888192068</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.247">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>255032,47909</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Yealm</ogr:Waterway>
      <ogr:Head_Navi>Newton Ferrers</ogr:Head_Navi>
      <ogr:Class>DE, KB</ogr:Class>
      <ogr:Last_Date>1326</ogr:Last_Date>
      <ogr:Notes>Named in the lists of large ship requisition ports of 1324 and 1326.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>CoCR 1323-1327, 184, 641</ogr:References>
      <ogr:Easting>255032</ogr:Easting>
      <ogr:Northing>47909</ogr:Northing>
      <ogr:Grid_Ref>SX5503247909</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:heads_of_navigation fid="heads_of_navigation.248">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>352224,122827</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:Waterway>Yeo, Ilchester</ogr:Waterway>
      <ogr:Head_Navi>Ilchester</ogr:Head_Navi>
      <ogr:Class>IE</ogr:Class>
      <ogr:Last_Date>PN</ogr:Last_Date>
      <ogr:Notes>Lode place-name at Long Load and Little Load by 1285. Roman wharves found at Ilchester on the Foss Way, so the Yeo may have been kept navigable that far. An account from c. 1633 mentions that boats reached the Pill Bridge, 3 km downstream from Ilchester.</ogr:Notes>
      <ogr:Obstruct xsi:nil="true"/>
      <ogr:References>Caffyn 2010, 408; Cole 2007, 78; Cole 2013, 60, 238; Edwards 1987, 322</ogr:References>
      <ogr:Easting>352224</ogr:Easting>
      <ogr:Northing>122827</ogr:Northing>
      <ogr:Grid_Ref>ST5222422827</ogr:Grid_Ref>
    </ogr:heads_of_navigation>
  </gml:featureMember>
</ogr:FeatureCollection>
