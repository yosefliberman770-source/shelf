<?xml version="1.0" encoding="utf-8" ?>
<ogr:FeatureCollection
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://ogr.maptools.org/ pn_river_traffic.xsd"
     xmlns:ogr="http://ogr.maptools.org/"
     xmlns:gml="http://www.opengis.net/gml">
  <gml:boundedBy>
    <gml:Box>
      <gml:coord><gml:X>336350</gml:X><gml:Y>98298</gml:Y></gml:coord>
      <gml:coord><gml:X>620253</gml:X><gml:Y>510823</gml:Y></gml:coord>
    </gml:Box>
  </gml:boundedBy>
                                                                                                                                       
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.0">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>517039,258864</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Bedfordshire</ogr:County>
      <ogr:Headform>Eaton Socon</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Affix from 17th c. (OE sōcn); Eaton Ford (TL 18089 60216) recorded from 1198 (Gover et al., 1936, xlii)).</ogr:Notes>
      <ogr:References>Cole 2007, 82; Cole 2013, 319; Ekwall 1960, 158; Gover et al. 1936, xlii; Mawer and Stenton 1926, 54; Watts 2004, 206</ogr:References>
      <ogr:Easting>517039</ogr:Easting>
      <ogr:Northing>258864</ogr:Northing>
      <ogr:Grid_Ref>TL1703958864</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.1">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>444796,203240</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Berkshire</ogr:County>
      <ogr:Headform>Eaton [Be]</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Dredging necessary to keep river usable here (Cole).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 319; Ekwall 1960, 158; Gelling 1973–1976, 402; Watts 2004, 206</ogr:References>
      <ogr:Easting>444796</ogr:Easting>
      <ogr:Northing>203240</ogr:Northing>
      <ogr:Grid_Ref>SP4479603240</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.2">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>426358,198581</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Berkshire</ogr:County>
      <ogr:Headform>Eaton Hastings</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On Thames between Lechlade and Radcot Bridge.  River liable to be choked by club rush (Cole 2007).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 319; Ekwall 1960, 158; Gelling 1973–1976, 364; Watts 2004, 206</ogr:References>
      <ogr:Easting>426358</ogr:Easting>
      <ogr:Northing>198581</ogr:Northing>
      <ogr:Grid_Ref>SU2635898581</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.3">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>438264,167209</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Berkshire</ogr:County>
      <ogr:Headform>Hidden</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>denu</ogr:Generic>
      <ogr:Element_1>hȳð</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place valley'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Charter bounds show this to be name of a valley running form the county boundary, 4 miles NW of Hungerford, to the Kennet at Kintbury; the landing place was on the Kennet (Gelling). The localisation given here is that of the likely landing place (ER).</ogr:Notes>
      <ogr:References>Gelling 1973–1976, 304; Cole 2013, 229 and 313</ogr:References>
      <ogr:Easting>438264</ogr:Easting>
      <ogr:Northing>167209</ogr:Northing>
      <ogr:Grid_Ref>SU3826467209</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.4">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>490044,181389</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Berkshire</ogr:County>
      <ogr:Headform>Maidenhead</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>mægden</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Maidens' landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>13th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>The early spellings do not securely demonstrate the OE genitive plural mægdena, but the specific is usually interpreted as a plural form.</ogr:Notes>
      <ogr:References>Gelling 1973–1976, 53; Cole 2013, 229 and 313; Ekwall 1960, 311; Watts 2004, 393</ogr:References>
      <ogr:Easting>490044</ogr:Easting>
      <ogr:Northing>181389</ogr:Northing>
      <ogr:Grid_Ref>SU9004481389</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.5">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>496604,177588</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Buckinghamshire</ogr:County>
      <ogr:Headform>Eton</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn/īg-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement or 'island settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Glossed as OE īg-tūn 'island settlement' by Mawer and Stenton (noting surrounding water), but others think this is ēa-tūn, with which most forms are consistent. Cole notes extensive reed beds and sharp turns that caused 1780 navigators difficulty.</ogr:Notes>
      <ogr:References>Cole 2007, 82; Cole 2013, 319; Ekwall 1960, 169; Mawer and Stenton 1925, 236; Watts 2004, 219</ogr:References>
      <ogr:Easting>496604</ogr:Easting>
      <ogr:Northing>177588</ogr:Northing>
      <ogr:Grid_Ref>SU9660477588</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.6">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>488253,232948</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Buckinghamshire</ogr:County>
      <ogr:Headform>Water Eaton [Bu]</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the River Ounzle.  Punting on these reaches possible in 1980s (Cole 2007).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 319; Ekwall 1960, 158; Mawer and Stenton 1925, 19; Watts 2004, 206</ogr:References>
      <ogr:Easting>488253</ogr:Easting>
      <ogr:Northing>232948</ogr:Northing>
      <ogr:Grid_Ref>SP8825332948</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.7">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>546300,302000</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Cambridgeshire</ogr:County>
      <ogr:Headform>Laddus Fens</ogr:Headform>
      <ogr:LCR>2</ogr:LCR>
      <ogr:Generic>lād</ogr:Generic>
      <ogr:Element_1>wer</ogr:Element_1>
      <ogr:Diagnostic>lād</ogr:Diagnostic>
      <ogr:Transl>Watercourse weir(s)'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Naismith dates earliest form to ante c. 1035, and thinks OE lād has sense 'path'. However, 'weir on a watercourse' or 'weir on a watercourse called lād' makes better sense.  Uncertain whether the referent is River Nene or a tributary (Cole).</ogr:Notes>
      <ogr:References>Cole 2013, 60; Naismith 2016, 342 and 355–56; Reaney 1943, 291; Watts 2004, 356</ogr:References>
      <ogr:Easting>546300</ogr:Easting>
      <ogr:Northing>302000</ogr:Northing>
      <ogr:Grid_Ref>TF4748001120</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.8">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>553300,262600</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Cambridgeshire</ogr:County>
      <ogr:Headform>Lode</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>lād</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>lād</ogr:Diagnostic>
      <ogr:Transl>Watercourse'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>12th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Named from Bottisham Lode (Reaney).</ogr:Notes>
      <ogr:References>Cole 2013, 77; Cole 2013, 60; Ekwall 1960, 302; Reaney 1943, 131; Watts 2004, 379</ogr:References>
      <ogr:Easting>553300</ogr:Easting>
      <ogr:Northing>262600</ogr:Northing>
      <ogr:Grid_Ref>TL5303662648</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.9">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>536319,269369</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Cambridgeshire</ogr:County>
      <ogr:Headform>Swavesey</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>pers.n.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Swǣf's landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Personal name *Swǣf. Alternatively OE 'Swǣfe' 'Swabians' - but this seems unlikely due to singular genitive inflexion (Reaney).</ogr:Notes>
      <ogr:References>Cole 2013, 229 and 314; Reaney 1943, 172; Watts 2004, 594</ogr:References>
      <ogr:Easting>536319</ogr:Easting>
      <ogr:Northing>269369</ogr:Northing>
      <ogr:Grid_Ref>TL3631969369</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.10">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>341409,360710</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Cheshire</ogr:County>
      <ogr:Headform>Eaton Hall</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Cole 2007, 82; Cole 2013, 319; Dodgson 1972, 148–49; Ekwall 1960, 158; Watts 2004, 206</ogr:References>
      <ogr:Easting>341409</ogr:Easting>
      <ogr:Northing>360710</ogr:Northing>
      <ogr:Grid_Ref>SJ4140960710</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.11">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>442929,111215</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Hampshire</ogr:County>
      <ogr:Headform>Wichyðe</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>p.n.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Probably 'landing-place associated with Hamwīc'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>12th</ogr:Century>
      <ogr:Chrtr_Date>990–92 (12th c.)</ogr:Chrtr_Date>
      <ogr:Notes>South Stoneham, Ha. Referring to Hamwic (Currie). Questions over the charter's authenticity.</ogr:Notes>
      <ogr:References>Sawyer no 944; Cole 2007, 72–73; Currie 1994, 113</ogr:References>
      <ogr:Easting>442929</ogr:Easting>
      <ogr:Northing>111215</ogr:Northing>
      <ogr:Grid_Ref>SU4292911215</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.12">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>350872,258260</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Herefordshire</ogr:County>
      <ogr:Headform>Eaton and Westeaton</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Coplestone-Crow 1989, 124; Ekwall 1960, 158</ogr:References>
      <ogr:Easting>350872</ogr:Easting>
      <ogr:Northing>258260</ogr:Northing>
      <ogr:Grid_Ref>SO5087258260</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.13">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>344284,239110</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Herefordshire</ogr:County>
      <ogr:Headform>Eaton Bishop</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Coplestone-Crow 1989, 80; Ekwall 1960, 158; Watts 2004, 206</ogr:References>
      <ogr:Easting>344284</ogr:Easting>
      <ogr:Northing>239110</ogr:Northing>
      <ogr:Grid_Ref>SO4428439110</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.14">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>361362,227804</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Herefordshire</ogr:County>
      <ogr:Headform>Eaton Tregoz or Hill of Eaton</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Coplestone-Crow 1989, 86; Ekwall 1960, 158</ogr:References>
      <ogr:Easting>361362</ogr:Easting>
      <ogr:Northing>227804</ogr:Northing>
      <ogr:Grid_Ref>SO6136227804</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.15">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>518954,292073</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Huntingdonshire</ogr:County>
      <ogr:Headform>(to) dichyðe, (of) dichyþe</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>dīc</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Ditch landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>956 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Text and location from Hart. Old course of Nene between Yaxley and Farcet</ogr:Notes>
      <ogr:References>Sawyer no 595; Hart 1966, 159 and 164; Cole 2007, 74</ogr:References>
      <ogr:Easting>518954</ogr:Easting>
      <ogr:Northing>292073</ogr:Northing>
      <ogr:Grid_Ref>TL1895492073</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.16">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>520988,294734</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Huntingdonshire</ogr:County>
      <ogr:Headform>(to) færresheafde hyþe</ogr:Headform>
      <ogr:LCR>2</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>p.n.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place associated with Farcet'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>956 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Text and location from Hart. First element is the place-name Farcet. Old course of Nene between Yaxley and Farcet</ogr:Notes>
      <ogr:References>Sawyer no 595; Hart 1966, 160 and 165; Cole 2007, 74</ogr:References>
      <ogr:Easting>520988</ogr:Easting>
      <ogr:Northing>294734</ogr:Northing>
      <ogr:Grid_Ref>TL2098894734</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.17">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>519956,293603</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Huntingdonshire</ogr:County>
      <ogr:Headform>(to) norðhyþe</ogr:Headform>
      <ogr:LCR>2</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>norð</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>North landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>956 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Text and location from Hart.  Old course of Nene between Yaxley and Farcet</ogr:Notes>
      <ogr:References>Sawyer no 595; Hart 1966, 160 and 165; Cole 2007, 74</ogr:References>
      <ogr:Easting>519956</ogr:Easting>
      <ogr:Northing>293603</ogr:Northing>
      <ogr:Grid_Ref>TL1995693603</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.18">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>519900,293019</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Huntingdonshire</ogr:County>
      <ogr:Headform>(to) suðhythe</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>sūð</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>South landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>956 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Text and location from Hart. Old course of Nene between Yaxley and Farcet</ogr:Notes>
      <ogr:References>Sawyer no 595; Hart 1966, 160 and 164; Cole 2007, 74</ogr:References>
      <ogr:Easting>519900</ogr:Easting>
      <ogr:Northing>293019</ogr:Northing>
      <ogr:Grid_Ref>TL1990093019</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.19">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>538604,274852</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Huntingdonshire</ogr:County>
      <ogr:Headform>Earith</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>ēar</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Gravelly landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>13th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Good access to fenland waterways (Cole).</ogr:Notes>
      <ogr:References>Cole 2013, 314; Mawer and Stenton 1926, 204</ogr:References>
      <ogr:Easting>538604</ogr:Easting>
      <ogr:Northing>274852</ogr:Northing>
      <ogr:Grid_Ref>TL3860474852</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.20">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>551577,178025</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Kent</ogr:County>
      <ogr:Headform>Erith</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>ēar</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Gravelly landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Cole 2013, 314; Wallenberg 1931, 17; Watts 2004, 218</ogr:References>
      <ogr:Easting>551577</ogr:Easting>
      <ogr:Northing>178025</ogr:Northing>
      <ogr:Grid_Ref>TQ5157778025</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.21">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>616134,134767</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Kent</ogr:County>
      <ogr:Headform>Hythe</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Cf. also West Hythe, probably 'the western part of Hythe' rather than a second hȳð place-name (Cullen). Hythe and West Hythe are now on the coast, but a northern branch of the River Rother probably formerly reached the coast at Hythe (Rippon).</ogr:Notes>
      <ogr:References>Carroll and Parsons 2007, 177–78; Cole 2013, 314; Cullen 1997, 213 and 222; Rippon 2002, 90–91; Watts 2004, 327</ogr:References>
      <ogr:Easting>616134</ogr:Easting>
      <ogr:Northing>134767</ogr:Northing>
      <ogr:Grid_Ref>TR1613434767</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.22">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>344255,391122</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Lancashire</ogr:County>
      <ogr:Headform>Huyton</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>tūn</ogr:Generic>
      <ogr:Element_1>hȳð</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>In this case, where hȳð is the first rather than the generic element, possibly ‘the settlement associated with or near the hȳð’ rather than ‘the hȳð-settlement’; if so, the landing-place might be more distant, perhaps Croxteth or Toxteth.</ogr:Notes>
      <ogr:References>Cole 2013, 315; Ekwall 1922, 113; Watts 2004, 326</ogr:References>
      <ogr:Easting>344255</ogr:Easting>
      <ogr:Northing>391122</ogr:Northing>
      <ogr:Grid_Ref>SJ4425591122</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.23">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>336350,387983</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Lancashire</ogr:County>
      <ogr:Headform>Toxteth</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>stæð/stǫð</ogr:Generic>
      <ogr:Element_1>pers.n.</ogr:Element_1>
      <ogr:Diagnostic>stæð/stǫð</ogr:Diagnostic>
      <ogr:Transl>Tóki's landing-place' or 'Tóki's river-bank'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Alternatively ON 'staðr' 'place' (Ekwall); however, estuary-side position would make this a suitable landing place (Cole 2013).</ogr:Notes>
      <ogr:References>Ekwall 1922, 115; Watts 2004, 625; Cole 2007, 76; Cole 2013, 223 and 318</ogr:References>
      <ogr:Easting>336350</ogr:Easting>
      <ogr:Northing>387983</ogr:Northing>
      <ogr:Grid_Ref>SJ3635087983</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.24">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>478805,394529</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Lincolnshire</ogr:County>
      <ogr:Headform>East Stockwith</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>stocc</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Tree-stump landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>12th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Cf. also West Stockwith in Nottinghamshire, on the opposite bank of the Trent.</ogr:Notes>
      <ogr:References>Cameron 1998, 118; Cole 2013, 315; Ekwall 1960, 444; Gover, Mawer and Stenton 1940, 39; Watts 2004, 393</ogr:References>
      <ogr:Easting>478805</ogr:Easting>
      <ogr:Northing>394529</ogr:Northing>
      <ogr:Grid_Ref>SK7880594529</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.25">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>482841,384642</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Lincolnshire</ogr:County>
      <ogr:Headform>Knaith</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>cnēo</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place by the knee or bend'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Referring to a river-bend.</ogr:Notes>
      <ogr:References>Cameron 1998, 76; Cole 2013, 315; Ekwall 1960, 281;  Watts 2004, 353</ogr:References>
      <ogr:Easting>482841</ogr:Easting>
      <ogr:Northing>384642</ogr:Northing>
      <ogr:Grid_Ref>SK8284184642</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.26">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>532300,324000</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Lincolnshire</ogr:County>
      <ogr:Headform>Whaplode</ogr:Headform>
      <ogr:LCR>1</ogr:LCR>
      <ogr:Generic>lād</ogr:Generic>
      <ogr:Element_1>*cwappa</ogr:Element_1>
      <ogr:Diagnostic>lād</ogr:Diagnostic>
      <ogr:Transl>Eelpout/burbot watercourse'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Cole suggests this might have been a channel linking the settlement to the Wash.</ogr:Notes>
      <ogr:References>Cameron 1998, 137; Cole 2007, 77; Cole 2013, 60;  Watts 2004, 669</ogr:References>
      <ogr:Easting>532300</ogr:Easting>
      <ogr:Northing>324000</ogr:Northing>
      <ogr:Grid_Ref>TF3245024028</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.27">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>561403,98298</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Middlesex</ogr:County>
      <ogr:Headform>(from) þære ealdan heðe</ogr:Headform>
      <ogr:LCR>2</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>eald</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>The old landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>963 (12th c.)</ogr:Chrtr_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Sawyer no 708; Kelly 2001, 388 and 390</ogr:References>
      <ogr:Easting>561403</ogr:Easting>
      <ogr:Northing>98298</ogr:Northing>
      <ogr:Grid_Ref>TV6140398298</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.28">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>532298,180805</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Middlesex</ogr:County>
      <ogr:Headform>Cf. Queenhithe</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>pers.n.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Æðelræd's landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>9th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Ætheredes hyd 898 (12th c.). Personal name Æðelrǣd. Former name for Queenhithe.</ogr:Notes>
      <ogr:References>Cole 2013, 316; Mills 2010, 201</ogr:References>
      <ogr:Easting>532298</ogr:Easting>
      <ogr:Northing>180805</ogr:Northing>
      <ogr:Grid_Ref>TQ3229880805</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.29">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>526906,177610</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Middlesex</ogr:County>
      <ogr:Headform>Chelsea</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>*cielce, *cyclce</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Chalk or limestone landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>8th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>The name may refer either to goods landed, or to the nature of the ground.</ogr:Notes>
      <ogr:References>Cole 2013, 315; Gover, Mawer and Stenton 1942, 85–86; Mills 2010, 51; Watts 2004, 129</ogr:References>
      <ogr:Easting>526906</ogr:Easting>
      <ogr:Northing>177610</ogr:Northing>
      <ogr:Grid_Ref>TQ2690677610</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.30">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>530728,180975</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Middlesex</ogr:County>
      <ogr:Headform>Lundentunes hyth</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>p.n.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>London-town's landing-place'</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>8th</ogr:Century>
      <ogr:Chrtr_Date>743 (11th c.)</ogr:Chrtr_Date>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Sawyer no 98; Cole 2007, 73–74; Mills 2010, 151</ogr:References>
      <ogr:Easting>530728</ogr:Easting>
      <ogr:Northing>180975</ogr:Northing>
      <ogr:Grid_Ref>TQ3072880975</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.31">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>535966,180909</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Middlesex</ogr:County>
      <ogr:Headform>Stepney</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>*stybba</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Stump or pile landing-place' or '*Stybba's landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>First element usually interpreted as an unrecorded OE personal name *Stybba (Gover et al.; Watts). However, Mills suggests OE *stybba (side-form of OE stybb ‘stub, tree-stump’) referring to the construction of the landing-place or a mooring post.</ogr:Notes>
      <ogr:References>Cole 2013, 315; Gover, Mawer and Stenton 1942, 149–50; Mills 2010, 235–36; Watts 2004, 574</ogr:References>
      <ogr:Easting>535966</ogr:Easting>
      <ogr:Northing>180909</ogr:Northing>
      <ogr:Grid_Ref>TQ3596680909</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.32">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>620253,305963</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Norfolk</ogr:County>
      <ogr:Headform>Eaton [Nf]</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the River Yare (Watts).</ogr:Notes>
      <ogr:References>Cole 2007, 82; Cole 2013, 320; Ekwall 1960, 158; Watts 2004, 206</ogr:References>
      <ogr:Easting>620253</ogr:Easting>
      <ogr:Northing>305963</ogr:Northing>
      <ogr:Grid_Ref>TG2025305963</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.33">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>580079,287598</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Norfolk</ogr:County>
      <ogr:Headform>Otringhithe [lost]</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>Group name.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place of the Otringas'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>The Otringas are 'the people named after Oter' or 'the people at a place called 'Otter-island''.  Early spellings of the place-name from slips in the Institute for Name-Studies, University of Nottingham show the dental consonant by the 12th century.</ogr:Notes>
      <ogr:References>Cole 2013, 316; Dymond 1998; Ekwall 1960, 324 and 353</ogr:References>
      <ogr:Easting>580079</ogr:Easting>
      <ogr:Northing>287598</ogr:Northing>
      <ogr:Grid_Ref>TL8007987598</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.34">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>471020,377966</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Nottinghamshire</ogr:County>
      <ogr:Headform>Eaton [Nt]</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the River Idle; a navigable R. Idle, crossed at Gamston by Great North Road, would provide a water route to Lincoln and York from the Great North Road (Cole).</ogr:Notes>
      <ogr:References>Cole 2007, 82; Cole 2013, 320; Ekwall 1960, 158; Gover, Mawer and Stenton 1940, 50; Watts 2004, 206</ogr:References>
      <ogr:Easting>471020</ogr:Easting>
      <ogr:Northing>377966</ogr:Northing>
      <ogr:Grid_Ref>SK7102077966</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.35">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>477732,180597</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Oxfordshire</ogr:County>
      <ogr:Headform>Bolney Court</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>bula</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place for bullocks'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Outside chance could be hæ:th (&lt;e&gt; in 11th and 12th c. spellings), but unlikely to account for range of spellings of generic (with &lt;i&gt;, &lt;y&gt; etc).</ogr:Notes>
      <ogr:References>Cole 2013, 316; Ekwall 1960, 51; Gelling 1953–54, 73–74</ogr:References>
      <ogr:Easting>477732</ogr:Easting>
      <ogr:Northing>180597</ogr:Northing>
      <ogr:Grid_Ref>SU7773280597</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.36">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>451555,212044</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Oxfordshire</ogr:County>
      <ogr:Headform>Water Eaton [Ox]</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>9th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Woodeaton (see below) and Water Eaton on opposite banks of the Cherwell below confluence with River Ray, the crossing place of a route from Worcester to London (Cole 2007).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 320; Ekwall 1960, 158; Gelling 1953–54, 266; Watts 2004, 206</ogr:References>
      <ogr:Easting>451555</ogr:Easting>
      <ogr:Northing>212044</ogr:Northing>
      <ogr:Grid_Ref>SP5155512044</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.37">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>453490,211905</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Oxfordshire</ogr:County>
      <ogr:Headform>Woodeaton</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Woodeaton and Water Eaton (see above) on opposite banks of the Cherwell below confluence with River Ray, the crossing place of a route from Worcester to London (Cole 2007).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 320; Ekwall 1960, 158; Gelling 1953–54, 194–95; Watts 2004, 694</ogr:References>
      <ogr:Easting>453490</ogr:Easting>
      <ogr:Northing>211905</ogr:Northing>
      <ogr:Grid_Ref>SP5349011905</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.38">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>359726,306307</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Shropshire</ogr:County>
      <ogr:Headform>Eaton Constantine</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>One mile from the Severn (Cole).</ogr:Notes>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Ekwall 1960, 158;  Gelling 1990, 115; Gelling 2012, 127; Watts 2004, 206</ogr:References>
      <ogr:Easting>359726</ogr:Easting>
      <ogr:Northing>306307</ogr:Northing>
      <ogr:Grid_Ref>SJ5972606307</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.39">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>353754,305863</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Shropshire</ogr:County>
      <ogr:Headform>Eaton Mascott</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the banks of the Cound Brook, which would be usable by small craft if kept clear (Cole). The lost hamlet of (Little) Eton (juxta Pitchford) in adjacent parish of Pitchford may derive its name from Eaton Mascott (Gelling 1990).</ogr:Notes>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Ekwall 1960, 158;  Gelling 1990, 115–16; Gelling 1995, 101</ogr:References>
      <ogr:Easting>353754</ogr:Easting>
      <ogr:Northing>305863</ogr:Northing>
      <ogr:Grid_Ref>SJ5375405863</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.40">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>350049,290056</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Shropshire</ogr:County>
      <ogr:Headform>Eaton under Heywood</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>13th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On a large stream (Watts).</ogr:Notes>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Ekwall 1960, 158;  Gelling 1990, 117; Gelling 2001, 143; Watts 2004, 206</ogr:References>
      <ogr:Easting>350049</ogr:Easting>
      <ogr:Northing>290056</ogr:Northing>
      <ogr:Grid_Ref>SO5004990056</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.41">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>343375,319443</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Shropshire</ogr:County>
      <ogr:Headform>Yeaton</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the banks of the River Perry, which has been straightened as it flows through the village (Cole). The DB form is the only form that might be indicative of 'īg-tūn'.</ogr:Notes>
      <ogr:References>Cole 2007, 81; Cole 2013, 320; Ekwall 1960, 544;  Gelling 1990, 333; Gelling 2006, 18; Watts 2004, 710</ogr:References>
      <ogr:Easting>343375</ogr:Easting>
      <ogr:Northing>319443</ogr:Northing>
      <ogr:Grid_Ref>SJ4337519443</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.42">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>354962,140356</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Somerset</ogr:County>
      <ogr:Headform>(Of) Cleuan (or Cleiian) Hithe, (on) Clewan Hithe</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>clǣg?</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Clay (?) landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>14th</ogr:Century>
      <ogr:Chrtr_Date>946 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Wootton, So; Grundy's localisation and text. Questions over the charter's authenticity.</ogr:Notes>
      <ogr:References>Sawyer no 509; Cole 2007, 74; Grundy 1935, 95 and 97</ogr:References>
      <ogr:Easting>354962</ogr:Easting>
      <ogr:Northing>140356</ogr:Northing>
      <ogr:Grid_Ref>ST5496240356</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.43">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>348231,145406</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Somerset</ogr:County>
      <ogr:Headform>Bleadney</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>pers.n.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>*Bledda's landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>8th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Personal name *Bledda (Cox).</ogr:Notes>
      <ogr:References>Abrams 1996, 62–63; Cole 2013, 317; Cox 1976, 17</ogr:References>
      <ogr:Easting>348231</ogr:Easting>
      <ogr:Northing>145406</ogr:Northing>
      <ogr:Grid_Ref>ST4823145406</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.44">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>351233,135682</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Somerset</ogr:County>
      <ogr:Headform>Hoctanyth</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>hōcede</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Hooked landing-place' or 'Octa's landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>801 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Specific alternatively a personal name Octa. Interpretation follows Kitson (forthcoming); location follows Hollinrake and Hollinrake (2007b, 242); Costen (1992) argues that this is a 10th c. boundary clause.</ogr:Notes>
      <ogr:References>Sawyer no 270a; Cole 2007, 74; Costen 1992, 43; Hollinrake and Hollinrake 2007b, 242; Kitson forthcoming, Somerset p. 20</ogr:References>
      <ogr:Easting>351233</ogr:Easting>
      <ogr:Northing>135682</ogr:Northing>
      <ogr:Grid_Ref>ST5123335682</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.45">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>346500,123300</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Somerset</ogr:County>
      <ogr:Headform>Long Load</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>lād</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>lād</ogr:Diagnostic>
      <ogr:Transl>Watercourse'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>13th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Either side of the river Yeo; referring either to the canalisation of the Yeo itself, or ot a short watercourse linking Long Load to the Yeo (Cole 2013).</ogr:Notes>
      <ogr:References>Cole 2007, 78; Cole 2013, 60 and 238</ogr:References>
      <ogr:Easting>346500</ogr:Easting>
      <ogr:Northing>123300</ogr:Northing>
      <ogr:Grid_Ref>ST4669723797</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.46">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>351370,135248</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Somerset</ogr:County>
      <ogr:Headform>Selfith</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>sci(e)lf</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Shelf landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>801 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Interpretation following Kitson (forthcoming).  Location following Hollinrake and Hollinrake (2007b, 242); Costen (1992) argues that this is a 10thC boundary clause.</ogr:Notes>
      <ogr:References>Sawyer no 270a; Cole 2007, 74; Costen 1992, 43; Hollinrake and Hollinrake 2007b, 242; Kitson forthcoming, Somerset p. 20</ogr:References>
      <ogr:Easting>351370</ogr:Easting>
      <ogr:Northing>135248</ogr:Northing>
      <ogr:Grid_Ref>ST5137035248</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.47">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>352079,134830</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Somerset</ogr:County>
      <ogr:Headform>Welesith</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>wealh</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Briton's landing-place' or 'Wealh's landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>801 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Specific alternatively the recorded personal name Wealh.  Location following Hollinrake and Hollinrake (2007b, 242); Costen (1992) argues that this is a 10thC boundary clause.</ogr:Notes>
      <ogr:References>Sawyer no 270a; Cole 2007, 74; Costen 1992, 43; Hollinrake and Hollinrake 2007b, 242; Kitson forthcoming, Somerset p. 20</ogr:References>
      <ogr:Easting>352079</ogr:Easting>
      <ogr:Northing>134830</ogr:Northing>
      <ogr:Grid_Ref>ST5207934830</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.48">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>353223,134653</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Somerset</ogr:County>
      <ogr:Headform>Yithe</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>801 (14th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Locations following Hollinrake and Hollinrake (2007b, 242); Costen (1992) argues that this is a 10thC boundary clause.</ogr:Notes>
      <ogr:References>Sawyer no 270a; Cole 2007, 74; Costen 1992, 43; Hollinrake and Hollinrake 2007b, 242</ogr:References>
      <ogr:Easting>353223</ogr:Easting>
      <ogr:Northing>134653</ogr:Northing>
      <ogr:Grid_Ref>ST5322334653</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.49">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>390247,311014</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Staffordshire</ogr:County>
      <ogr:Headform>Water Eaton [St]</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>The 940 (14th c.) form 'Eatun' listed in StPNs is from S 392, a spurious charter in which the land granted is unidentified. On the River Penk (Horovitz).</ogr:Notes>
      <ogr:References>Cole 2007, 81; Cole 2013, 321; Ekwall 1960, 158; Horovitz 2005, 242; Oakden 1984, 92</ogr:References>
      <ogr:Easting>390247</ogr:Easting>
      <ogr:Northing>311014</ogr:Northing>
      <ogr:Grid_Ref>SJ9024711014</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.50">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>616743,243524</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Suffolk</ogr:County>
      <ogr:Headform>Hyðe</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date>970 (12th c.)</ogr:Chrtr_Date>
      <ogr:Notes>In Stoke near Ipswich. Location from Hart (1992).</ogr:Notes>
      <ogr:References>Sawyer no 781; Cole 2007, 72; Hart 1992, 60</ogr:References>
      <ogr:Easting>616743</ogr:Easting>
      <ogr:Northing>243524</ogr:Northing>
      <ogr:Grid_Ref>TM1674343524</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.51">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>571418,282744</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Suffolk</ogr:County>
      <ogr:Headform>Lakenheath</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>Group name.</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing place of the Lacingas (probably, the people living by the streams)'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Alternatively, the Lacingas could be named after someone bearing the unrecorded personal name *Lāca; however, OE lacu 'small stream' is topographically appropriate.</ogr:Notes>
      <ogr:References>Briggs and Kilpatrick 2015, 85–86; Cole 2016, 317; Watts 2004, 356</ogr:References>
      <ogr:Easting>571418</ogr:Easting>
      <ogr:Northing>282744</ogr:Northing>
      <ogr:Grid_Ref>TL7141882744</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.52">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>501860,171640</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Surrey</ogr:County>
      <ogr:Headform>Glanty</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>*glente</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Probably 'kite landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>7th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>The specific is thought to mean either 'look-out' or to refer to a bird of prey; Kitson suggests it might mean 'black kite'.</ogr:Notes>
      <ogr:References>Cole 2013, 317; Gover et al. 1934, 121; Kitson 1998, 10</ogr:References>
      <ogr:Easting>501860</ogr:Easting>
      <ogr:Northing>171640</ogr:Northing>
      <ogr:Grid_Ref>TQ0186071640</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.53">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>503302,171417</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Surrey</ogr:County>
      <ogr:Headform>Hythe [Sr]</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>7th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Cole 2013, 317; Gover et al. 1934, 122</ogr:References>
      <ogr:Easting>503302</ogr:Easting>
      <ogr:Northing>171417</ogr:Northing>
      <ogr:Grid_Ref>TQ0330271417</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.54">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>530376,178140</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Surrey</ogr:County>
      <ogr:Headform>Lambeth</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>lamb</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place for lambs'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes xsi:nil="true"/>
      <ogr:References>Cole 2013, 317; Gover et al. 1934, 22–23; Mills 2010, 142–43; Watts 2004, 357</ogr:References>
      <ogr:Easting>530376</ogr:Easting>
      <ogr:Northing>178140</ogr:Northing>
      <ogr:Grid_Ref>TQ3037678140</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.55">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>535599,180181</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Surrey</ogr:County>
      <ogr:Headform>Rotherhithe</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>hrīðer</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place for cattle'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>12th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Cattle were probably transported from Rotherhithe across the Thames to 'Rederesgate' east of London Bridge on their way to the cattlemarket at Eastcheap (Mills).</ogr:Notes>
      <ogr:References>Cole 2013, 317; Ekwall 1960, 393; Gover et al. 1934, 28; Mills 2010, 210; Watts 2004, 261 and 357</ogr:References>
      <ogr:Easting>535599</ogr:Easting>
      <ogr:Northing>180181</ogr:Northing>
      <ogr:Grid_Ref>TQ3559980181</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.56">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>503674,170684</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Surrey</ogr:County>
      <ogr:Headform>Wealas Huthe, Wheles huþe</ogr:Headform>
      <ogr:LCR>3</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1>wealh</ogr:Element_1>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Briton's landing-place' or 'Wealh's landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>Y</ogr:Mltpl_Etym>
      <ogr:Century>13th</ogr:Century>
      <ogr:Chrtr_Date>675 (13th c.)</ogr:Chrtr_Date>
      <ogr:Notes>First element alternatively the recorded personal name Wealh.  Also in S 353 (spurious). Charter may be basically acceptable, but bounds later.</ogr:Notes>
      <ogr:References>Sawyer no 1165; Cole 2007, 74; Gover et al. 1934, 106 and 122</ogr:References>
      <ogr:Easting>503674</ogr:Easting>
      <ogr:Northing>170684</ogr:Northing>
      <ogr:Grid_Ref>TQ0367470684</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.57">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>582695,117474</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Sussex</ogr:County>
      <ogr:Headform>ða Hyðe</ogr:Headform>
      <ogr:LCR>1</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>The landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date>1005 (12th c.)</ogr:Chrtr_Date>
      <ogr:Notes>Brede, Sx; River formerly an estuary.</ogr:Notes>
      <ogr:References>Sawyer no 911; Cole 2007, 72</ogr:References>
      <ogr:Easting>582695</ogr:Easting>
      <ogr:Northing>117474</ogr:Northing>
      <ogr:Grid_Ref>TQ8269517474</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.58">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>518711,116173</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Sussex</ogr:County>
      <ogr:Headform>Eatons Fm</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the River Adur (Mawer and Stenton). About one mile downstream of Bines Bridge, the present head of navigation; may have played a roel in keeping watercourse open as far as landing place at Heath Barn, a 'hȳð' (Cole).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 320; Mawer and Stenton 1929–30, 217</ogr:References>
      <ogr:Easting>518711</ogr:Easting>
      <ogr:Northing>116173</ogr:Northing>
      <ogr:Grid_Ref>TQ1871116173</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.59">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>436556,291657</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Warwickshire</ogr:County>
      <ogr:Headform>Nuneaton</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>By the River Anker (Gover et al), which is just big enough for small craft at this location (Cole).</ogr:Notes>
      <ogr:References>Cole 2007, 81; Cole 2013, 321; Gover et al 1936, 88; Ekwall 1960, 158; Watts 2004, 445</ogr:References>
      <ogr:Easting>436556</ogr:Easting>
      <ogr:Northing>291657</ogr:Northing>
      <ogr:Grid_Ref>SP3655691657</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.60">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>414682,195905</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Wiltshire</ogr:County>
      <ogr:Headform>Castle Eaton</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the Thames between Lechlade, the present head fo navigation, and Cricklade, which can be reached by small craft if the channel is kept clear (Cole 2013).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 321; Gover, Mawer and Stenton 1939, 23–24; Ekwall 1960, 158; Watts 2004, 206</ogr:References>
      <ogr:Easting>414682</ogr:Easting>
      <ogr:Northing>195905</ogr:Northing>
      <ogr:Grid_Ref>SU1468295905</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.61">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>412653,193879</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Wiltshire</ogr:County>
      <ogr:Headform>Water Eaton [Wi]</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>ēa-tūn</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>On the Thames between Lechlade, the present head fo navigation, and Cricklade, which can be reached by small craft if the channel is kept clear (Cole 2013).</ogr:Notes>
      <ogr:References>Cole 2007, 80; Cole 2013, 321; Gover, Mawer and Stenton 1939, 45; Ekwall 1960, 158</ogr:References>
      <ogr:Easting>412653</ogr:Easting>
      <ogr:Northing>193879</ogr:Northing>
      <ogr:Grid_Ref>SU1265393879</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.62">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>482115,430955</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Yorkshire East Riding</ogr:County>
      <ogr:Headform>Hive</ogr:Headform>
      <ogr:LCR>5</ogr:LCR>
      <ogr:Generic>hȳð</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>hȳð</ogr:Diagnostic>
      <ogr:Transl>Landing-place'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>10th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Now a mile from the river Foulness.  There must, therefore, have been a navigable drain.  Smith suggests the Delph Drain (SE 82879 30819), and Cole seems to reach the same decision.</ogr:Notes>
      <ogr:References>Cole 2013,  317–18; Smith 1937, 247</ogr:References>
      <ogr:Easting>482115</ogr:Easting>
      <ogr:Northing>430955</ogr:Northing>
      <ogr:Grid_Ref>SE8211530955</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.63">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>498792,484791</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Yorkshire North Riding</ogr:County>
      <ogr:Headform>East and West Ayton</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>á-tún</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Ekwall suggests OE ēa-tūn influenced by ON á 'river'.  Scandinavian form given here following earliest (and most later) attestations. East Ayton (adjacent) not separately entered.</ogr:Notes>
      <ogr:References>Cole 2007, 81; Cole 2013, 321; Ekwall 1960, 21; Smith 1928, 100–01 ;Watts 2004, 29</ogr:References>
      <ogr:Easting>498792</ogr:Easting>
      <ogr:Northing>484791</ogr:Northing>
      <ogr:Grid_Ref>SE9879284791</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
  <gml:featureMember>
    <ogr:pn_river_traffic fid="pn_river_traffic.64">
      <ogr:geometryProperty><gml:Point srsName="EPSG:27700"><gml:coordinates>455546,510823</gml:coordinates></gml:Point></ogr:geometryProperty>
      <ogr:County>Yorkshire North Riding</ogr:County>
      <ogr:Headform>Great and Little Ayton</ogr:Headform>
      <ogr:LCR>4</ogr:LCR>
      <ogr:Generic>á-tún</ogr:Generic>
      <ogr:Element_1 xsi:nil="true"/>
      <ogr:Diagnostic>ēa-tūn</ogr:Diagnostic>
      <ogr:Transl>River settlement'.</ogr:Transl>
      <ogr:Mltpl_Etym>N</ogr:Mltpl_Etym>
      <ogr:Century>11th</ogr:Century>
      <ogr:Chrtr_Date xsi:nil="true"/>
      <ogr:Notes>Ekwall suggests OE ēa-tūn influenced by ON á 'river'.  Scandinavian form given here following earliest (and most later) attestations. By River Leven, which is not consistently navigable and meanders (Cole). Little Ayton (adjacent) not separately enter</ogr:Notes>
      <ogr:References>Cole 2007, 82; Cole 2013, 321; Ekwall 1960, 21; Smith 1928, 165–66 ;Watts 2004, 29</ogr:References>
      <ogr:Easting>455546</ogr:Easting>
      <ogr:Northing>510823</ogr:Northing>
      <ogr:Grid_Ref>NZ5554610823</ogr:Grid_Ref>
    </ogr:pn_river_traffic>
  </gml:featureMember>
</ogr:FeatureCollection>
